﻿using DataAccessLayer;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class FeeTypeMasterForm : System.Web.UI.Page
    {
        public int getid;
        public int UnitId;
        public static int ActiveId { get; set; }
        public static int rowIndex { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                FeeTypeMaster objFeeMaster = new FeeTypeMaster();
                BindAccount();

                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    FeeSave.Text = "Update";
                    ActiveId = 1;
                   // loadSession();
                    Initilaize();
                    BindAccount();
                    GetId();


                }
                else
                {
                    FeeSave.Text = "Save";
                    ActiveId = 0;
                    Clear();
                    //  ClearProduct();
                }

            }
        }

        //public void loadSession()
        //{
        //    FeeTypeMasterDAL objFeeTypeMasterDAL = new FeeTypeMasterDAL();
        //    List<FeeTypeMaster> activeFeeTypeMasterList = objFeeTypeMasterDAL.FeeTypeMasterSelect();
        //    if (activeFeeTypeMasterList != null)
        //    {
        //        GridViewListOfFeeTypeMaster.DataSource = ViewState["activeFeeMasterIdList"] as List<FeesMaster>;
        //        GridViewFeeMaster.DataBind();
        //    }
        //}
        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);

                }
            }
            catch
            {
                //   MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }

        public void BindAccount()
        {
            try
            {
                ChartofAccountDAL Activedal = new ChartofAccountDAL();
                List<ChartofAccount> ActiveListacc = Activedal.ChartofAccountSelect();
                ChartofAccount activeAccount = new ChartofAccount();
                if (ActiveListacc != null)
                {
                    activeAccount.Id = 0;
                    activeAccount.AccountName = "None";
                    ActiveListacc.Insert(0, activeAccount);
                    ddlAccountCode.DataSource = ActiveListacc;
                    ddlAccountCode.DataValueField = "Id";
                    ddlAccountCode.DataTextField = "AccountName";
                    ddlAccountCode.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        public void UpdateData(int Id)
        {
            try
            {
                FeeTypeMasterDAL activeFeeTypeMasterDAL = new FeeTypeMasterDAL();
                FeeTypeMaster activeFeeTypeMaster = activeFeeTypeMasterDAL.FeeTypeMasterGetById(Id);
                if (activeFeeTypeMaster != null)
                {

                    HiddenFieldDegree.Value = activeFeeTypeMaster.Id.ToString();
                    txtFeeCode.Attributes.Add("value", activeFeeTypeMaster.Code);
                    FeeDescription.Text = activeFeeTypeMaster.Description;
                   // activeFeeTypeMaster.AccountCode = Convert.ToInt32(txtAccountCode.Text);
                    ddltype.SelectedValue = activeFeeTypeMaster.FeeType.ToString();
                    ddlAccountCode.SelectedValue = activeFeeTypeMaster.AccountCode.ToString();


                    checkboxTransable.Checked = Convert.ToBoolean(activeFeeTypeMaster.Transable);

                   
                }

            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        public void Clear()
        {
            try
            {
                ActiveId = 0;

                FeeDescription.Text = string.Empty;
                ddlAccountCode.Text = string.Empty;
                checkboxTransable.Checked = false;
                ddltype.Text = string.Empty;

                HiddenFieldDegree.Value = string.Empty;
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        public void Initilaize()
        {
            try
            {
                FeeTypeMasterDAL objFeeTypeMasterDAL = new FeeTypeMasterDAL();
                FeeTypeMaster objFeeTypeMaster = objFeeTypeMasterDAL.FeeTypeMasterGetMaxId();
                string caption = "FT-00001";
                if (objFeeTypeMaster != null)
                {
                    string theString = objFeeTypeMaster.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtFeeCode.Value = "FT-0000" + code.ToString();
                }
                else
                {
                    txtFeeCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        public bool Save()
        {

            bool IsSave = true;


            FeeTypeMasterDAL activeFeeTypeMasterDAL = new FeeTypeMasterDAL();
            FeeTypeMaster activeFeeTypeMaster = new FeeTypeMaster();

            if (!string.IsNullOrEmpty(HiddenFieldDegree.Value))
            {
                activeFeeTypeMaster.Id = Convert.ToInt32(HiddenFieldDegree.Value);
            }



            if (!string.IsNullOrEmpty(FeeDescription.Text))
            {
                activeFeeTypeMaster.Description = FeeDescription.Text;
            }
            else
            {
                IsSave = false;
            }


            if (!string.IsNullOrEmpty(txtFeeCode.Value))
            {
                activeFeeTypeMaster.Code = txtFeeCode.Value;
            }
            else
            {
                IsSave = false;
            }

            //if (!string.IsNullOrEmpty(ddlAccountCode.Text))
            //{
            //    activeFeeTypeMaster.AccountCode = Convert.ToInt32(ddlAccountCode.Text);
            //}
            //else
            //{
            //    IsSave = false;
            //}

            if (!string.IsNullOrEmpty(ddlAccountCode.Text))
            {
                activeFeeTypeMaster.AccountCode = ddlAccountCode.SelectedItem.ToString();
                //    activeFeeMaster.Id = Convert.ToInt32(ddlchartAccount.SelectedValue);
            }
            else
            {
                //activeFeeMaster.AccountCode = string.Empty;
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddltype.SelectedItem.Text))
            {
                activeFeeTypeMaster.FeeType = ddltype.SelectedItem.Text;

            }
            else
            {
                //errorProviderDis.SetError(txtCode, "Enter The Job Code ");
                IsSave = false;
            }



            // activeAcadmicSession.Active = Activechk.Checked;
            //   activeAcadmicSession.Active = true;
            // activeAcadmicSession.CurrentYear = true;


            //if (Activechk !=null && Activechk.Checked)
            //{
            //    activeAcadmicSession.Active = Activechk.Checked;

            //}
            //else
            //{

            //    //  activeAcadmicSession.Active = Activechk.Checked;
            //    Activechk.Checked = false;
            //  //  IsSave = false;
            //}

            //if (CurrentYearchk != null && CurrentYearchk.Checked)
            //{
            //    activeAcadmicSession.CurrentYear = CurrentYearchk.Checked;

            //}
            //else
            //{

            //    //  activeAcadmicSession.Active = Activechk.Checked;
            //    CurrentYearchk.Checked = false;
            //  //  IsSave = false;
            //}

            activeFeeTypeMaster.Transable = checkboxTransable.Checked;
          //  activeAcadmicSession.CurrentYear = CurrentYearchk.Checked;




            if (IsSave == true)
            {
                if (FeeSave.Text == "Save")
                {
                    UnitId = activeFeeTypeMasterDAL.FeeTypeMasterInsert(activeFeeTypeMaster);
                    Response.Redirect("ListOfFeeTypeMasterForm.aspx");
                }

                else if (FeeSave.Text == "Update")
                {
                    if (activeFeeTypeMasterDAL.FeeTypeMasterUpdate(activeFeeTypeMaster) == true)

                        IsSave = true;
                    Response.Redirect("ListOfFeeTypeMasterForm.aspx");
                }
            }

            return IsSave;
        }




        protected void ddltype_SelectedIndexChanged(object sender, EventArgs e)
        {
            string message = ddltype.SelectedItem.Text + " - " + ddltype.SelectedItem.Value;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + message + "');", true);
        }

        protected void Feesave_btn(object sender, EventArgs e)
        {
            
                try
                {

                    if (Save())
                    {
                        Clear();
                        //BindUnit();
                        Response.Redirect("ListOfFeeTypeMasterForm.aspx");
                    }
                }
                catch (Exception ex)
                {
                    Messages.ErrorMessage(ex.ToString());

                }
            
        }

        protected void FeeClear_btn(object sender, EventArgs e)
        {
            Clear();
        }

        protected void txtFeeCode_TextChanged(object sender, EventArgs e)
        {

        }

        protected void FeeDescription_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ddlParentAccountFee_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void AccountCode_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
