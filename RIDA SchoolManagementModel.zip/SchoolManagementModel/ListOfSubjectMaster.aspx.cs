﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;


namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfSubjectMaster : System.Web.UI.Page
    {
        SubjectMasterDAL activeSubjectMasterDAL = new SubjectMasterDAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            bindtreeview();
         //   loadSession();
        }

        public void loadSession()
        {
            SubjectMasterDAL activeSubjectMasterDAL = new SubjectMasterDAL();
            List<SubjectMaster> activeSubjectMasterList = activeSubjectMasterDAL.SubjectMasterSelect();
            if (activeSubjectMasterList != null)
            {
                GridViewSubjectMaster.DataSource = ViewState["activeSubjectMasterList"] as List<SubjectMaster>;
                GridViewSubjectMaster.DataBind();
            }
            else
            {

                GridViewSubjectMaster.DataSource = null;
                GridViewSubjectMaster.DataBind();
            }

        }

        public void bindtreeview()
        {
            DataTable dt = activeSubjectMasterDAL.GetData("SELECT * From  SubjectMaster where Active='True'");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["Id"].ToString()
                };
                if (parentId == 0)
                {
                    //  TreeViewFeeMaster.Nodes.Add(child);
                    dtChild = activeSubjectMasterDAL.GetData("SELECT * From SubjectMaster where Active='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = activeSubjectMasterDAL.GetData("SELECT * From SubjectMaster where Active='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }
        protected void GridViewSubjectMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewSubjectMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                SubjectMasterDAL activeSubjectMasterDAL = new SubjectMasterDAL();
                if (iStID > 0)
                {
                    activeSubjectMasterDAL.SubjectMasterDelete(iStID);
                    //BindFeesMaster();
                   // loadSession();
                    TreeViewSubjectMaster.Nodes.Clear();
                    bindtreeview();
                    Response.Redirect("ListOfSubjectMaster.aspx");
                }              
            }
        }
        protected void TreeViewSubjectMaster_SelectedNodeChanged(object sender, EventArgs e)
        {

        }

        protected void GridViewSubjectMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridViewSubjectMaster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
    }
}