﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfFeeMasterForm : System.Web.UI.Page
    {
        List<FeesMaster> activeFeeMasterIdList = new List<FeesMaster>();
        FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
        FeesMaster objFeeMaster = new FeesMaster();
        public static int FeesMasterId { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
              //  BindFeesMaster();
                bindtreeview();
                loadSession();
            }
        }
        
        private void BindFeesMaster()
        {
            try
            {
                FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
                FeesMaster objFeeMaster = new FeesMaster();
                List<FeesMaster> activeFeeMasterIdList = objFeeMasterDAL.FeeMasterSelectNew();
                if (activeFeeMasterIdList != null)
                {
                    GridViewListofFeeMaster.DataSource = ViewState ["activeFeeMasterIdList"] as List<FeesMaster>;
                    GridViewListofFeeMaster.DataBind();
                }
            }
            catch (Exception)
            {
                //          throw;
            }
        }

        public void loadSession()
        {
            FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
            List<FeesMaster> activeFeeMasterIdList = objFeeMasterDAL.FeesMasterSelect();
            if (activeFeeMasterIdList != null)
            {
                GridViewListofFeeMaster.DataSource = ViewState["activeFeeMasterIdList"] as List<FeesMaster>;
                GridViewListofFeeMaster.DataBind();
            }
        }
        protected void GridViewListofFeeMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridViewListofFeeMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }

        public void bindtreeview()
        {
            DataTable dt = objFeeMasterDAL.GetData("SELECT Code, FeeType, FeeMonth,Description,AccountCode, Amount,Year From  FeesMaster  ");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["id"].ToString()
                };
                if (parentId == 0)
                {
                    TreeViewFeeMaster.Nodes.Add(child);
                    dtChild = objFeeMasterDAL.GetData("SELECT * From FeesMaster ");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = objFeeMasterDAL.GetData("SELECT * From FeesMaster ");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }
        protected void GridViewListofFeeMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/FeeMasterForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
                if (iStID > 0)
                {
                    objFeeMasterDAL.FeesMasterDelete(iStID);
                    //   BindFeesMaster();
                   // loadSession();
                    TreeViewFeeMaster.Nodes.Clear();
                    bindtreeview();
                    Response.Redirect("ListOfFeeMasterForm.aspx");
                }
                //  ClassSessionDAL objClassSessionDal = new ClassSessionDAL();
                // objClassSessionDal.ClassSessionDelete(iStID);
                // BindFeesMaster(); 
            }
        }

        protected void TreeViewFeeMaster_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}