﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfChallanDescription : System.Web.UI.Page
    {
        ChallanDescriptionDAL objChallanDescriptionDAL = new ChallanDescriptionDAL();
        ChallanDescription objChallanDescription = new ChallanDescription();
        protected void Page_Load(object sender, EventArgs e)
        {
            bindtreeview();
        }

        public void bindtreeview()
        {
            DataTable dt = objChallanDescriptionDAL.GetData("SELECT * From  ChallanDescription");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["Id"].ToString()
                };
                if (parentId == 0)
                {
                    TreeViewChallanDescription.Nodes.Add(child);
                    dtChild = objChallanDescriptionDAL.GetData("SELECT * From  ChallanDescription");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = objChallanDescriptionDAL.GetData("SELECT * From  ChallanDescription");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }

        protected void GridViewChallanDescription_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridViewChallanDescription_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewChallanDescription_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/ClassSectionGeneralForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                ChallanDescriptionDAL objChallanDescriptionDAL = new ChallanDescriptionDAL();
                objChallanDescriptionDAL.ChallanDescriptionDelete(iStID);
                //   BindFeesMaster();
                // loadSession();
                Response.Redirect("ListOfChallanDescription.aspx");
                bindtreeview();
            }
        }

        protected void TreeViewChallanDescription_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}