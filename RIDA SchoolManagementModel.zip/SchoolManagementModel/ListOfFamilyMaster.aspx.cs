﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EntityLayer;
using System.Data;
using DataAccessLayer;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfFamilyMaster : System.Web.UI.Page
    {
        public string IdCode { get; set; }
        public int ActiveId { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //         BindDegreeLevel();
                loadSession();
                bindtreeview();
            }
        }

        public void loadSession()
        {
            FamilyMasterDAL activeFamilyMasterDAL = new FamilyMasterDAL();
            List<FamilyMaster> activeList = activeFamilyMasterDAL.FamilyMasterSelect();
            if (activeList != null)
            {
                GridViewListofFamilyMaster.DataSource = ViewState["activeList"] as List<FamilyMaster>;
                GridViewListofFamilyMaster.DataBind();
            }
        }
        public void bindtreeview()
        {
            FamilyMasterDAL activeFamilyMasterDAL = new FamilyMasterDAL();
            DataTable dt = activeFamilyMasterDAL.GetData("SELECT * From  FamilyMaster where Active='True'");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            FamilyMasterDAL activeFamilyMasterDAL = new FamilyMasterDAL();
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["id"].ToString()
                };
                if (parentId == 0)
                {
                    //TreeViewAcadmicSession.Nodes.Add(child);

                    dtChild = activeFamilyMasterDAL.GetData("SELECT * From  FamilyMaster where Active='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = activeFamilyMasterDAL.GetData("SELECT * From  FamilyMaster where Active='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }

        protected void GridViewListofFamilyMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/FamilyMasterForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                FamilyMasterDAL activeDAL = new FamilyMasterDAL();
                if (iStID > 0)
                {
                    activeDAL.FamilyMasterDelete(iStID);
                    //loadSession();
                    //    TreeViewAcadmicSession.Nodes.Clear();
                    bindtreeview();
                    Response.Redirect("ListOfFamilyMaster.aspx");
                }
            }
        }

        protected void GridViewListofFamilyMaster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewListofFamilyMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewListofFamilyMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void TreeViewFamilyMaster_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}