﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI;
using System.Configuration;
using EntityLayer;
using System.Data;
using DataAccessLayer;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class TransportMasterForm : System.Web.UI.Page
    {
        public int ActiveId;
        public int getid;
        public int UnitId;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Initilaize();
                GetId();
                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {

                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    TransportMasterSave.Text = "Update";
                    ActiveId = 1;
                    Initilaize();
                    GetId();
                }
                else
                {
                    TransportMasterSave.Text = "Save";
                    ActiveId = 0;
                    Clear();
                }
            }
        }
        
        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);
                }
            }
            catch
            {
                MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }
        public void UpdateData(int Id)
        {
            try
            {
                TransportMasterDAL activeTransportMasterDAL = new TransportMasterDAL();
                TransportMaster activeTransportMaster = activeTransportMasterDAL.TransportMasterGetById(Id);
                if (activeTransportMaster != null)
                {
                    HiddenFieldTransportMaster.Value = activeTransportMaster.Id.ToString();
                    txtTransportMasterCode.Attributes.Add("value", activeTransportMaster.Code);
                    txtTransportMasterDescription.Text = activeTransportMaster.Description;
                    TextBoxDriverName.Text = activeTransportMaster.DriverName;
                    TextBoxDriverID.Text = activeTransportMaster.DriverId.ToString();
                    TextBoxRegistration.Text = activeTransportMaster.Registration;
                    TextBoxNumberPlate.Text = activeTransportMaster.NumberPlate;
                    TextBoxCell.Text = activeTransportMaster.CellPhone.ToString();
                    TextBoxCapacity.Text = activeTransportMaster.Capacity;
                    CheckBoxTransport.Checked = Convert.ToBoolean(activeTransportMaster.Active);
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        public void Initilaize()
        {
            try
            {
                TransportMasterDAL activeTransportMasterDAL = new TransportMasterDAL();
                TransportMaster activeMemberMaxId = activeTransportMasterDAL.TransportMasterGetMaxId();
                string caption = "TM-00001";
                if (activeMemberMaxId != null)
                {
                    string theString = activeMemberMaxId.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtTransportMasterCode.Value = "TM-0000" + code.ToString();
                }
                else
                {
                    txtTransportMasterCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        public void Clear()
        {
            try
            {
                ActiveId = 0;

                txtTransportMasterDescription.Text = string.Empty;
                TextBoxCapacity.Text = string.Empty;
                TextBoxCell.Text = string.Empty;
                TextBoxDriverName.Text = string.Empty;
                TextBoxDriverID.Text = string.Empty;
                TextBoxRegistration.Text = string.Empty;
                TextBoxNumberPlate.Text = string.Empty;
                HiddenFieldTransportMaster.Value = string.Empty;
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
        public bool Save()
        {
            bool IsSave = true;

            TransportMasterDAL activeTransportMasterDAL = new TransportMasterDAL();
            TransportMaster activeTransportMaster = new TransportMaster();

            if (!string.IsNullOrEmpty(HiddenFieldTransportMaster.Value))
            {
                activeTransportMaster.Id = Convert.ToInt32(HiddenFieldTransportMaster.Value);
            }

            if (!string.IsNullOrEmpty(txtTransportMasterDescription.Text))
            {
                activeTransportMaster.Description = txtTransportMasterDescription.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxDriverName.Text))
            {
                activeTransportMaster.DriverName = TextBoxDriverName.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxDriverID.Text))
            {
                activeTransportMaster.DriverId = Convert.ToInt32(TextBoxDriverID.Text);
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(txtTransportMasterCode.Value))
            {
                activeTransportMaster.Code = txtTransportMasterCode.Value;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxNumberPlate.Text))
            {
                activeTransportMaster.NumberPlate = TextBoxNumberPlate.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxRegistration.Text))
            {
                activeTransportMaster.Registration = TextBoxRegistration.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxCell.Text))
            {
                activeTransportMaster.CellPhone =TextBoxCell.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxCapacity.Text))
            {
                activeTransportMaster.Capacity = TextBoxCapacity.Text;
            }
            else
            {
                IsSave = false;
            }
            activeTransportMaster.Active = CheckBoxTransport.Checked;

            if (IsSave == true)
            {
                if (TransportMasterSave.Text == "Save")
                {
                    UnitId = activeTransportMasterDAL.TransportMasterInsert(activeTransportMaster);
                    Response.Redirect("ListOfTransportMaster.aspx");
                }
                else if (TransportMasterSave.Text == "Update")
                {
                    if (activeTransportMasterDAL.TansportMasterUpdate(activeTransportMaster) == true)

                        IsSave = true;
                    Response.Redirect("ListOfTransportMaster.aspx");
                }
            }
            return IsSave;
        }

        protected void TransportMasterSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    Clear();
                    Response.Redirect("ListOfTransportMaster.aspx");
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        protected void TransportMasterClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}