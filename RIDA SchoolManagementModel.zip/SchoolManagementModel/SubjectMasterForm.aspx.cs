﻿using DataAccessLayer;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Data;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class SubjectMasterForm : System.Web.UI.Page
    {
        public static int ActiveId { get; set; }
        public static int SectionId { get; set; }
        public static int rowIndex { get; set; }
        public static int SubjectMasterId { get; set; }

        public static string Code = null;
        public int UnitId;
        SubjectMaster objSubjectMaster = new SubjectMaster();
        List<SubjectMaster> activeSubjectMasterIdList = new List<SubjectMaster>();
        List<SubjectSection> activeSubjectSectionList = new List<SubjectSection>();
        List<SubjectChapter> activeSubjectChapterList = new List<SubjectChapter>();
        List<SubjectTopic> activeSubjectTopicList = new List<SubjectTopic>();
        SubjectMaster objFeeMasterDAL = new SubjectMaster();
        public int getid;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rowIndex = -1;
                ViewState["SubjectSection"] = new List<SubjectSection>();
                // TabName.Value = Request.Form[TabName.UniqueID];
                Initilaize();
                GetId();
                BindEmployee();
                GetAllSection();
                GetAllChapter();
                GetAllTopic();
                //DataTable dt = new DataTable();
                //dt.Columns.AddRange(new DataColumn[1] { new DataColumn("Section") });
                //ViewState["SubjectSection"] = dt;
                //this.BindGrid();


                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    SubjectMasterSave.Text = "Update";
                    ActiveId = 1;

                    //buttonSectionPost.Text = "Post";
                    //ActiveId = 1;

                    //loadSession();
                    // Initilaize();
                    //   GetId();

                    //MainView.ActiveViewIndex = 1;
                    //MainView.ActiveViewIndex = 2;
                    //MainView.ActiveViewIndex = 3;

                }
                else
                {
                    ViewState["SubjectSection"] = (List<SubjectSection>)null;
                    SubjectMasterSave.Text = "Save";
                    ActiveId = 0;
                  //  Clear();
                    GridViewSection.DataBind();
                }
            }
        }

        //protected void BindGrid()
        //{
        //    GridViewSection.DataSource = (DataTable)ViewState["SubjectSection"];
        //    GridViewSection.DataBind();
        //}
        //protected void Insert(object sender, EventArgs e)
        //{
        //    DataTable dt = (DataTable)ViewState["SubjectSection"];
        //    dt.Rows.Add(TextBoxSubjectSection.Text.Trim());
        //    ViewState["SubjectSection"] = dt;
        //    this.BindGrid();
        //    TextBoxSubjectSection.Text = string.Empty;
        //    //txtCountry.Text = string.Empty;
        //}
        public void UpdateData(int Id)
        {
            try
            {
                SubjectMasterDAL activeSubjectMasterDAL = new SubjectMasterDAL();
                SubjectMaster objSubjectMaster = activeSubjectMasterDAL.SubjectMasterGetById(Id);

                if (objSubjectMaster != null)
                {
                    hfSubjectMaster.Value = objSubjectMaster.Id.ToString();
                    txtSubjectCode.Attributes.Add("value", objSubjectMaster.Code);
                    txtSubject.Text = objSubjectMaster.Subject.ToString();
                    TextBoxHours.Text = objSubjectMaster.Hours.ToString();
                    TextBoxSubjectRemarks.Text = objSubjectMaster.Remarks.ToString();
                    ddlTeacher.SelectedItem.Text = objSubjectMaster.TeacherId;
                    objSubjectMaster.Active = CheckBoxSubject.Checked;
                    //TextBoxSubjectSection.Text = objSubjectMaster.Section.ToString();
                    //TextBoxChapters.Text = objSubjectMaster.Chapter;
                    //TextBoxTopics.Text = objSubjectMaster.Topic;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);

                }
            }
            catch
            {
              
            }
        }

        private void BindEmployee()
        {
            EmployeeDAL activeDAL = new EmployeeDAL();
            List<Employee> EmployeeList = activeDAL.EmployeeSelect();
            Employee activeEmployee = new Employee();
            activeEmployee.Id = 0;
            activeEmployee.Name = "None";
            EmployeeList.Insert(0, activeEmployee);
            ddlTeacher.DataSource = EmployeeList;
            ddlTeacher.DataValueField = "Id";
            ddlTeacher.DataTextField = "Name";
            ddlTeacher.DataBind();
        }
        //public void loadSession()
        //{
        //    SubjectMasterDAL objSubjectMasterDAL = new SubjectMasterDAL();
        //    List<SubjectMaster> activeFeeMasterIdList = objSubjectMasterDAL.SubjectMasterSelect();
        //    if (activeFeeMasterIdList != null)
        //    {
        //        GridViewSection.DataSource = ViewState["activeSubjectMasterIdList"] as List<SubjectMaster>;
        //        GridViewSection.DataBind();
        //    }
        //}
        public void AllClear()
        {
            try
            {
                ActiveId = 0;

                txtSubject.Text = string.Empty;
                ddlTeacher.SelectedIndex = 0;
                TextBoxHours.Text = string.Empty;
                TextBoxSubjectRemarks.Text = string.Empty;
                TextBoxSubjectSection.Text = string.Empty;
                TextBoxChapters.Text = string.Empty;
                TextBoxTopics.Text = string.Empty;
                

                hfSubjectMaster.Value = string.Empty;
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        public void Clear()
        {
            SubjectSectionDAL objFee = new SubjectSectionDAL();
            DataSet ds = objFee.GetALlSection();
            ViewState["ClassFeePost"] = null;
            ds.Clear();
            GridViewSection.DataBind();
            rowIndex = -1;
            ActiveId = 0;
            Initilaize();
            AllClear();
            //GridViewSection.DataSource = string.Empty;
            //GridViewSection.DataBind();
            GridViewChapters.DataSource = string.Empty;
            GridViewChapters.DataBind();
            GridViewTopics.DataSource = string.Empty;
            GridViewTopics.DataBind();
            //ActiveId = 0;
            //rowIndex = -1;
            //Initilaize();
            //ViewState["SubjectSection"] = (List<SubjectSection>)null;
            //ViewState["SubjectChapter"] = (List<SubjectChapter>)null;
            //ViewState["SubjectTopic"] = (List<SubjectTopic>)null;
            //AllClear();
        }
        
        public void Initilaize()
        {
            try
            {
                SubjectMasterDAL objSubjectMasterDAL = new SubjectMasterDAL();
                SubjectMaster objSubjectMaster = objSubjectMasterDAL.SubjectMasterGetMaxId();
                string caption = "SM-00001";
                if (objSubjectMaster != null)
                {
                    string theString = objSubjectMaster.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtSubjectCode.Value = "SM-0000" + code.ToString();
                }
                else
                {
                    txtSubjectCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
        private void BindGridView()
        {
            try
            {
                SubjectMasterDAL objSubjectMasterDAL = new SubjectMasterDAL();
                List<SubjectMaster> activeSubjectMasterIdList = objSubjectMasterDAL.SubjectMasterSelectNew();
                if (activeSubjectMasterIdList != null)
                {
                   // GridViewSection.DataSource = ViewState["activeSubjectMasterIdList"] as List<FeesMaster>;
                   // GridViewSection.DataBind();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

      

        protected void SubjectMasterSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    Response.Redirect("~/SchoolManagementModel/ListOfSubjectMaster.aspx", false);
                    Context.ApplicationInstance.CompleteRequest();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool Save()
        {

            bool IsSave = true;

            SubjectMasterDAL activeSubjectMasterDAL = new SubjectMasterDAL();
            SubjectMaster activeSubjectMaster = new SubjectMaster();

            if (!string.IsNullOrEmpty(hfSubjectMaster.Value))
            {
                activeSubjectMaster.Id = Convert.ToInt32(hfSubjectMaster.Value);
            }

            if (!string.IsNullOrEmpty(txtSubject.Text))
            {
                activeSubjectMaster.Subject = txtSubject.Text;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(txtSubjectCode.Value))
            {
                activeSubjectMaster.Code = txtSubjectCode.Value;
            }
            else
            {
                IsSave = false;
            }


            if (!string.IsNullOrEmpty(ddlTeacher.Text))
            {
                activeSubjectMaster.TeacherId = ddlTeacher.SelectedItem.Text.ToString();
            }
            else
            {
                IsSave = false;
            }


            if (!string.IsNullOrEmpty(TextBoxHours.Text))
            {
                activeSubjectMaster.Hours = TextBoxHours.Text;
            }
            else
            {
                IsSave = false;
            }


            if (!string.IsNullOrEmpty(TextBoxSubjectRemarks.Text))
            {
                activeSubjectMaster.Remarks = TextBoxSubjectRemarks.Text.ToString();
            }
            else
            {
                IsSave = false;
            }
            activeSubjectMaster.Active = CheckBoxSubject.Checked;

            if (IsSave == true)
            {
                if (SubjectMasterSave.Text == "Save")
                {
                    UnitId = activeSubjectMasterDAL.SubjectMasterInsert(activeSubjectMaster);
                    Response.Redirect("ListOfSubjectMaster.aspx");
                    
                }

                else if (SubjectMasterSave.Text == "Update")
                {
                    if (activeSubjectMasterDAL.SubjectMasterUpdate(activeSubjectMaster) == true)

                        IsSave = true;
                    Response.Redirect("ListOfSubjectMaster.aspx");
                }

            }

            return IsSave;
        }

       
        protected void SubjectMasterClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void GetAllSection()
        {
            SubjectSectionDAL objsection = new SubjectSectionDAL();
            DataSet ds= objsection.GetALlSection();
            if (ds!=null)
            {
                GridViewSection.DataSource = ds;
                GridViewSection.DataBind();
            }
            else {
                GridViewSection.DataSource = null;
                GridViewSection.DataBind();
            }

        }

        private void GetAllChapter()
        {
            SubjectChapterDAL objChapter = new SubjectChapterDAL();
            DataSet ds = objChapter.GetALlChapter();
            if (ds != null)
            {
                GridViewChapters.DataSource = ds;
                GridViewChapters.DataBind();
            }
            else
            {
                GridViewChapters.DataSource = null;
                GridViewChapters.DataBind();
            }

        }

        private void GetAllTopic()
        {
            SubjectTopicDAL objTopic = new SubjectTopicDAL();
            DataSet ds = objTopic.GetALlTopic();
            if (ds != null)
            {
                GridViewTopics.DataSource = ds;
                GridViewTopics.DataBind();
            }
            else
            {
                GridViewTopics.DataSource = null;
                GridViewTopics.DataBind();
            }

        }


        protected void TextBoxTeacherID_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtSubject_TextChanged(object sender, EventArgs e)
        {

        }

        //********************************************************* Tab 1 ***********************************************************//
        //private bool IPost()
        //{


        //    bool IsPost = true;


        //    SubjectSectionDAL activeSubjectSectionDAL = new SubjectSectionDAL();
        //    SubjectSection activeSubjectSection = new SubjectSection();

        //    if (!string.IsNullOrEmpty(hfSubjectSection.Value))
        //    {
        //        activeSubjectSection.Id = Convert.ToInt32(hfSubjectSection.Value);
        //    }

        //    if (!string.IsNullOrEmpty(TextBoxSubjectSection.Text))
        //    {
        //        activeSubjectSection.Section = TextBoxSubjectSection.Text;

        //    }
        //    else
        //    {
        //        IsPost = false;
        //    }

        //    if (IsPost == true)
        //    {
        //        if (buttonSectionPost.Text == "Post")
        //        {
        //            UnitId = activeSubjectSectionDAL.SubjectSectionInsert(activeSubjectSection);
        //            // Response.Redirect("SubjectMasterForm.aspx");
        //            //GridViewSection.Columns.Clear();
        //        }

        //        else if (buttonSectionPost.Text == "Update")
        //        {
        //            if (activeSubjectSectionDAL.SubjectSectionUpdate(activeSubjectSection) == true)
        //                IsPost = true;
        //            //  Response.Redirect("SubjectMasterForm.aspx");
        //        }
        //    }
        //    return IsPost;
        //}

        private bool IPost()
        {
            if (TextBoxSubjectSection.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all Fields Correctly";
                return false;
            }
            bool _post = true;
            SubjectSectionDAL activeSubjectSectionDAL = new SubjectSectionDAL();
            List<SubjectSection> activeSubjectSectionList = new List<SubjectSection>();
            if (ViewState["SubjectSection"] != null)
            {
                activeSubjectSectionList = (List<SubjectSection>)ViewState["SubjectSection"];
            }

            //var _item = _listApproval.Find(x => x.FormID == Convert.ToInt16(ddlForms.SelectedItem.Value) && x.UserID == Convert.ToInt16(ddlUser.SelectedItem.Value));
            //if (_item != null)
            //{
            //    msgAleart.Visible = true;
            //    lblMessage.Text = "Duplicate Value not Allowed";
            //    ddlForms.ClearSelection();
            //    ddlUser.ClearSelection();
            //    txtSequence.Value = "";
            //    return false;
            //}

            SubjectSection activeSubjectSection = new SubjectSection();
            if (ActiveId == 0)
            {
                activeSubjectSection.Id = Convert.ToInt16(activeSubjectSectionDAL.MaxSubjectSectionID().Tables[0].Rows[0][0]);
            }
            else
            {
                activeSubjectSection.Id = ActiveId;
            }

            //activeSubjectSection.Id = Convert.ToInt32(TextBoxSubjectSection.Text);

            //  activeSubjectSection.Id = Convert.ToInt16(hfSubjectSection.Value);
            activeSubjectSection.Section = TextBoxSubjectSection.Text.ToString();

            //if (!string.IsNullOrEmpty(hfSubjectSection.Value))
            //{
            //    activeSubjectSection.Id = Convert.ToInt32(hfSubjectSection.Value);
            //}
            //if (!string.IsNullOrEmpty(TextBoxSubjectSection.Text.ToString()))
            //{
            //    activeSubjectSection.Section = TextBoxSubjectSection.Text.ToString();
            //}
            //else
            //{
            //    _post = false;
            //}

            //_approval.UserID = Convert.ToInt16(ddlUser.SelectedValue);
            //_approval.UserName = ddlUser.SelectedItem.Text;
            //_approval.Sequence = string.IsNullOrEmpty(txtSequence.Value) ? 0 : Convert.ToInt16(txtSequence.Value);
            if (rowIndex >= 0)
            {
                activeSubjectSectionList.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                TextBoxSubjectSection.Text = "";
                //  TextBoxSubjectSection.Text.ToString();
                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";

            }

            activeSubjectSectionList.Add(activeSubjectSection);
            GridViewSection.DataSource = activeSubjectSectionList;
            GridViewSection.DataBind();
            ViewState["SubjectSection"] = activeSubjectSectionList;
            lblMessage.Text = "";
            TextBoxSubjectSection.Text = "";
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;

        }
        protected void GridViewSection_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }

        protected void GridViewSection_RowDataBound(object sender, GridViewRowEventArgs e)
        {
          
        }
        protected void GridViewSection_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewSection_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                SubjectSectionDAL objSubjectSectionDAL = new SubjectSectionDAL();
                //if (iStID > 0)
                //{
                //    objSubjectSectionDAL.SubjectSectionDelete(iStID);
                    GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                    //rowIndex = -1;
                    rowIndex = row.RowIndex;
                    int id = Convert.ToInt32(e.CommandArgument);
                    activeSubjectSectionList = (List<SubjectSection>)ViewState["SubjectSection"];
                    activeSubjectSectionList.RemoveAt(rowIndex);
                    GridViewSection.DataSource = activeSubjectSectionList;
                    GridViewSection.DataBind();
                  //  Response.Redirect("SubjectMasterForm.aspx");
              //  }
            }
            //    if (e.CommandName == "Edit")
            //    {
            //        int iStID = Int32.Parse(e.CommandArgument.ToString());
            //        if (iStID > 0)
            //        {
            //            Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx?Id=" + iStID);
            //        }
            //    }
            //    else
            //    {
            //        int iStID = Int32.Parse(e.CommandArgument.ToString());
            //        SubjectSectionDAL objSubjectSectionDAL = new SubjectSectionDAL();
            //        if (iStID > 0)
            //        {
            //            objSubjectSectionDAL.SubjectSectionDelete(iStID);
            //            Response.Redirect("SubjectMasterForm.aspx");
            //        }
            //    }
        }
        protected void buttonSectionPost_Click(object sender, EventArgs e)
        {
            try
            {
                if (IPost())
                {
                    //GridViewSection.DataSource = null;
                    //GridViewSection.DataBind();
                }
            }
            catch (Exception)
            {
                throw;
            }
        //    try
        //    {
        //        if (IPost())
        //        {
        //            ActiveId = 1;
        //            GridViewSection.DataSource = null;
        //            GridViewSection.DataBind();
        //            GetAllSection();
        //            TextBoxSubjectSection.Text = string.Empty;
        //            //Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx", false);
        //            // Context.ApplicationInstance.CompleteRequest();
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        }




            //******************************************************** TAB 2 ************************************************************//
        //private bool Post()
        //{
        //    bool isPost = true;
        //    SubjectChapterDAL activeSubjectChapterDAL = new SubjectChapterDAL();
        //    SubjectChapter activeSubjectChapter = new SubjectChapter();
        //    if (!string.IsNullOrEmpty(hfSubjectChapter.Value))
        //    {
        //        activeSubjectChapter.Id = Convert.ToInt32(hfSubjectChapter.Value);
        //    }
        //    if (!string.IsNullOrEmpty(TextBoxChapters.Text))
        //    {
        //        activeSubjectChapter.Chapter = TextBoxChapters.Text;
        //    }
        //    else
        //    {
        //        isPost = false;
        //    }
        //    if (isPost == true)
        //    {
        //        if (buttonChapterPost.Text == "Post")
        //        {
        //            UnitId = activeSubjectChapterDAL.SubjectChapterInsert(activeSubjectChapter);
        //          //  Response.Redirect("SubjectMasterForm.aspx");
        //            //GridViewSection.Columns.Clear();
        //        }

        //        else if (buttonChapterPost.Text == "Update")
        //        {
        //            if (activeSubjectChapterDAL.SubjectChapterUpdate(activeSubjectChapter) == true)
        //                isPost = true;
        //          //  Response.Redirect("SubjectMasterForm.aspx");
        //        }
        //    }
        //    return isPost;
        //}

        private bool Post()
        {
            if (TextBoxChapters.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all Fields Correctly";
                return false;
            }
            bool _post = true;
            SubjectChapterDAL activeSubjectChapterDAL = new SubjectChapterDAL();
            List<SubjectChapter> activeSubjectChapterList = new List<SubjectChapter>();
            if (ViewState["SubjectChapter"] != null)
            {
                activeSubjectChapterList = (List<SubjectChapter>)ViewState["SubjectChapter"];
            }

            //var _item = _listApproval.Find(x => x.FormID == Convert.ToInt16(ddlForms.SelectedItem.Value) && x.UserID == Convert.ToInt16(ddlUser.SelectedItem.Value));
            //if (_item != null)
            //{
            //    msgAleart.Visible = true;
            //    lblMessage.Text = "Duplicate Value not Allowed";
            //    ddlForms.ClearSelection();
            //    ddlUser.ClearSelection();
            //    txtSequence.Value = "";
            //    return false;
            //}

            SubjectChapter activeSubjectChapter = new SubjectChapter();
            if (ActiveId == 0)
            {
                activeSubjectChapter.Id = Convert.ToInt16(activeSubjectChapterDAL.MaxSubjectChapterID().Tables[0].Rows[0][0]);
            }
            else
            {
                activeSubjectChapter.Id = ActiveId;
            }

            //activeSubjectSection.Id = Convert.ToInt32(TextBoxSubjectSection.Text);

            //  activeSubjectSection.Id = Convert.ToInt16(hfSubjectSection.Value);
            activeSubjectChapter.Chapter = TextBoxChapters.Text.ToString();

            //if (!string.IsNullOrEmpty(hfSubjectSection.Value))
            //{
            //    activeSubjectSection.Id = Convert.ToInt32(hfSubjectSection.Value);
            //}
            //if (!string.IsNullOrEmpty(TextBoxSubjectSection.Text.ToString()))
            //{
            //    activeSubjectSection.Section = TextBoxSubjectSection.Text.ToString();
            //}
            //else
            //{
            //    _post = false;
            //}

            //_approval.UserID = Convert.ToInt16(ddlUser.SelectedValue);
            //_approval.UserName = ddlUser.SelectedItem.Text;
            //_approval.Sequence = string.IsNullOrEmpty(txtSequence.Value) ? 0 : Convert.ToInt16(txtSequence.Value);
            if (rowIndex >= 0)
            {
                activeSubjectChapterList.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                TextBoxChapters.Text = "";
                //  TextBoxSubjectSection.Text.ToString();
                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";

            }

            activeSubjectChapterList.Add(activeSubjectChapter);
            GridViewChapters.DataSource = activeSubjectChapterList;
            GridViewChapters.DataBind();
            ViewState["SubjectChapter"] = activeSubjectChapterList;
            lblMessage.Text = "";
            TextBoxChapters.Text = "";
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;

        }

        protected void buttonChapterPost_Click(object sender, EventArgs e)
        {
            try
            {
                if (Post())
                {
                    //GridViewSection.DataSource = null;
                    //GridViewSection.DataBind();
                }
            }
            catch (Exception)
            {
                throw;
            }
            //try
            //{
            //    if (Post())
            //    {
            //        ActiveId = 1;
            //        GridViewChapters.DataSource = null;
            //        GridViewChapters.DataBind();
            //        GetAllChapter();
            //        TextBoxChapters.Text = string.Empty;
            //        //  Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx", false);
            //        //Context.ApplicationInstance.CompleteRequest();
            //    }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }
        
        protected void GridViewChapters_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }

        protected void GridViewChapters_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
        protected void GridViewChapters_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewChapters_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    SubjectChapterDAL activeSubjectChapterDAL = new SubjectChapterDAL();
            //    if (iStID > 0)
            //    {
            //        activeSubjectChapterDAL.SubjectChapterDelete(iStID);
            //        //BindFeesMaster();
            //        // loadSession();

            //        Response.Redirect("SubjectMasterForm.aspx");
            //    }
            //}

            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                SubjectChapterDAL objClassSectionFeeDAL = new SubjectChapterDAL();
                //if (iStID > 0)
                //{
                //    objClassSectionFeeDAL.ClassSectionFeeDelete(iStID);
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                activeSubjectChapterList = (List<SubjectChapter>)ViewState["SubjectChapter"];
                activeSubjectChapterList.RemoveAt(rowIndex);
                GridViewChapters.DataSource = activeSubjectChapterList;
                GridViewChapters.DataBind();
                // Response.Redirect("ClassSectionGeneralForm.aspx");
                //  }
            }
        }

        //********************************************************* Tab 3 *************************************************************//

        //private bool TPost()
        //{
        //    bool tPost = true;
        //    SubjectTopicDAL activeSubjectTopicDAL = new SubjectTopicDAL();
        //    SubjectTopic activeSubjectTopic = new SubjectTopic();
        //    if (!string.IsNullOrEmpty(hfSubjectTopic.Value))
        //    {
        //        activeSubjectTopic.Id = Convert.ToInt32(hfSubjectTopic.Value);
        //    }
        //    if (!string.IsNullOrEmpty(TextBoxTopics.Text))
        //    {
        //        activeSubjectTopic.Topic = TextBoxTopics.Text;
        //    }
        //    else
        //    {
        //        tPost = false;
        //    }
        //    if (tPost == true)
        //    {
        //        if (buttonChapterPost.Text == "Post")
        //        {
        //            UnitId = activeSubjectTopicDAL.SubjectTopicInsert(activeSubjectTopic);
        //         //   Response.Redirect("SubjectMasterForm.aspx");
        //            //GridViewSection.Columns.Clear();
        //        }

        //        else if (buttonChapterPost.Text == "Update")
        //        {
        //            if (activeSubjectTopicDAL.SubjectTopicUpdate(activeSubjectTopic) == true)
        //                tPost = true;
        //      //      Response.Redirect("SubjectMasterForm.aspx");
        //        }
        //    }
        //    return tPost;
        //}

        private bool TPost()
        {
            if (TextBoxTopics.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all Fields Correctly";
                return false;
            }
            bool _post = true;
            SubjectTopicDAL activeSubjectTopicDAL = new SubjectTopicDAL();
            List<SubjectTopic> activeSubjectTopicList = new List<SubjectTopic>();
            if (ViewState["SubjectTopic"] != null)
            {
                activeSubjectTopicList = (List<SubjectTopic>)ViewState["SubjectTopic"];
            }

            //var _item = _listApproval.Find(x => x.FormID == Convert.ToInt16(ddlForms.SelectedItem.Value) && x.UserID == Convert.ToInt16(ddlUser.SelectedItem.Value));
            //if (_item != null)
            //{
            //    msgAleart.Visible = true;
            //    lblMessage.Text = "Duplicate Value not Allowed";
            //    ddlForms.ClearSelection();
            //    ddlUser.ClearSelection();
            //    txtSequence.Value = "";
            //    return false;
            //}

            SubjectTopic activeSubjectTopic = new SubjectTopic();
            if (ActiveId == 0)
            {
                activeSubjectTopic.Id = Convert.ToInt16(activeSubjectTopicDAL.MaxSubjectTopicID().Tables[0].Rows[0][0]);
            }
            else
            {
                activeSubjectTopic.Id = ActiveId;
            }

            //activeSubjectSection.Id = Convert.ToInt32(TextBoxSubjectSection.Text);

            //  activeSubjectSection.Id = Convert.ToInt16(hfSubjectSection.Value);
            activeSubjectTopic.Topic = TextBoxTopics.Text.ToString();

            //if (!string.IsNullOrEmpty(hfSubjectSection.Value))
            //{
            //    activeSubjectSection.Id = Convert.ToInt32(hfSubjectSection.Value);
            //}
            //if (!string.IsNullOrEmpty(TextBoxSubjectSection.Text.ToString()))
            //{
            //    activeSubjectSection.Section = TextBoxSubjectSection.Text.ToString();
            //}
            //else
            //{
            //    _post = false;
            //}

            //_approval.UserID = Convert.ToInt16(ddlUser.SelectedValue);
            //_approval.UserName = ddlUser.SelectedItem.Text;
            //_approval.Sequence = string.IsNullOrEmpty(txtSequence.Value) ? 0 : Convert.ToInt16(txtSequence.Value);
            if (rowIndex >= 0)
            {
                activeSubjectTopicList.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                TextBoxTopics.Text = "";
                //  TextBoxSubjectSection.Text.ToString();
                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";

            }

            activeSubjectTopicList.Add(activeSubjectTopic);
            GridViewTopics.DataSource = activeSubjectTopicList;
            GridViewTopics.DataBind();
            ViewState["SubjectTopic"] = activeSubjectTopicList;
            lblMessage.Text = "";
            TextBoxTopics.Text = "";
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;

        }
        protected void buttonTopicsPost_Click(object sender, EventArgs e)
        {
            try
            {
                if (TPost())
                {
                    //GridViewSection.DataSource = null;
                    //GridViewSection.DataBind();
                }
            }
            catch (Exception)
            {
                throw;
            }
            //try
            //{
            //    if (TPost())
            //    {
            //        ActiveId = 1;
            //        GridViewTopics.DataSource = null;
            //        GridViewTopics.DataBind();
            //        GetAllTopic();
            //        TextBoxTopics.Text = string.Empty;
            //        //ActiveId = 0;
            //        //  Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx", false);
            //        //  Context.ApplicationInstance.CompleteRequest();
            //    }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }
        protected void GridViewTopics_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }

        protected void GridViewTopics_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
        protected void GridViewTopics_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewTopics_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    SubjectTopicDAL objSubjectTopicDAL = new SubjectTopicDAL();
            //    if (iStID > 0)
            //    {
            //        objSubjectTopicDAL.SubjectTopicDelete(iStID);

            //        Response.Redirect("SubjectMasterForm.aspx");
            //    }
            //}

            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                SubjectTopicDAL objClassSectionFeeDAL = new SubjectTopicDAL();
                //if (iStID > 0)
                //{
                //    objClassSectionFeeDAL.ClassSectionFeeDelete(iStID);
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                activeSubjectTopicList = (List<SubjectTopic>)ViewState["SubjectTopic"];
                activeSubjectTopicList.RemoveAt(rowIndex);
                GridViewTopics.DataSource = activeSubjectTopicList;
                GridViewTopics.DataBind();
                // Response.Redirect("ClassSectionGeneralForm.aspx");
                //  }
            }
        }
        
        protected void GridViewSection_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
       
    }
}