﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI;
using System.Configuration;
using EntityLayer;
using System.Data;
using DataAccessLayer;
using System.Data.SqlClient;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class FamilyMasterForm : System.Web.UI.Page
    {
        public int ActiveId;
        public int getid;
        public int UnitId;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Initilaize();
                GetId();
                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {

                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    FamilyMasterSave.Text = "Update";
                    ActiveId = 1;
                    Initilaize();
                    GetId();
                }
                else
                {
                    FamilyMasterSave.Text = "Save";
                    ActiveId = 0;
                    Clear();
                }
            }
        }
     
        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);
                }
            }
            catch
            {
                MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }

        public void UpdateData(int Id)
        {
            try
            {
                FamilyMasterDAL activeFamilyMasterDAL = new FamilyMasterDAL();
                FamilyMaster activeFamilyMaster = activeFamilyMasterDAL.FamilyMasterGetById(Id);
                if (activeFamilyMaster != null)
                {
                    HiddenFieldFamilyMaster.Value = activeFamilyMaster.Id.ToString();
                    txtFamilyMasterCode.Attributes.Add("value", activeFamilyMaster.Code);
                    txtFamilyMasterDescription.Text = activeFamilyMaster.Description;
                    TextBoxFamilyRemarks.Text = activeFamilyMaster.Remarks;
                    CheckBoxFamilyMaster.Checked = Convert.ToBoolean(activeFamilyMaster.Active);
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        public void Initilaize()
        {
            try
            {
                FamilyMasterDAL activeFamilyMasterDAL = new FamilyMasterDAL();
                FamilyMaster activeMemberMaxId = activeFamilyMasterDAL.FamilyMasterGetMaxId();
                string caption = "FM-00001";
                if (activeMemberMaxId != null)
                {
                    string theString = activeMemberMaxId.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtFamilyMasterCode.Value = "FM-0000" + code.ToString();
                }
                else
                {
                    txtFamilyMasterCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        public void Clear()
        {
            try
            {
                ActiveId = 0;

                txtFamilyMasterDescription.Text = string.Empty;
                TextBoxFamilyRemarks.Text = string.Empty;
                CheckBoxFamilyMaster.Checked = false;
                HiddenFieldFamilyMaster.Value = string.Empty;
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        public bool Save()
        {
            bool IsSave = true;

            FamilyMasterDAL activeFamilyMasterDAL = new FamilyMasterDAL();
            FamilyMaster activeFamilyMaster = new FamilyMaster();

            if (!string.IsNullOrEmpty(HiddenFieldFamilyMaster.Value))
            {
                activeFamilyMaster.Id = Convert.ToInt32(HiddenFieldFamilyMaster.Value);
            }

            if (!string.IsNullOrEmpty(txtFamilyMasterDescription.Text))
            {
                activeFamilyMaster.Description = txtFamilyMasterDescription.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxFamilyRemarks.Text))
            {
                activeFamilyMaster.Remarks = TextBoxFamilyRemarks.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(txtFamilyMasterCode.Value))
            {
                activeFamilyMaster.Code = txtFamilyMasterCode.Value;
            }
            else
            {
                IsSave = false;
            }
            activeFamilyMaster.Active = CheckBoxFamilyMaster.Checked;

            if (IsSave == true)
            {
                if (FamilyMasterSave.Text == "Save")
                {
                    UnitId = activeFamilyMasterDAL.FamilyMasterInsert(activeFamilyMaster);
                    Response.Redirect("ListOfFamilyMaster.aspx");
                }
                else if (FamilyMasterSave.Text == "Update")
                {
                    if (activeFamilyMasterDAL.FamilyMasterUpdate(activeFamilyMaster) == true)

                        IsSave = true;
                    Response.Redirect("ListOfFamilyMaster.aspx");
                }
            }
            return IsSave;
        }
      
        protected void FamilyMasterSave_Click(object sender, EventArgs e)
        {
                try
                {
                    if (Save())
                    {
                        Clear();
                        Response.Redirect("ListOfFamilyMaster.aspx");
                    }
                }
                catch (Exception ex)
                {
                    Messages.ErrorMessage(ex.ToString());

                }
        }

        protected void FamilyMasterClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}