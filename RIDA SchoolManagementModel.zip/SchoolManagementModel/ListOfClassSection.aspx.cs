﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfClassSection : System.Web.UI.Page
    {
        ClassSectionDAL objClassSectionDAL = new ClassSectionDAL();
        ClassSection objClassSection = new ClassSection();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void bindtreeview()
        {
            DataTable dt = objClassSectionDAL.GetData("SELECT * From  ClassSection");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["id"].ToString()
                };
                if (parentId == 0)
                {
                    TreeViewClassSection.Nodes.Add(child);
                    dtChild = objClassSectionDAL.GetData("SELECT * From  ClassSection");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = objClassSectionDAL.GetData("SELECT * From  ClassSection");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }
        protected void GridViewListofClassSection_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridViewListofClassSection_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewListofClassSection_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/ClassSectionGeneralForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                ClassSectionDAL objClassSectionDAL = new ClassSectionDAL();
                objClassSectionDAL.ClassSectionDelete(iStID);
                //   BindFeesMaster();
                // loadSession();
                Response.Redirect("ListofClassSection.aspx");
                bindtreeview();
            }
        }

        protected void TreeViewClassSection_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}