﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI;
using System.Configuration;
using EntityLayer;
using System.Data;
using DataAccessLayer; 
using System.Data.SqlClient;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class DegreeForm : System.Web.UI.Page
    {
        public int ActiveId;
        public int getid;
        public int UnitId;
        public string IdCode { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {

                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    savebtn.Text = "Update";
                    ActiveId = 1;
                  //  UpdateData(getid);
                   // Initialize();
                    Initilaize();
                    GetId();
                }
                else
                {
                    savebtn.Text = "Save";
                    ActiveId = 0;
                    Clear();
                }
            }

        }
        public void UpdateData(int Id)
        {
            try
            {
                DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
                DegreeLevel activeDegreeLevel = activeDegreeDAL.DegreeLevelGetById(Id);
                if (activeDegreeLevel != null)
                {

                    HiddenFieldDegree.Value = activeDegreeLevel.Id.ToString();
                    txtDegreeCode.Attributes.Add("value", activeDegreeLevel.Code);
                    degreeDescription.Text = activeDegreeLevel.Description;

                    ActiveYear.Checked = Convert.ToBoolean(activeDegreeLevel.Active);

                   
                }

            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        //public void Initialize()
        //{
        //    try
        //    {
        //        DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
        //        DegreeLevel activeMemberMaxId = activeDegreeDAL.DegreeLevelGetMaxId();
        //        string caption = "AS-00001";
        //        if (activeMemberMaxId != null)
        //        {
        //            string theString = activeMemberMaxId.Code;
        //            var subString = theString.Substring(theString.LastIndexOf('-') + 1);
        //            int add = Convert.ToInt32(subString);
        //            int code = add + 1;

        //            IdCode = "AS-0000" + code.ToString();
        //        }
        //        else
        //        {
        //            IdCode = caption;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //}


        protected void txtAcdmicCode_TextChanged(object sender, EventArgs e)
        {

        }

        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);

                }
            }
            catch
            {
                MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }

        protected void save_btn(object sender, EventArgs e)
        {
            {
                try
                {
                    if (Save())
                    {
                        Clear();
                        //BindUnit();
                        Response.Redirect("ListDegreeForm.aspx");
                    }
                }
                catch (Exception ex)
                {
                    Messages.ErrorMessage(ex.ToString());

                }
            }

        }

        //public bool Save()
        //{

        //    bool IsSave = true;


        //    DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
        //    DegreeLevel activeDegreeLevel = new DegreeLevel();

        //    if (!string.IsNullOrEmpty(HiddenFieldDegree.Value))
        //    {
        //        activeDegreeLevel.Id = Convert.ToInt32(HiddenFieldDegree.Value);
        //    }




        //    if (!string.IsNullOrEmpty(degreeDescription.Text))
        //    {
        //        activeDegreeLevel.Description = degreeDescription.Text;

        //    }
        //    else
        //    {
        //        //  errorProviderDis.SetError(txtDescription, "Enter The Job Name");
        //        IsSave = false;
        //    }
        //    if (!string.IsNullOrEmpty(txtDegreeCode.Text))
        //    {
        //        activeDegreeLevel.Code = txtDegreeCode.Text;

        //    }
        //    else
        //    {


        //        //errorProviderDis.SetError(txtCode, "Enter The Job Code ");
        //        IsSave = false;
        //    }

        //    activeDegreeLevel.Active = ActiveYear.Checked;

        //    if (IsSave == true)
        //    {
        //        if (savebtn.Text == "Save")
        //        {
        //           // UnitId = activeDegreeDAL.DegreeLevelInsert(activeDegreeLevel);
        //            Response.Redirect("ListDegreeForm.aspx");
        //        }
        //        else if (savebtn.Text == "Update")
        //        {
        //            if (activeDegreeDAL.DegreeLevelUpdate(activeDegreeLevel) == true)

        //                IsSave = true;
        //            Response.Redirect("ListDegreeForm.aspx");
        //        }
        //    }

        //    return IsSave;
        //}

        public bool Save()
        {

            bool IsSave = true;


            DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
            DegreeLevel activeDegree = new DegreeLevel();

            if (!string.IsNullOrEmpty(HiddenFieldDegree.Value))
            {
                activeDegree.Id = Convert.ToInt32(HiddenFieldDegree.Value);
            }




            if (!string.IsNullOrEmpty(degreeDescription.Text))
            {
                activeDegree.Description = degreeDescription.Text;

            }
            else
            {
                //  errorProviderDis.SetError(txtDescription, "Enter The Job Name");
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(txtDegreeCode.Value))
            {
                activeDegree.Code = txtDegreeCode.Value;

            }
            else
            {


                //errorProviderDis.SetError(txtCode, "Enter The Job Code ");
                IsSave = false;
            }


            activeDegree.Active = ActiveYear.Checked;
 
            if (IsSave == true)
            {
                if (savebtn.Text == "Save")
                {
                    UnitId = activeDegreeDAL.DegreeLevelInsert(activeDegree);
                    Response.Redirect("ListDegreeForm.aspx");
                }

                else if (savebtn.Text == "Update")
                {
                    if (activeDegreeDAL.DegreeLevelUpdate(activeDegree) == true)

                        IsSave = true;
                    Response.Redirect("ListDegreeForm.aspx");
                }
            }

            return IsSave;
        }


        protected void Clear_btn(object sender, EventArgs e)
        {
            Clear();
        }

        public void Clear()
        {
            try
            {
                ActiveId = 0;

                degreeDescription.Text = string.Empty;

               

                ActiveYear.Checked = false;


                HiddenFieldDegree.Value = string.Empty;
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        public void Initilaize()
        {
            try
            {
                DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
                DegreeLevel activeMemberMaxId = activeDegreeDAL.DegreeLevelGetMaxId();
                string caption = "DS-00001";
                if (activeMemberMaxId != null)
                {
                    string theString = activeMemberMaxId.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtDegreeCode.Value = "DS-0000" + code.ToString();
                }
                else
                {
                    txtDegreeCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        protected void degreeDescription_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}