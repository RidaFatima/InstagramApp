﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;


namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ClassSectionGeneralForm : System.Web.UI.Page
    {
        public int getid;
        public int UnitId;
        public static int ActiveId { get; set; }
        public static int rowIndex { get; set; }
        List<ClassSectionFee> activeClassSectionFeeList = new List<ClassSectionFee>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rowIndex = -1;
                ViewState["ClassSectionFee"] = new List<ClassSectionFee>();
                
                Initilaize();
                BindFeesMaster();
                BindClassSession();
                ViewState["ClassSectionFee"] = ActiveId;
                GetAllFee();
                GetId();
               
                ViewState["ClassSectionFee"] = null;
                GridViewFeeID.DataBind();
                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    ClassSectionSave.Text = "Update";
                    ActiveId = 1;
                }
                else
                {
                    ViewState["ClassSectionFee"] = (List<ClassSectionFee>)null;
                    ClassSectionSave.Text = "Save";
                    ActiveId = 0;
                    Clear();
                    GridViewFeeID.DataBind(); 
                }
            }
        }
        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);
                }
            }
            catch
            {
                //  MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }

        public void UpdateData(int Id)
        {
            try
            {
                ClassSectionDAL objClassSectionDAL = new ClassSectionDAL();
                ClassSection objClassSection = objClassSectionDAL.ClassSectionGetById(Id);
                if (objClassSection != null)
                {

                    hfClassSection.Value = objClassSection.Id.ToString();
                    txtClassSectionCode.Attributes.Add("value", objClassSection.Code);
                    txtClassSectionDescription.Text = objClassSection.Description;
                    ddlClassSession.SelectedItem.Text = objClassSection.Session;
                    ddlFeeMaster.SelectedItem.Text = objClassSection.Fee;        
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
     
        public void Clear()
        {
            //try
            //{
            //    ActiveId = 0;

            //    txtClassSectionDescription.Text = string.Empty;

            //    ddlClassSession.SelectedIndex = 0;
            //    ddlFeeMaster.SelectedIndex=0;
            //    GridViewFeeID.DataSource = string.Empty;
            //    GridViewFeeID.DataBind();
            //    ViewState["ClassSectionFee"] = (List<ClassSectionFee>)null;
            //    ActiveId = 0;
            //    Initilaize();
            //}
            //catch (Exception ex)
            //{
            //    Messages.ErrorMessage(ex.ToString());

            //}

            ClassSectionFeeDAL objFee = new ClassSectionFeeDAL();
            DataSet ds = objFee.GetALlFee();
            ViewState["ClassSectionFee"] = null;
            ds.Clear();
            GridViewFeeID.DataBind();
            ActiveId = 0;
            Initilaize();
          //  AllClear();

        }
     
        public void BindClassSession()
        {
            try
            {
                ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
                List<ClassSession> activeClassSessionIdList = objClassSessionDAL.ClassSessionSelect();
                ClassSession objClassSession = new ClassSession();
                if (activeClassSessionIdList != null)
                {
                    objClassSession.Id = 0;
                    objClassSession.Description = "None";
                    activeClassSessionIdList.Insert(0, objClassSession);
                    ddlClassSession.DataSource = activeClassSessionIdList;
                    ddlClassSession.DataValueField = "Id";
                    ddlClassSession.DataTextField = "Description";
                    ddlClassSession.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
 
        public void BindFeesMaster()
        {
            try
            {
                FeesMasterDAL objFeesMasterDAL = new FeesMasterDAL();
                List<FeesMaster> activeFeesMasterIdList = objFeesMasterDAL.FeesMasterSelect();
                FeesMaster objFeesMaster = new FeesMaster();
                if (activeFeesMasterIdList != null)
                {
                    objFeesMaster.Id = 0;
                    objFeesMaster.Description = "None";
                    activeFeesMasterIdList.Insert(0, objFeesMaster);
                    ddlFeeMaster.DataSource = activeFeesMasterIdList;
                    ddlFeeMaster.DataValueField = "Id";
                    ddlFeeMaster.DataTextField = "Description";
                    ddlFeeMaster.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void Initilaize()
        {
            try
            {
                ClassSectionDAL objClassSectionDAL = new ClassSectionDAL();
                ClassSection objClassSection = objClassSectionDAL.ClassSectionGetMaxId();
                string caption = "CS-00001";
                if (objClassSection != null)
                {
                    string theString = objClassSection.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtClassSectionCode.Value = "CS-0000" + code.ToString();
                }
                else
                {
                    txtClassSectionCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
        protected void ClassSectionSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    ActiveId = 0;
                    Response.Redirect("~/SchoolManagementModel/ListofClassSection.aspx", false);
                    Context.ApplicationInstance.CompleteRequest();
                    // GridViewFee.DataSource = null;
                }
            }
            catch (Exception)
            {
                //     throw;
            }
        }
       
        private bool Save()
        {
            bool IsSave = true;

            ClassSectionDAL objClassSectionDAL = new ClassSectionDAL();
            ClassSection objClassSection = new ClassSection();

            if (!string.IsNullOrEmpty(hfClassSection.Value))
            {
                objClassSection.Id = Convert.ToInt32(hfClassSection.Value);
            }
            if (!string.IsNullOrEmpty(txtClassSectionDescription.Text))
            {
                objClassSection.Description = txtClassSectionDescription.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(txtClassSectionCode.Value))
            {
                objClassSection.Code = txtClassSectionCode.Value;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlClassSession.Text))
            {
                objClassSection.Session = ddlClassSession.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlFeeMaster.SelectedItem.Text))
            {
                objClassSection.Fee = ddlFeeMaster.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }

            if (IsSave == true)
            {
                if (ClassSectionSave.Text == "Save")
                {
                    UnitId = objClassSectionDAL.ClassSectionInsert(objClassSection);
                    Response.Redirect("ListofClassSection.aspx");
                }

                else if (ClassSectionSave.Text == "Update")
                {
                    if (objClassSectionDAL.ClassSectionUpdate(objClassSection) == true)
                        IsSave = true;
                    Response.Redirect("ListofClassSection.aspx");
                }
            }
            return IsSave;
        }

        public bool Post()
        {
            if (ddlFeeMaster.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all Fields Correctly";
                return false;
            }
            bool _post = true;
            ClassSectionFeeDAL activeClassSectionFeeDAL = new ClassSectionFeeDAL();
            List<ClassSectionFee> activeClassSectionFeeList = new List<ClassSectionFee>();
            if (ViewState["ClassSectionFee"] != null)
            {
                activeClassSectionFeeList = (List<ClassSectionFee>)ViewState["ClassSectionFee"];
            }

            //var _item = _listApproval.Find(x => x.FormID == Convert.ToInt16(ddlForms.SelectedItem.Value) && x.UserID == Convert.ToInt16(ddlUser.SelectedItem.Value));
            //if (_item != null)
            //{
            //    msgAleart.Visible = true;
            //    lblMessage.Text = "Duplicate Value not Allowed";
            //    ddlForms.ClearSelection();
            //    ddlUser.ClearSelection();
            //    txtSequence.Value = "";
            //    return false;
            //}
            ClassSectionFee _approval = new ClassSectionFee();
            if (ActiveId == 0)
            {
                _approval.Id = Convert.ToInt16(activeClassSectionFeeDAL.MaxClassSectionFeeID().Tables[0].Rows[0][0]);
            }
            else
            {
                _approval.Id = ActiveId;
            }

            _approval.Id = Convert.ToInt16(ddlFeeMaster.SelectedValue);
            _approval.Fee = ddlFeeMaster.SelectedItem.Text;
            //_approval.UserID = Convert.ToInt16(ddlUser.SelectedValue);
            //_approval.UserName = ddlUser.SelectedItem.Text;
            //_approval.Sequence = string.IsNullOrEmpty(txtSequence.Value) ? 0 : Convert.ToInt16(txtSequence.Value);
            if (rowIndex >= 0)
            {
                activeClassSectionFeeList.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                ddlFeeMaster.ClearSelection();
                //  ddlUser.ClearSelection();
                // txtSequence.Value = ""; 

            }

            activeClassSectionFeeList.Add(_approval);
            GridViewFeeID.DataSource = activeClassSectionFeeList;
            GridViewFeeID.DataBind();
            ViewState["ClassSectionFee"] = activeClassSectionFeeList;
            lblMessage.Text = "";
            ddlFeeMaster.ClearSelection();
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;
        }

        private bool IPost()
        {
            bool IsPost = true;

            ClassSectionFeeDAL activeClassSectionFeeDAL = new ClassSectionFeeDAL();
            ClassSectionFee activeClassSectionFee = new ClassSectionFee();

            if (ActiveId == 0)
            {
                activeClassSectionFee.Id = Convert.ToInt16(activeClassSectionFeeDAL.MaxClassSectionFeeID().Tables[0].Rows[0][0]);
            }
            else
            {
                activeClassSectionFee.Id = ActiveId;
            }

            if (!string.IsNullOrEmpty(hfClassSectionFee.Value))
            {
                activeClassSectionFee.Id = Convert.ToInt32(hfClassSectionFee.Value);
            }

            if (!string.IsNullOrEmpty(ddlFeeMaster.Text))
            {
                activeClassSectionFee.Fee = ddlFeeMaster.SelectedItem.Text;

            }
            else
            {
                IsPost = false;
            }

            if (rowIndex >= 0)
            {
                activeClassSectionFeeList.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                ddlFeeMaster.ClearSelection();
                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";
            }

            if (IsPost == true)
            {
                if (buttonFeeIDPost.Text == "Post")
                {
                    UnitId = activeClassSectionFeeDAL.ClassSectionFeeInsert(activeClassSectionFee);
                    // Response.Redirect("SubjectMasterForm.aspx");
                    //GridViewSection.Columns.Clear();
                }

                else if (buttonFeeIDPost.Text == "Update")
                {
                    if (activeClassSectionFeeDAL.ClassSectionFeeUpdate(activeClassSectionFee) == true)
                        IsPost = true;
                    //  Response.Redirect("SubjectMasterForm.aspx");
                }
            }

            return IsPost;
        }

        
        private void GetAllFee()
        {
            ClassSectionFeeDAL objFee = new ClassSectionFeeDAL();
            DataSet ds = objFee.GetALlFee();
            if (ds != null)
            {
                GridViewFeeID.DataSource = ds;
                GridViewFeeID.DataBind();
            }
            else
            {
                GridViewFeeID.DataSource = null;
                GridViewFeeID.DataBind();
            }
        }
        protected void ClassSectionClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private bool ISave()
        {
            bool isSave = true;


            ChallanDescriptionDAL objChallanDescriptionDAL = new ChallanDescriptionDAL();
            ChallanDescription objChallanDescription = new ChallanDescription();

            if (!string.IsNullOrEmpty(hfChallanDescription.Value))
            {
                objChallanDescription.Id = Convert.ToInt32(hfChallanDescription.Value);
            }

            if (!string.IsNullOrEmpty(txtClassSectionPayment.Text))
            {
                objChallanDescription.PaymentTerm = txtClassSectionPayment.Text;
            }
            else
            {
                isSave = false;
            }

            if (!string.IsNullOrEmpty(BankName.Text))
            {
                objChallanDescription.BankName = BankName.Text;
            }
            else
            {
                isSave = false;
            }

            if (!string.IsNullOrEmpty(TextBoxAccountTitle.Text))
            {
                objChallanDescription.AccountTitle = TextBoxAccountTitle.Text.ToString();
            }
            else
            {
                isSave = false;
            }

            if (!string.IsNullOrEmpty(TextBoxBranchName.Text))
            {
                objChallanDescription.BranchName = TextBoxBranchName.Text.ToString();
            }
            else
            {
                isSave = false;
            }

            if (!string.IsNullOrEmpty(TextBoxAccountPayment.Text))
            {
                objChallanDescription.ModeOfPayment = TextBoxAccountPayment.Text.ToString();
            }
            else
            {
                isSave = false;
            }

            if (!string.IsNullOrEmpty(TextBoxRemarks1.Text))
            {
                objChallanDescription.Remarks = TextBoxRemarks1.Text.ToString();
            }
            else
            {
                isSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxRemarks2.Text))
            {
                objChallanDescription.Remark = TextBoxRemarks2.Text.ToString();
            }
            else
            {
                isSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxRemarks3.Text))
            {
                objChallanDescription.Remaark = TextBoxRemarks3.Text.ToString();
            }
            else
            {
                isSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxRemarks4.Text))
            {
                objChallanDescription.Remaarks = TextBoxRemarks4.Text.ToString();
            }
            else
            {
                isSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxRemarks5.Text))
            {
                objChallanDescription.Remarrk = TextBoxRemarks5.Text.ToString();
            }
            else
            {
                isSave = false;
            }

            if (isSave == true)
            {
                if (ButtonApplyToAll.Text == "Apply To All")
                {
                    UnitId = objChallanDescriptionDAL.ChallanDescriptionInsert(objChallanDescription);
                    Response.Redirect("ListOfChallanDescription.aspx");
                }

                else if (ButtonApplyToAll.Text == "Apply To All")
                {
                    if (objChallanDescriptionDAL.ChallanDescriptionUpdate(objChallanDescription) == true)

                        isSave = true;
                    Response.Redirect("ListOfChallanDescription.aspx");
                }
            }

            return isSave;
        }
   
        protected void ButtonApplyToAll_Click(object sender, EventArgs e)
        {
            try
            {
                if (ISave())
                {
                    ActiveId = 0;
                    Response.Redirect("~/SchoolManagementModel/ListOfChallanDescription.aspx", false);
                    Context.ApplicationInstance.CompleteRequest();
                    // GridViewFee.DataSource = null;
                }
            }
            catch (Exception)
            {
                     throw;
            }
        }
        protected void buttonFeeIDPost_Click(object sender, EventArgs e)
        {
            if (Post())
            {
                ActiveId = 0;
            }

            //try
            //{
            //    if (IPost())
            //    {
            //        ActiveId = 1;
            //        GridViewFeeID.DataSource = null;
            //        GridViewFeeID.DataBind();
            //        GetAllFee();
            //        // ddlFeeMaster.SelectedIndex = 0;
            //        //Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx", false);
            //        // Context.ApplicationInstance.CompleteRequest();
            //    }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }
        protected void GridViewFeeID_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewFeeID_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewFeeID_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/ClassSectionGeneralForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    ClassSectionFeeDAL objClassSectionFeeDAL = new ClassSectionFeeDAL();
            //    if (iStID > 0)
            //    {
            //        objClassSectionFeeDAL.ClassSectionFeeDelete(iStID);
            //        Response.Redirect("ClassSectionGeneralForm.aspx");
            //    }
            //}

            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                ClassSectionFeeDAL objClassSectionFeeDAL = new ClassSectionFeeDAL();
                //if (iStID > 0)
                //{
                //    objClassSectionFeeDAL.ClassSectionFeeDelete(iStID);
                    GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                    rowIndex = row.RowIndex;
                    int id = Convert.ToInt32(e.CommandArgument);
                    activeClassSectionFeeList = (List<ClassSectionFee>)ViewState["ClassSectionFee"];
                    activeClassSectionFeeList.RemoveAt(rowIndex);
                    GridViewFeeID.DataSource = activeClassSectionFeeList;
                    GridViewFeeID.DataBind();
                   // Response.Redirect("ClassSectionGeneralForm.aspx");
              //  }
            }

        }
        protected void GridViewFeeID_RowDataBound(object sender, GridViewRowEventArgs e)
        {
        }
   
        protected void GridViewFeeID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ButtonGetSetUP_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/SchoolManagementModel/StudentMasterForm.aspx", false);
            Context.ApplicationInstance.CompleteRequest();
        }
    }
}