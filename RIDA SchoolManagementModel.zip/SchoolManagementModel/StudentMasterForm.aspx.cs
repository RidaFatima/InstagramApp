﻿using DataAccessLayer;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web;
using System.Text.RegularExpressions;


namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class StudentMasterForm : System.Web.UI.Page
    {
        public static int ActiveId { get; set; }
        public static int rowIndex { get; set; }
        public static string FileName { get; set; }
        public static string Code = null;

        public int getid;
        public int UnitId;
        List<StudentMaster> activeStudentMasterIdList = new List<StudentMaster>();
        StudentMasterDAL objStudentMasterDAL = new StudentMasterDAL();
        List<ClassSectionFee> activeClassSectionFeeList = new List<ClassSectionFee>();
        List<StudentMasterContact> activeStudentMasterContactList = new List<StudentMasterContact>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rowIndex = -1;
                GetAllFee();
                BindFeesMaster();
                BindClassSession();
                BindLeavingClass();
                BindJoiningClass();
                BindAccount();
                BindFamilyMaster();
                BindTransportMaster();
                GetAllContact();
                BindRelationMaster();
                UploadDocuments(ActiveId);
                //TabStudentMaster.CssClass = "Clicked";
                //MainView.ActiveViewIndex = 0;


                string[] filePaths = Directory.GetFiles(Server.MapPath("~/ProductIMG/"));
                List<ListItem> files = new List<ListItem>();
                foreach (string filePath in filePaths)
                {
                    string fileName = Path.GetFileName(filePath);
                    files.Add(new ListItem(fileName, "~/ProductIMG/" + fileName));
                }

                Initilaize();
                GetId();

                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    StudentMasterSave.Text = "Update";
                    ActiveId = 1;
                    if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.ContentLength > 0)
                    {
                        FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                        FileUpload1.SaveAs(Server.MapPath("~/ProductIMG/" + FileName));
                        this.studentphoto.ImageUrl = "~/ProductIMG/" + FileName;
                    }

                }
                else
                {
                    StudentMasterSave.Text = "Save";
                    ActiveId = 0;
                //    Clear();
                }

                }
            }        
        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);
                }
            }
            catch
            {
                //  MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }

        public void BindClassSession()
        {
            try
            {
                ClassSectionDAL objClassSectionDAL = new ClassSectionDAL();
                List<ClassSection> activeClassSectionIdList = objClassSectionDAL.ClassSectionSelect();
                ClassSection objClassSection = new ClassSection();
                if (activeClassSectionIdList != null)
                {
                    objClassSection.Id = 0;
                    objClassSection.Description = "None";
                    activeClassSectionIdList.Insert(0, objClassSection);
                    ddlClassSection.DataSource = activeClassSectionIdList;
                    ddlClassSection.DataValueField = "Id";
                    ddlClassSection.DataTextField = "Description";
                    ddlClassSection.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        public void BindAccount()
        {
            try
            {
                ChartofAccountDAL ActiveAccountDAL = new ChartofAccountDAL();
                List<ChartofAccount> ActiveListacc = ActiveAccountDAL.ChartofAccountSelect();
                ChartofAccount activeAccount = new ChartofAccount();
                if (ActiveListacc != null)
                {
                    activeAccount.Id = 0;
                    activeAccount.AccountName = "None";
                    ActiveListacc.Insert(0, activeAccount);
                    ddlAccountCode.DataSource = ActiveListacc;
                    ddlAccountCode.DataValueField = "Id";
                    ddlAccountCode.DataTextField = "AccountName";
                    ddlAccountCode.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindTransportMaster()
        {
            try
            {
                TransportMasterDAL ActiveTransportDAL = new TransportMasterDAL();
                List<TransportMaster> ActiveTransportMasterList = ActiveTransportDAL.TransportMasterSelect();
                TransportMaster activeTransportMaster = new TransportMaster();
                if (ActiveTransportMasterList != null)
                {
                    activeTransportMaster.Id = 0;
                    activeTransportMaster.Description = "None";
                    ActiveTransportMasterList.Insert(0, activeTransportMaster);
                    ddlTransportId.DataSource = ActiveTransportMasterList;
                    ddlTransportId.DataValueField = "Id";
                    ddlTransportId.DataTextField = "Description";
                    ddlTransportId.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindFamilyMaster()
        {
            try
            {
                FamilyMasterDAL ActiveFamilydal = new FamilyMasterDAL();
                List<FamilyMaster> ActiveFamilyMasterList = ActiveFamilydal.FamilyMasterSelect();
                FamilyMaster activeFamilyMaster = new FamilyMaster();
                if (ActiveFamilyMasterList != null)
                {
                    activeFamilyMaster.Id = 0;
                    activeFamilyMaster.Description = "None";
                    ActiveFamilyMasterList.Insert(0, activeFamilyMaster);
                    ddlFamilyId.DataSource = ActiveFamilyMasterList;
                    ddlFamilyId.DataValueField = "Id";
                    ddlFamilyId.DataTextField = "Description";
                    ddlFamilyId.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindRelationMaster()
        {
            try
            {
                RelationTypeDAL ActiveDAL = new RelationTypeDAL();
                List<RelationType> ActiveRelationTypeList = ActiveDAL.RelationTypeSelect();
                RelationType activeRelationType = new RelationType();
                if (ActiveRelationTypeList != null)
                {
                    activeRelationType.Id = 0;
                    activeRelationType.Description = "None";
                    ActiveRelationTypeList.Insert(0, activeRelationType);
                    ddlRelationType.DataSource = ActiveRelationTypeList;
                    ddlRelationType.DataValueField = "Id";
                    ddlRelationType.DataTextField = "Description";
                    ddlRelationType.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        public void BindJoiningClass()
        {
            try
            {
                ClassSectionDAL objClassSectnDAL = new ClassSectionDAL();
                List<ClassSection> activeClassSectnIdList = objClassSectnDAL.ClassSectionSelect();
                ClassSection objClassSectn = new ClassSection();
                if (activeClassSectnIdList != null)
                {
                    objClassSectn.Id = 0;
                    objClassSectn.Description = "None";
                    activeClassSectnIdList.Insert(0, objClassSectn);
                    ddlclassSections.DataSource = activeClassSectnIdList;
                    ddlclassSections.DataValueField = "Id";
                    ddlclassSections.DataTextField = "Description";
                    ddlclassSections.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindLeavingClass()
        {
            try
            {
                ClassSectionDAL objClassSectiondal = new ClassSectionDAL();
                List<ClassSection> activeClassSectionList = objClassSectiondal.ClassSectionSelect();
                ClassSection objClassSections = new ClassSection();
                if (activeClassSectionList != null)
                {
                    objClassSections.Id = 0;
                    objClassSections.Description = "None";
                    activeClassSectionList.Insert(0, objClassSections);
                    ddlclasSecTion.DataSource = activeClassSectionList;
                    ddlclasSecTion.DataValueField = "Id";
                    ddlclasSecTion.DataTextField = "Description";
                    ddlclasSecTion.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        private void GetAllFee()
        {
            ClassSectionFeeDAL objFee = new ClassSectionFeeDAL();
            DataSet ds = objFee.GetALlFee();
            if (ds != null)
            {
                GridViewStdntMaster.DataSource = ds;
                GridViewStdntMaster.DataBind();
            }
            else
            {
                GridViewStdntMaster.DataSource = null;
                GridViewStdntMaster.DataBind();
            }
        }

        private void GetAllContact()
        {
            StudentMasterContactDAL objContacts = new StudentMasterContactDAL();
            DataSet ds = objContacts.GetALlContact();
            if (ds != null)
            {
                GridViewContact.DataSource = ds;
                GridViewContact.DataBind();
            }
            else
            {
                GridViewContact.DataSource = null;
                GridViewContact.DataBind();
            }
        }

        private void UploadDocuments(int prodid)
        {
            try
            {
                if (FileUpload1.HasFile)
                {
                    HttpPostedFile file = FileUpload1.PostedFile;

                    string filename = Path.GetFileNameWithoutExtension(file.FileName);
                    string fileextension = Path.GetExtension(file.FileName);
                    string folderPath = Server.MapPath("~/ProductIMG/");
                    if (!Directory.Exists(folderPath))
                    {
                        Directory.CreateDirectory(folderPath);
                    }

                    file.SaveAs(folderPath + "STD_" + filename + "_" + prodid + fileextension);
                    StudentMasterDAL objStudentMaster = new StudentMasterDAL();
                    objStudentMaster.UpdateStudentImage(prodid, "STD_" + filename + "_" + prodid + fileextension);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
      //  StudentIMG/
        public void UpdateData(int Id)
        {
            try
            {
                StudentMasterDAL objStudentMasterDAL = new StudentMasterDAL();
                StudentMaster objStudentMaster = objStudentMasterDAL.StudentMasterGetById(Id);
                if (objStudentMaster != null)
                {

                    hfStudentMaster.Value = objStudentMaster.Id.ToString();
                    txtStudentCode.Attributes.Add("value", objStudentMaster.Code);
                    txtStudentName.Text = objStudentMaster.StudentName;
                    objStudentMaster.Photos = studentphoto.ImageUrl;
                    objStudentMaster.Gender = ddlGender.SelectedItem.Text;
                    objStudentMaster.Address = TextBoxAddress.Text;
                    objStudentMaster.Phone = TextBoxPhone.Text;
                    objStudentMaster.CellNo = TextBox1.Text;
                    objStudentMaster.SMSMobile1 = TextBox2.Text;
                    objStudentMaster.SMSMobile2 = TextBox3.Text;
                    objStudentMaster.EmailId = TextBoxEmail.Text;
                    objStudentMaster.BirthPlace = TextBoxBirthPlace.Text;
                    objStudentMaster.BirthDate = single_calStartDate.Text;
                    objStudentMaster.AdmissionDate = TextBoxAdmissionDate.Text;
                    objStudentMaster.JoinningDate = TextBoxJoiningDate.Text;
                    objStudentMaster.JoinningClass = ddlclassSections.SelectedItem.Text;
                    objStudentMaster.Nationality = TextBoxNationality.Text;
                    objStudentMaster.AccountCode = ddlAccountCode.SelectedItem.Text;
                    objStudentMaster.LeavingClass = ddlclasSecTion.SelectedItem.Text;
                    objStudentMaster.LeaveDate = TextBoxLeaveDate.Text;
                    objStudentMaster.FamilyId = ddlFamilyId.SelectedItem.Text;
                    objStudentMaster.TransportId = ddlTransportId.SelectedItem.Text;
                    objStudentMaster.PickTime = TextBoxPickTime.Text;
                    objStudentMaster.DropTime = TextBoxDropTime.Text;
                    objStudentMaster.Fees = ddlDropDown.SelectedItem.Text;
                    objStudentMaster.LeftReason = ddlLeftReason.SelectedItem.Text;
                    CheckBoxStudy.Checked = Convert.ToBoolean(objStudentMaster.Study);
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
        public void AllClear()
        {
            try
            {
                ActiveId = 0;

                txtStudentName.Text = string.Empty;
               // studentphoto.ImageUrl = string.Empty;
                ddlGender.SelectedIndex = 0;
                ddlDropDown.SelectedIndex = 0;
                ddlLeftReason.SelectedIndex = 0;
                TextBoxAddress.Text = string.Empty;
                TextBoxPhone.Text = string.Empty;
                TextBox1.Text = string.Empty;
                TextBox2.Text = string.Empty;
                TextBox3.Text = string.Empty;
                TextBoxEmail.Text = string.Empty;
                TextBoxBirthPlace.Text = string.Empty;
                single_calStartDate.Text = string.Empty;
                TextBoxAdmissionDate.Text = string.Empty;
                TextBoxJoiningDate.Text = string.Empty;
                ddlclassSections.SelectedIndex = 0;
                TextBoxNationality.Text = string.Empty;
                ddlAccountCode.SelectedIndex = 0;
                ddlclasSecTion.SelectedIndex = 0;
                TextBoxLeaveDate.Text = string.Empty;
                ddlFamilyId.SelectedIndex = 0;
                ddlTransportId.SelectedIndex = 0;
                TextBoxPickTime.Text = string.Empty;
                TextBoxDropTime.Text = string.Empty;
                CheckBoxStudy.Checked = false;
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        public void ContactClear()
        {
            TextBox4Name.Text = string.Empty;
            TextBox4EmailID.Text = string.Empty;
            TextBox4Cell.Text = string.Empty;
            ddlRelationType.SelectedIndex = 0;
            TextBox5IDNo.Text = string.Empty;
            TextBox6Company.Text = string.Empty;
            TextBox7Designation.Text = string.Empty;
            TextBox8OfficeAddress.Text = string.Empty;
            TextBox9OfficeNo.Text = string.Empty;
            TextBox10OfficeAddress.Text = string.Empty;
            ddlClassSection.SelectedIndex=0;
            //ddlFeeMaster.SelectedItem.Text = string.Empty;
        }

        public void Clear()
       {
            GridViewContact.DataSource = string.Empty;
            GridViewContact.DataBind();
            GridViewStdntMaster.DataSource = string.Empty;
            GridViewStdntMaster.DataBind();
            ActiveId = 0;
            rowIndex = -1;
            Initilaize();
            ViewState["StudentMasterContact"] = (List<StudentMasterContact>)null;
            ViewState["ClassSectionFee"] = (List<ClassSectionFee>)null;
            AllClear();
            ContactClear();
        }
       
    public void Initilaize()
        {
            try
            {
                StudentMasterDAL objStudentMasterDAL = new StudentMasterDAL();
                StudentMaster objStudentMaster = new StudentMaster();
                StudentMaster activeMemberMaxId = objStudentMasterDAL.StudentMasterGetMaxId();
                string caption = "StM-00001";
                if (activeMemberMaxId != null)
                {
                    string theString = activeMemberMaxId.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtStudentCode.Value = "StM-0000" + code.ToString();
                }
                else
                {
                    txtStudentCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
       
        protected void StudentMasterSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {                   
                    Response.Redirect("~/SchoolManagementModel/ListOfStudentMaster.aspx", false);
                    Context.ApplicationInstance.CompleteRequest();                    
                }
            }
            catch (Exception)
            {
                     throw;
            }
            //Check Email Id is valid
            if (IsValidEmailId(TextBoxEmail.Text))
            {
                lblMessage.Text = TextBoxEmail.Text +  "is valid email";
            }
            else
            {
                lblMessage.Text = TextBoxEmail.Text + "is not valid email";
            }
        }

        private bool IsValidEmailId(string InputEmail)
        {
            //Regex To validate Email Address
            Regex regex = new Regex(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
            Match match = regex.Match(InputEmail);
            if (match.Success)
                return true;
            else
                return false;
        }
        private bool Save()
        {

            bool IsSave = true;

            StudentMasterDAL objStudentMasterDAL = new StudentMasterDAL();
            StudentMaster objStudentMaster = new StudentMaster();
           
            if (!string.IsNullOrEmpty(hfStudentMaster.Value))
            {
                objStudentMaster.Id = Convert.ToInt32(hfStudentMaster.Value);
            }

            if (!string.IsNullOrEmpty(txtStudentCode.Value))
            {
                objStudentMaster.Code = txtStudentCode.Value;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(txtStudentName.Text))
            {
                objStudentMaster.StudentName = txtStudentName.Text;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlGender.Text))
            {
                objStudentMaster.Gender = ddlGender.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }
            //if (!string.IsNullOrEmpty(studentphoto.ImageUrl))
            //{
            //    objStudentMaster.Photos = studentphoto.ImageUrl;
            //}
            //else
            //{
            //    IsSave = false;
            //}
            if (!string.IsNullOrEmpty(ddlDropDown.Text))
            {
                objStudentMaster.Fees = ddlDropDown.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlLeftReason.SelectedItem.Text))
            {
                objStudentMaster.LeftReason = ddlLeftReason.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(TextBoxAddress.Text))
            {
                objStudentMaster.Address = TextBoxAddress.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxEmail.Text))
            {
                objStudentMaster.EmailId = TextBoxEmail.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBox1.Text))
            {
                objStudentMaster.CellNo = TextBox1.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxPhone.Text))
            {
                objStudentMaster.Phone = TextBoxPhone.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBox2.Text))
            {
                objStudentMaster.SMSMobile1 = TextBox2.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBox3.Text))
            {
                objStudentMaster.SMSMobile2 = TextBox3.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxBirthPlace.Text))
            {
                objStudentMaster.BirthPlace = TextBoxBirthPlace.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(single_calStartDate.Text))
            {
                objStudentMaster.BirthDate = single_calStartDate.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxAdmissionDate.Text))
            {
                objStudentMaster.AdmissionDate = TextBoxAdmissionDate.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxLeaveDate.Text))
            {
                objStudentMaster.LeaveDate = TextBoxLeaveDate.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlclasSecTion.Text))
            {
                objStudentMaster.LeavingClass = ddlclasSecTion.SelectedItem.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlAccountCode.Text))
            {
                objStudentMaster.AccountCode = ddlAccountCode.SelectedItem.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxNationality.Text))
            {
                objStudentMaster.Nationality = TextBoxNationality.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlFamilyId.Text))
            {
                objStudentMaster.FamilyId = ddlFamilyId.SelectedItem.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlTransportId.Text))
            {
                objStudentMaster.TransportId = ddlTransportId.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxJoiningDate.Text))
            {
                objStudentMaster.JoinningDate = TextBoxJoiningDate.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlclassSections.Text))
            {
                objStudentMaster.JoinningClass = ddlclassSections.SelectedItem.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxPickTime.Text))
            {
                objStudentMaster.PickTime = TextBoxPickTime.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(TextBoxDropTime.Text))
            {
                objStudentMaster.DropTime = TextBoxDropTime.Text;
            }
            else
            {
                IsSave = false;
            }

            objStudentMaster.Study = CheckBoxStudy.Checked;

            
                //int StudentId = objStudentMasterDAL.StudentMasterInsert(objStudentMaster);
                UploadDocuments(ActiveId);
              
           

            if (IsSave == true)
            {
                if (StudentMasterSave.Text == "Save")
                {
                    UnitId = objStudentMasterDAL.StudentMasterInsert(objStudentMaster);
                    Response.Redirect("ListOfStudentMaster.aspx");
                }

                else if (StudentMasterSave.Text == "Update")
                {
                    if (objStudentMasterDAL.StudentMasterUpdate(objStudentMaster) == true)

                        IsSave = true;
                    Response.Redirect("ListOfStudentMaster.aspx");
                }
            }

            return IsSave;
        }

        protected void StudentMasterClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        protected void ButtonClearFile_Click(object sender, EventArgs e)
        {
          
                    ////Response.Redirect("~/SchoolManagementModel/StudentMasterForm.aspx?pkg=modeReset", false);
                    ////Context.ApplicationInstance.CompleteRequest();
                }
       
        
        protected void Upload(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/ProductIMG/") + fileName);
                Response.Redirect(Request.Url.AbsoluteUri);
            }
        }

       


        protected void txtStudentName_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ddlGender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }
        protected void txtPhone_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtCell_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtSMSMobile1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtSMSMobile2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        protected void BirthDate_TextChanged(object sender, EventArgs e)
        {

        }

        protected void AdmissionDate_TextChanged(object sender, EventArgs e)
        {

        }

        protected void JoiningDate_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtBirthPlace_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtNationality_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtJoiningClass_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtAccountCode_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ddlDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txtLeavingClass_TextChanged(object sender, EventArgs e)
        {

        }

        protected void LeaveDate_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ddlLeftReason_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txtFamilyID_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtTransporterID_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtPickTime_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtDropTime_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtSectionID_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtFeeID_TextChanged(object sender, EventArgs e)
        {

        }

        
        protected void ButtonGetFeeSetUp_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/SchoolManagementModel/ListOfClassSection.aspx", false);
            Context.ApplicationInstance.CompleteRequest();
        }

        protected void txtRelation_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtNamee_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtCellno_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtEmailID1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtIDno_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtCompany_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtDesignation_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtOfficeAddress_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtOfficeno_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtOfficeAddress1_TextChanged(object sender, EventArgs e)
        {

        }

        public void BindFeesMaster()
        {
            try
            {
                FeesMasterDAL objFeesMasterDAL = new FeesMasterDAL();
                List<FeesMaster> activeFeesMasterIdList = objFeesMasterDAL.FeesMasterSelect();
                FeesMaster objFeesMaster = new FeesMaster();
                if (activeFeesMasterIdList != null)
                {
                    objFeesMaster.Id = 0;
                    objFeesMaster.Description = "None";
                    activeFeesMasterIdList.Insert(0, objFeesMaster);
                    ddlFeeMaster.DataSource = activeFeesMasterIdList;
                    ddlFeeMaster.DataValueField = "Id";
                    ddlFeeMaster.DataTextField = "Description";
                    ddlFeeMaster.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        //private bool IPost()
        //{
        //    bool IsPost = true;

        //    ClassSectionFeeDAL activeClassSectionFeeDAL = new ClassSectionFeeDAL();
        //    ClassSectionFee activeClassSectionFee = new ClassSectionFee();

        //    if (!string.IsNullOrEmpty(hfClassFee.Value))
        //    {
        //        activeClassSectionFee.Id = Convert.ToInt32(hfClassFee.Value);
        //    }

        //    if (!string.IsNullOrEmpty(ddlFeeMaster.Text))
        //    {
        //        activeClassSectionFee.Fee = ddlFeeMaster.SelectedItem.Text;

        //    }
        //    else
        //    {
        //        IsPost = false;
        //    }

        //    if (IsPost == true)
        //    {
        //        if (ButtonPost.Text == "Post")
        //        {
        //            UnitId = activeClassSectionFeeDAL.ClassSectionFeeInsert(activeClassSectionFee);
        //            // Response.Redirect("SubjectMasterForm.aspx");
        //            //GridViewSection.Columns.Clear();
        //        }

        //        else if (ButtonPost.Text == "Update")
        //        {
        //            if (activeClassSectionFeeDAL.ClassSectionFeeUpdate(activeClassSectionFee) == true)
        //                IsPost = true;
        //            //  Response.Redirect("SubjectMasterForm.aspx");
        //        }
        //    }
        //    return IsPost;
        //}

        public bool Post()
        {
            if (ddlFeeMaster.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all Fields Correctly";
                return false;
            }
            bool _post = true;
            ClassSectionFeeDAL _dalApproval = new ClassSectionFeeDAL();
            List<ClassSectionFee> _listApproval = new List<ClassSectionFee>();
            if (ViewState["ClassSectionFee"] != null)
            {
                _listApproval = (List<ClassSectionFee>)ViewState["ClassSectionFee"];
            }

            //var _item = _listApproval.Find(x => x.FormID == Convert.ToInt16(ddlForms.SelectedItem.Value) && x.UserID == Convert.ToInt16(ddlUser.SelectedItem.Value));
            //if (_item != null)
            //{
            //    msgAleart.Visible = true;
            //    lblMessage.Text = "Duplicate Value not Allowed";
            //    ddlForms.ClearSelection();
            //    ddlUser.ClearSelection();
            //    txtSequence.Value = "";
            //    return false;
            //} 
            ClassSectionFee _approval = new ClassSectionFee();
            if (ActiveId == 0)
            {
                _approval.Id = Convert.ToInt16(_dalApproval.MaxClassSectionFeeID().Tables[0].Rows[0][0]);
            }
            else
            {
                _approval.Id = ActiveId;
            }

            _approval.Id = Convert.ToInt16(ddlFeeMaster.SelectedValue);
            _approval.Fee = ddlFeeMaster.SelectedItem.Text;
            //_approval.UserID = Convert.ToInt16(ddlUser.SelectedValue);
            //_approval.UserName = ddlUser.SelectedItem.Text;
            //_approval.Sequence = string.IsNullOrEmpty(txtSequence.Value) ? 0 : Convert.ToInt16(txtSequence.Value);
            if (rowIndex >= 0)
            {
                _listApproval.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                ddlFeeMaster.ClearSelection();
                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";

            }

            _listApproval.Add(_approval);
            GridViewStdntMaster.DataSource = _listApproval;
            GridViewStdntMaster.DataBind();
            ViewState["ClassSectionFee"] = _listApproval;
            lblMessage.Text = "";
            ddlFeeMaster.ClearSelection();
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;
        }
        protected void ButtonPost_Click(object sender, EventArgs e)
        {
            if (Post())
            {

            }
            //try
            //{
            //    if (Post())
            //    {
            //        ActiveId = 1;
            //        GridViewStdntMaster.DataSource = null;
            //        GridViewStdntMaster.DataBind();
            //        GetAllFee();
            //        ddlFeeMaster.SelectedIndex = 0;
            //        //   ddlClassSection.SelectedItem.Text = string.Empty;    

            //        //Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx", false);
            //        // Context.ApplicationInstance.CompleteRequest();
            //    }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }

        protected void GridViewStdntMaster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewStdntMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewStdntMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/StudentMasterForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    ClassSectionFeeDAL objClassSectionFeeDAL = new ClassSectionFeeDAL();
            //    if (iStID > 0)
            //    {
            //        objClassSectionFeeDAL.ClassSectionFeeDelete(iStID);
            //        Response.Redirect("StudentMasterForm.aspx");
            //    }
            //}

            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                ClassSectionFeeDAL objClassSectionFeeDAL = new ClassSectionFeeDAL();
                //if (iStID > 0)
                //{
                //    objClassSectionFeeDAL.ClassSectionFeeDelete(iStID);
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                activeClassSectionFeeList = (List<ClassSectionFee>)ViewState["ClassSectionFee"];
                activeClassSectionFeeList.RemoveAt(rowIndex);
                GridViewStdntMaster.DataSource = activeClassSectionFeeList;
                GridViewStdntMaster.DataBind();
                // Response.Redirect("ClassSectionGeneralForm.aspx");
                //  }
            }
        }
        protected void GridViewStdntMaster_RowDataBound(object sender, GridViewRowEventArgs e)
        {
          

        }

        protected void GridViewStdntMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
       
        protected void ImageImage_Load(object sender, EventArgs e)
        {
            try
            {
                if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileNameWithoutExtension(FileUpload1.PostedFile.FileName);
                    FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                    FileUpload1.SaveAs(Server.MapPath(FileName));
                    this.studentphoto.ImageUrl = FileName;
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('" + ex.Message.ToString() + "');", true);
            }
        }

        //private bool APost()
        //{
        //    bool isPost = true;

        //    StudentMasterContactDAL activeStudentMasterContactDAL = new StudentMasterContactDAL();
        //    StudentMasterContact activeStudentMasterContact = new StudentMasterContact();

        //    if (!string.IsNullOrEmpty(hfClassFee.Value))
        //    {
        //        activeStudentMasterContact.Id = Convert.ToInt32(hfClassFee.Value);
        //    }

        //    if (!string.IsNullOrEmpty(ddlRelationType.Text))
        //    {
        //        activeStudentMasterContact.Relation = ddlRelationType.SelectedItem.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(TextBox4Name.Text))
        //    {
        //        activeStudentMasterContact.Name = TextBox4Name.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(TextBox4Cell.Text))
        //    {
        //        activeStudentMasterContact.CellNo = TextBox4Cell.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(TextBox4EmailID.Text))
        //    {
        //        activeStudentMasterContact.EmailId = TextBox4EmailID.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(TextBox5IDNo.Text))
        //    {
        //        activeStudentMasterContact.IdNo = TextBox5IDNo.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(TextBox6Company.Text))
        //    {
        //        activeStudentMasterContact.Company = TextBox6Company.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(TextBox7Designation.Text))
        //    {
        //        activeStudentMasterContact.Designation = TextBox7Designation.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(TextBox8OfficeAddress.Text))
        //    {
        //        activeStudentMasterContact.OfficeAddress1 = TextBox8OfficeAddress.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(TextBox9OfficeNo.Text))
        //    {
        //        activeStudentMasterContact.OfficeNo = TextBox9OfficeNo.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(TextBox10OfficeAddress.Text))
        //    {
        //        activeStudentMasterContact.OfficeAddress2 = TextBox10OfficeAddress.Text;

        //    }
        //    else
        //    {
        //        isPost = false;
        //    }

        //    if (isPost == true)
        //    {
        //        if (ButtonContactPost.Text == "Post")
        //        {
        //            UnitId = activeStudentMasterContactDAL.StudentMasterContactInsert(activeStudentMasterContact);
        //            // Response.Redirect("SubjectMasterForm.aspx");
        //            //GridViewSection.Columns.Clear();
        //        }

        //        else if (ButtonContactPost.Text == "Update")
        //        {
        //            if (activeStudentMasterContactDAL.StudentMasterContactUpdate(activeStudentMasterContact) == true)
        //                isPost = true;
        //            //  Response.Redirect("SubjectMasterForm.aspx");
        //        }
        //    }
        //    return isPost;
        //}

        public bool APost()
        {
            if (ddlFeeMaster.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all Fields Correctly";
                return false;
            }
            bool _post = true;
            StudentMasterContactDAL _dalApproval = new StudentMasterContactDAL();
            List<StudentMasterContact> _listApproval = new List<StudentMasterContact>();
            if (ViewState["StudentMasterContact"] != null)
            {
                _listApproval = (List<StudentMasterContact>)ViewState["StudentMasterContact"];
            }

            
            StudentMasterContact _approval = new StudentMasterContact();
            if (ActiveId == 0)
            {
                _approval.Id = Convert.ToInt16(_dalApproval.MaxStudentMasterContactID().Tables[0].Rows[0][0]);
            }
            else
            {
                _approval.Id = ActiveId;
            }

            _approval.Id = Convert.ToInt16(ddlRelationType.SelectedValue);
            _approval.Relation = ddlRelationType.SelectedItem.Text;
            _approval.Name = TextBox4Name.Text.ToString();
            _approval.CellNo = TextBox4Cell.Text.ToString();
            _approval.EmailId = TextBox4EmailID.Text.ToString();
            _approval.IdNo = TextBox5IDNo.Text.ToString();
            _approval.Company = TextBox6Company.Text.ToString();
            _approval.Designation = TextBox7Designation.Text.ToString();
            _approval.OfficeAddress1 = TextBox8OfficeAddress.Text.ToString();
            _approval.OfficeNo = TextBox9OfficeNo.Text.ToString();
            _approval.OfficeAddress2 = TextBox10OfficeAddress.Text.ToString();

            //_approval.UserID = Convert.ToInt16(ddlUser.SelectedValue);
            //_approval.UserName = ddlUser.SelectedItem.Text;
            //_approval.Sequence = string.IsNullOrEmpty(txtSequence.Value) ? 0 : Convert.ToInt16(txtSequence.Value);
            if (rowIndex >= 0)
            {
                _listApproval.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                ddlRelationType.ClearSelection();
                TextBox4Name.Text = "";
                TextBox4Cell.Text = "";
                TextBox4EmailID.Text = "";
                TextBox5IDNo.Text = "";
                TextBox6Company.Text = "";
                TextBox7Designation.Text = "";
                TextBox8OfficeAddress.Text = "";
                TextBox9OfficeNo.Text = "";
                TextBox10OfficeAddress.Text = "";

                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";

            }

            _listApproval.Add(_approval);
            GridViewContact.DataSource = _listApproval;
            GridViewContact.DataBind();
            ViewState["StudentMasterContact"] = _listApproval;
            lblMessage.Text = "";
            ddlRelationType.ClearSelection();
            TextBox4Name.Text = "";
            TextBox4Cell.Text = "";
            TextBox4EmailID.Text = "";
            TextBox5IDNo.Text = "";
            TextBox6Company.Text = "";
            TextBox7Designation.Text = "";
            TextBox8OfficeAddress.Text = "";
            TextBox9OfficeNo.Text = "";
            TextBox10OfficeAddress.Text = "";
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;
        }
        protected void ButtonContactPost_Click(object sender, EventArgs e)
        {
            if (APost())
            {

            }
            //try
            //{
            //    if (APost())
            //    {
            //        ActiveId = 1;
            //        GridViewContact.DataSource = null;
            //        GridViewContact.DataBind();
            //        GetAllContact();
            //        ContactClear();
            //        //Response.Redirect("~/SchoolManagementModel/SubjectMasterForm.aspx", false);
            //        // Context.ApplicationInstance.CompleteRequest();
            //    }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }
        protected void GridViewContact_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewContact_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewContact_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            
            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/StudentMasterForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    StudentMasterContactDAL objStudentMasterContactDAL = new StudentMasterContactDAL();
            //    if (iStID > 0)
            //    {
            //        objStudentMasterContactDAL.StudentMasterContactDelete(iStID);
            //        Response.Redirect("StudentMasterForm.aspx");
            //    }
            //} 
            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                ClassSectionFeeDAL objClassSectionFeeDAL = new ClassSectionFeeDAL();
                //if (iStID > 0)
                //{
                //    objClassSectionFeeDAL.ClassSectionFeeDelete(iStID);
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                activeStudentMasterContactList = (List<StudentMasterContact>)ViewState["StudentMasterContact"];
                activeStudentMasterContactList.RemoveAt(rowIndex);
                GridViewContact.DataSource = activeStudentMasterContactList;
                GridViewContact.DataBind();
                // Response.Redirect("ClassSectionGeneralForm.aspx");
                //  }
            }
        }
        protected void GridViewContact_RowDataBound(object sender, GridViewRowEventArgs e)
        {
        }

        protected void GridViewContact_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}