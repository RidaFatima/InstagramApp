﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;



namespace WebDesk_ERP.SchoolManagementModel
{

    public partial class FeeMasterForm : System.Web.UI.Page
    {
        //public static int Id { get; set; }
        //public static int FeeId { get; set; }
        //public static string FeeType { get; set; }
        //public static string FeeMonth { get; set; }
        //public static int Account_Code { get; set; }
        //public static decimal Amount { get; set; }
        public static int ActiveId { get; set; }
        public static int rowIndex { get; set; }
        public static int FeeMasterId { get; set; }

        public static string Code = null;
        public int UnitId;


        FeesMaster objFeeMaster = new FeesMaster();
        List<ClassSession> activeClassSessionIdList = new List<ClassSession>();
        List<FeesMaster> activeFeeMasterIdList = new List<FeesMaster>();
        List<FeePost> activeFeePostList = new List<FeePost>();
        FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
        public int getid;

        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {
                FeesMaster objFeeMaster = new FeesMaster();
                //  ViewState["FeesMaster"] = new List<FeesMaster>();
                //  BindGridView();
                //  BindFeesMaster();
                ////loadSession();
                ////Initilaize();
                ////ClearProduct();
                rowIndex = -1;
                BindAccount();
                BindAcadmicSession();
                BindFeeTypeMaster();
                GetAllFee();
                Initilaize();

                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    FeeSaveBtn.Text = "Update";
                    ActiveId = 1;
                    // UpdateData(getid);
                    BindAccount();
                    BindAcadmicSession();
                    BindFeeTypeMaster();
                    loadSession();
                    Initilaize();
                    // ClearProduct();
                    GetId();
                  //  Post();

                }
                else
                {
                    FeeSaveBtn.Text = "Save";
                    ActiveId = 0;
                    Clear();
                    //  ClearProduct();
                }

            }
        }

        public void UpdateData(int Id)
        {
            try
            {
                FeesMasterDAL activeFeeMasterDAL = new FeesMasterDAL();
                FeesMaster objFeeMaster = activeFeeMasterDAL.FeesMasterGetById(Id);

                //if (activeFeeMasterIdList.IndexOf(item) == Id)
                //{
                if (objFeeMaster != null)
                {
                    hfFeesMasterID.Value = objFeeMaster.Id.ToString();
                    txtFeeMasterCode.Attributes.Add("value", objFeeMaster.Code);
                    txtFeeDescription.Text = objFeeMaster.Description;
                    // AcadmicYear.Text = objFeeMaster.Year;
                    //   objFeeMaster.AccountCode = Convert.ToInt32(txtAccountCode.Text);
                    ddlchartAccount.SelectedItem.Text = objFeeMaster.AccountCode;
                    ddlFeeTypeMaster.SelectedItem.Text = objFeeMaster.FeeType;
                    //ddlFeesMaster.SelectedValue = objFeeMaster.FeeType.ToString();
                    txtFeeAmount.Text = objFeeMaster.Amount.ToString("0.00");
                    // FeeMonthShow.Text = objFeeMaster.FeeMonth;
                    ddlMonth.SelectedItem.Text = objFeeMaster.FeeMonth.ToString();
                    ddlAcadmicSession.SelectedValue = objFeeMaster.Year.ToString();
                    // }  
                }

            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);

                }
            }
            catch
            {
                //  MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }

        private void GetAllFee()
        {
            FeePostDAL objFee = new FeePostDAL();
            DataSet ds = objFee.GetALlFee();
            if (ds != null)
            {
                GridViewFeeMaster.DataSource = ds;
                GridViewFeeMaster.DataBind();
            }
            else
            {
                GridViewFeeMaster.DataSource = null;
                GridViewFeeMaster.DataBind();
            }
        }
        public void ClearField()
        {
            try
            {
                ddlFeeTypeMaster.SelectedIndex =0;
                txtFeeAmount.Text = "0" ;
                ddlMonth.SelectedIndex = 0;
                ddlchartAccount.SelectedIndex =0;
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
}

public void AllClear()
        {
            try
            {
                ActiveId = 0;

                txtFeeDescription.Text = string.Empty;
                ddlAcadmicSession.SelectedIndex= 0;      
               //FeeMonthShow.Text = string.Empty;
                GridViewFeeMaster.SelectedIndex = 0;
                hfFeesMasterID.Value = string.Empty;
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
        public void Clear()
        {
          //  GridViewFeeMaster.DataSource = string.Empty;
            GridViewFeeMaster.SelectedIndex = 0;
            GridViewFeeMaster.DataBind();
            ViewState["FeePost"] = (List<FeePost>)null;
            ActiveId = 0;
            rowIndex = -1;
            Initilaize();
            AllClear();
        }
        public void BindAccount()
        {
            try
            {
                ChartofAccountDAL Activedal = new ChartofAccountDAL();
                List<ChartofAccount> ActiveListacc = Activedal.ChartofAccountSelect();
                ChartofAccount activeAccount = new ChartofAccount();
                if (ActiveListacc != null)
                {
                    activeAccount.Id = 0;
                    activeAccount.AccountName = "None";
                    ActiveListacc.Insert(0, activeAccount);
                    ddlchartAccount.DataSource = ActiveListacc;
                    ddlchartAccount.DataValueField = "Id";
                    ddlchartAccount.DataTextField = "AccountName";
                    ddlchartAccount.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindAcadmicSession()
        {
            try
            {
                AcadmicSessionDAL ActiveDAL = new AcadmicSessionDAL();
                List<AcadmicSession> ActiveList = ActiveDAL.AcadmicSessionSelect();
                AcadmicSession activeSession = new AcadmicSession();
                if (ActiveList != null)
                {
                    activeSession.Id = 0;
                    activeSession.Description = "None";
                    ActiveList.Insert(0, activeSession);
                    ddlAcadmicSession.DataSource = ActiveList;
                    ddlAcadmicSession.DataValueField = "Id";
                    ddlAcadmicSession.DataTextField = "Description";
                    ddlAcadmicSession.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindFeeTypeMaster()
        {
            try
            {
                FeeTypeMasterDAL objFeeTypeMasterDAL = new FeeTypeMasterDAL();
                List<FeeTypeMaster> activeFeeTypeMasterIdList = objFeeTypeMasterDAL.FeeTypeMasterSelect();
                FeeTypeMaster objFeeTypeMaster = new FeeTypeMaster();
                if (activeFeeTypeMasterIdList != null)
                {
                    objFeeTypeMaster.Id = 0;
                    objFeeTypeMaster.Description = "None";
                    activeFeeTypeMasterIdList.Insert(0, objFeeTypeMaster);
                    ddlFeeTypeMaster.DataSource = activeFeeTypeMasterIdList;
                    ddlFeeTypeMaster.DataValueField = "Id";
                    ddlFeeTypeMaster.DataTextField = "Description";
                    ddlFeeTypeMaster.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void loadSession()
        {
            FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
            List<FeesMaster> activeFeeMasterIdList = objFeeMasterDAL.FeesMasterSelect();
            if (activeFeeMasterIdList != null)
            {
                GridViewFeeMaster.DataSource = ViewState["activeFeeMasterIdList"] as List<FeesMaster>;
                GridViewFeeMaster.DataBind();
            }
        }

        //private bool Post()
        //{
        //    bool isPost = true;
        // //   FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
        //    //    FeesMaster objFeeMaster = new FeesMaster();

        //    try
        //    {
        //        List<FeePost> activeFeePostList = new List<FeePost>();
        //        if (ActiveId == 0)
        //        {
        //            activeFeePostList = (List<FeePost>)ViewState["FeePost"];
        //        }
        //        if (!string.IsNullOrEmpty(txtFeeAmount.Text))
        //        {
        //            decimal Amount = Convert.ToDecimal(txtFeeAmount.Text);
        //            int AccountCode = Convert.ToInt32(ddlchartAccount.Text);

        //        }
        //        else
        //        {
        //            decimal Amount = 0.00m;
        //            int AccountCode = 0;
        //            if (!string.IsNullOrEmpty(txtFeeAmount.Text))
        //            {
        //                Amount = Convert.ToDecimal(txtFeeAmount.Text);
        //            }
        //            if (!string.IsNullOrEmpty(ddlchartAccount.Text))
        //            {
        //                AccountCode = Convert.ToInt32(ddlchartAccount.Text);
        //            }
        //        }
        //            if (isPost)
        //            {
        //                if (GridViewFeeMaster.Rows.Count > 0)
        //                {
        //                    if (ActiveId > 0)
        //                    {

        //                        if (ViewState["FeePost"] != null)
        //                        {
        //                        activeFeePostList = (List<FeePost>)ViewState["FeePost"];

        //                        }

        //                        int index = rowIndex;
        //                        FeePost activeFeePost = new FeePost();
        //                    //if (!string.IsNullOrEmpty(hfFeesMasterID.Value))
        //                    //{
        //                    //    activeFeePost.Id = Convert.ToInt32(hfFeesMasterID.Value);
        //                    //}
        //                    activeFeePost.Id = 1;
        //                    activeFeePost.Id = Convert.ToInt32(ddlFeeTypeMaster.SelectedValue);
        //                    activeFeePost.FeeType = ddlFeeTypeMaster.SelectedItem.Text;
        //                   // activeFeePost.FeeMonth = FeeMonthShow.Text;
        //                    activeFeePost.FeeMonth = ddlMonth.SelectedItem.Text;
                               
        //                    //      activeFeeMaster.AccountCode = Convert.ToInt32(txtAccountCode.Text);
        //                        //       activeFeeMaster.Amount = Convert.ToDecimal(txtFeeAmount.Text);
        //                        if (!string.IsNullOrEmpty(txtFeeAmount.Text))
        //                        {
        //                        activeFeePost.Amount = Convert.ToDecimal(txtFeeAmount.Text);
        //                        }
        //                        else
        //                        {
        //                        activeFeePost.Amount = 0.00m;
        //                        }
        //                    activeFeePostList.RemoveAt(index);
        //                    activeFeePostList.Insert(index, activeFeePost);
        //                    }
        //                    else
        //                    {
        //                        if (ActiveId <= 0)
        //                        {
        //                            if (ViewState["FeePost"] != null)
        //                            {
        //                            activeFeePostList = (List<FeePost>)ViewState["FeePost"];
        //                            }
        //                       //     GridViewFeeMaster.DataSource = null;
        //                        }
        //                        FeePost activeFeePost = new FeePost();
        //                    //if (!string.IsNullOrEmpty(hfFeesMasterID.Value))
        //                    //{
        //                    //    activeFeePost.Id = Convert.ToInt32(hfFeesMasterID.Value);
        //                    //}
        //                    activeFeePost.Id = 1;
        //                    activeFeePost.Id = Convert.ToInt32(ddlFeeTypeMaster.SelectedValue);
        //                    activeFeePost.FeeType = ddlFeeTypeMaster.SelectedItem.Text;
        //                    //activeFeePost.FeeMonth = FeeMonthShow.Text;
        //                    activeFeePost.FeeMonth = ddlMonth.SelectedItem.Text;
                            
        //                    if (!string.IsNullOrEmpty(txtFeeAmount.Text))
        //                    {
        //                        activeFeePost.Amount = Convert.ToDecimal(txtFeeAmount.Text);
        //                    }
        //                    else
        //                    {
        //                        activeFeePost.Amount = 0.00m;
        //                    }
        //                    activeFeePostList.Add(activeFeePost);
        //                    }
        //                }

        //                else
        //                {
        //                    FeePost activeFeePost = new FeePost();
        //                //if (!string.IsNullOrEmpty(hfFeesMasterID.Value))
        //                //{
        //                //    activeFeePost.Id = Convert.ToInt32(hfFeesMasterID.Value);
        //                //}
        //                activeFeePost.Id = 1;
        //                activeFeePost.Id = Convert.ToInt32(ddlFeeTypeMaster.SelectedValue);
        //                activeFeePost.FeeType = ddlFeeTypeMaster.SelectedItem.Text;
        //                //activeFeePost.FeeMonth = FeeMonthShow.Text;
        //                activeFeePost.FeeMonth = ddlMonth.SelectedItem.Text;

        //                 //  activeFeeMaster.AccountCode = Convert.ToInt32(txtAccountCode.Text);
        //                //   activeFeeMaster.Amount = Convert.ToDecimal(txtFeeAmount.Text);
        //                if (!string.IsNullOrEmpty(txtFeeAmount.Text))
        //                {
        //                    activeFeePost.Amount = Convert.ToDecimal(txtFeeAmount.Text);
        //                }
        //                else
        //                {
        //                    activeFeePost.Amount = 0.00m;
        //                }
        //                activeFeePostList.Add(activeFeePost);
        //                }
        //                GridViewFeeMaster.DataSource = ViewState["activeFeePostList"] as List<FeePost>;
        //                GridViewFeeMaster.DataBind();
        //                //   ViewState["FeesMaster"] = activeFeeMasterIdList;
        //            }
        //    }

        //    catch (NullReferenceException ex)
        //    {
        //        //    throw ex;
        //    }
        //    return isPost;

        //} 

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/ListOfFeeMasterForm.aspx?ID=" + ((LinkButton)sender).Text);
        }

        protected void Fee_Save(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    //ActiveId = 0;
                    Response.Redirect("~/SchoolManagementModel/ListOfFeeMasterForm.aspx", false);
                    Context.ApplicationInstance.CompleteRequest();
                    ClearFeePost();

                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private bool Save()
        {


            bool IsSave = true;


            FeesMasterDAL activeFeeMasterDAL = new FeesMasterDAL();
            FeesMaster activeFeeMaster = new FeesMaster();

            if (!string.IsNullOrEmpty(hfFeesMasterID.Value))
            {
                activeFeeMaster.Id = Convert.ToInt32(hfFeesMasterID.Value);
            }   

            if (!string.IsNullOrEmpty(txtFeeDescription.Text))
            {
                activeFeeMaster.Description = txtFeeDescription.Text;

            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(txtFeeMasterCode.Value))
            {
                activeFeeMaster.Code = txtFeeMasterCode.Value;
            }
            else
            {
                IsSave = false;
            }


            if (!string.IsNullOrEmpty(ddlAcadmicSession.Text))
            {
                activeFeeMaster.Year = ddlAcadmicSession.SelectedItem.ToString();
                //    activeFeeMaster.Id = Convert.ToInt32(ddlchartAccount.SelectedValue);
            }
            else
            {
                //activeFeeMaster.AccountCode = string.Empty;
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlchartAccount.Text))
            {
                activeFeeMaster.AccountCode = ddlchartAccount.SelectedItem.ToString();
            //    activeFeeMaster.Id = Convert.ToInt32(ddlchartAccount.SelectedValue);
            }
            else
            {
                //activeFeeMaster.AccountCode = string.Empty;
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(txtFeeAmount.Text))
            {
                activeFeeMaster.Amount = Convert.ToDecimal(txtFeeAmount.Text);

            }
            else
            {
                IsSave = false;
            }

            //if (!string.IsNullOrEmpty(FeeMonthShow.Text))
            //{
            //    activeFeeMaster.FeeMonth = FeeMonthShow.Text;

            //}
            //else
            //{
            //    IsSave = false;
            //}

            if (!string.IsNullOrEmpty(ddlMonth.Text))
            {
                activeFeeMaster.FeeMonth = ddlMonth.SelectedItem.Text;

            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlFeeTypeMaster.Text))
            {
                activeFeeMaster.FeeType = ddlFeeTypeMaster.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }

            if (IsSave == true)
            {
                if (FeeSaveBtn.Text == "Save")
                {
                    UnitId = activeFeeMasterDAL.FeeMasterInsert(activeFeeMaster);
                    Response.Redirect("ListOfFeeMasterForm.aspx");
                    GridViewFeeMaster.Columns.Clear();
                }

                else if (FeeSaveBtn.Text == "Update")
                {
                    if (activeFeeMasterDAL.FeeMasterUpdate(activeFeeMaster) == true)

                        IsSave = true;
                    Response.Redirect("ListOfFeeMasterForm.aspx");
                }

            }

            return IsSave;
        }

        protected void Fee_Clear(object sender, EventArgs e)
        {
            Clear();
        }

        protected void single_Year_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ddlFeetype_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string message = ddlFeesMaster.SelectedItem.Text + " - " + ddlFeesMaster.SelectedItem.Value;
            //ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + message + "');", true);
            int FeesMasterid = 0;
            FeesMasterid = Convert.ToInt32(ddlFeeTypeMaster.SelectedValue);

            DisplayFeesMaster(FeesMasterid);
        }

        private void DisplayFeesMaster(int ActiveId)
        {
            try
            {
                FeesMasterDAL activeFeeMasterDAL = new FeesMasterDAL();
                FeesMaster activeFeeMaster = activeFeeMasterDAL.FeesMasterGetById(ActiveId);
                if (activeFeeMaster != null)
                {
                  //  activeFeeMaster.AccountCode = Convert.ToInt32(ddlchartAccount.Text);
                    ddlFeeTypeMaster.SelectedValue = activeFeeMaster.FeeType.ToString();
                    ddlchartAccount.SelectedValue = activeFeeMaster.AccountCode.ToString();
                    txtFeeAmount.Text = activeFeeMaster.Amount.ToString("0.00");
                    //FeeMonthShow.Text = activeFeeMaster.FeeMonth;
                    ddlMonth.SelectedItem.Text = activeFeeMaster.FeeMonth;
                }
            }
            catch (Exception ex)
            {
                //  MessageBox.Show("UpdateProduct: " + ex.Message, "ICT", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        protected void single_FeeMonth_TextChanged(object sender, EventArgs e)
        {

        }
        private void BindGridView()
        {
            try
            {
                FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
                List<FeesMaster> activeFeeMasterIdList = objFeeMasterDAL.FeeMasterSelectNew();
                if (activeFeeMasterIdList != null)
                {
                    GridViewFeeMaster.DataSource = ViewState["activeFeeMasterIdList"] as List<FeesMaster>;
                    GridViewFeeMaster.DataBind();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        protected void buttonPost_Click(object sender, EventArgs e)
        {
            try
            {
                if (Post())
                {
                    //GridViewSection.DataSource = null;
                    //GridViewSection.DataBind();
                }
            }
            catch (Exception)
            {
                throw;
            }
            //try
            //{
            //    if (IPost())
            //    {
            //        GridViewFeeMaster.DataSource = null;
            //        GridViewFeeMaster.DataBind();
            //        GetAllFee();
            //        ddlFeeTypeMaster.SelectedIndex = 0;
            //        ddlMonth.SelectedIndex = 0;
            //        ClearField();
            //        GridViewFeeMaster.SelectedIndex = 0;
            //        GridViewFeeMaster.DataBind();
            //        //  Clear();
            //        //AllClear();
            //        ////ActiveId = 0;
            //        //Response.Redirect("~/SchoolManagementModel/FeeMasterForm.aspx", false);
            //        //Context.ApplicationInstance.CompleteRequest();

            //    }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }

        private void ClearProduct()
        {
            try
            {
                //ddlFeesMaster.SelectedIndex = 0;
                //txtAccountCode.Text = "0";
                //FeeMonthShow.Text = string.Empty;
                //txtFeeAmount.Text = "0.00";
                GridViewFeeMaster.DataSource = null;
                GridViewFeeMaster.DataSource = ViewState["activeFeeMasterIdList"] as List<FeesMaster>;
                activeFeeMasterIdList.Clear();
                //if (!IsPostBack)
                //{
                //    GridViewFeeMaster.DataSource = null;
                //}
                //BindFeesMaster();
            }
            catch (Exception ex)
            {

            }
        }

        public void Initilaize()
        {
            try
            {
                FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
                FeesMaster objFeeMaster = objFeeMasterDAL.FeeMasterGetMaxId();
                string caption = "FM-00001";
                if (objFeeMaster != null)
                {
                    string theString = objFeeMaster.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtFeeMasterCode.Value = "FM-0000" + code.ToString();
                }
                else
                {
                    txtFeeMasterCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        private void UpdateFeesMaster(int Id)
        {
            if (GridViewFeeMaster.Rows.Count > 0)
            {
                List<FeesMaster> activeFeeMasterIdList = (List<FeesMaster>)ViewState["FeesMaster"];

                foreach (FeesMaster item in activeFeeMasterIdList)
                {
                    //if (activeFeeMasterIdList.IndexOf(item) == Id)
                    // { 
                    //      FeeMasterId = item.Id;

                   //FeeMonthShow.Text = item.FeeMonth;
                    ddlMonth.SelectedItem.Text = item.FeeMonth.ToString();

                    txtFeeAmount.Text = item.Amount.ToString();
                  //  txtAccountCode.Text = item.AccountCode.ToString();
                    ddlchartAccount.SelectedItem.Text = item.AccountCode.ToString();
                    ddlFeeTypeMaster.SelectedItem.Text = item.FeeType.ToString();
                    // }
                }
            }
        }

        protected void GridViewFeeMaster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewFeeMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewFeeMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/FeeMasterForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    FeePostDAL objFeePostDAL = new FeePostDAL();
            //    if (iStID > 0)
            //    {
            //        objFeePostDAL.FeePostDelete(iStID);

            //        Response.Redirect("FeeMasterForm.aspx");

            //    }
            //}

            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                FeePostDAL objFeePostDAL = new FeePostDAL();
                //if (iStID > 0)
                //{
                //    objClassFeePostDAL.ClassFeeDelete(iStID);
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                activeFeePostList = (List<FeePost>)ViewState["FeePost"];
                activeFeePostList.RemoveAt(rowIndex);
                GridViewFeeMaster.DataSource = activeFeePostList;
                GridViewFeeMaster.DataBind();
                // Response.Redirect("ClassMasterForm.aspx");
                // }
            }
        }

        protected void GridViewFeeMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public bool Post()
        {
            if (ddlFeeTypeMaster.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all the Fields Correctly";
                return false;
            }
            bool _post = true;
            FeePostDAL _dalApproval = new FeePostDAL();
            List<FeePost> _listApproval = new List<FeePost>();
            if (ViewState["FeePost"] != null)
            {
                _listApproval = (List<FeePost>)ViewState["FeePost"];
            }

            //var _item = _listApproval.Find(x => x.FormID == Convert.ToInt16(ddlForms.SelectedItem.Value) && x.UserID == Convert.ToInt16(ddlUser.SelectedItem.Value));
            //if (_item != null)
            //{
            //    msgAleart.Visible = true;
            //    lblMessage.Text = "Duplicate Value not Allowed";
            //    ddlForms.ClearSelection();
            //    ddlUser.ClearSelection();
            //    txtSequence.Value = "";
            //    return false;
            //}
            FeePost _approval = new FeePost();
            if (ActiveId == 0)
            {
                _approval.Id = Convert.ToInt16(_dalApproval.MaxFeePostID().Tables[0].Rows[0][0]);
            }
            else
            {
                _approval.Id = ActiveId;
            }

            _approval.Id = Convert.ToInt16(ddlchartAccount.SelectedValue);
            _approval.AccountCode = ddlchartAccount.SelectedItem.Text;
            _approval.Id = Convert.ToInt16(ddlFeeTypeMaster.SelectedValue);
            _approval.FeeType = ddlFeeTypeMaster.SelectedItem.Text;
            _approval.Id = Convert.ToInt16(ddlMonth.SelectedValue);
            _approval.FeeMonth = ddlMonth.SelectedItem.Text;
           // _approval.Id = Convert.ToDecimal(txtFeeAmount.Text);
            _approval.Amount = Convert.ToDecimal(txtFeeAmount.Text.ToString());

            if (rowIndex >= 0)
            {
                _listApproval.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                ddlchartAccount.ClearSelection();
                ddlFeeTypeMaster.ClearSelection();
                ddlMonth.ClearSelection();
                txtFeeAmount.Text = "0.00";
                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";

            }

            _listApproval.Add(_approval);
            GridViewFeeMaster.DataSource = _listApproval;
            GridViewFeeMaster.DataBind();
            ViewState["FeePost"] = _listApproval;
            lblMessage.Text = "";
            ddlchartAccount.ClearSelection();
            ddlFeeTypeMaster.ClearSelection();
            ddlMonth.ClearSelection();
            txtFeeAmount.Text = "0.00";
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;
        }

        private bool IPost()
        {

            bool IsPost = true;

            FeePostDAL activeFeePostDAL = new FeePostDAL();
            FeePost activeFeePost = new FeePost();

            if (!string.IsNullOrEmpty(HiddenFieldPost.Value))
            {
                activeFeePost.Id = Convert.ToInt32(HiddenFieldPost.Value);
            }

            //if (!string.IsNullOrEmpty(txtFeeDescription.Text))
            //{
            //    activeFeePost.FeeType = txtFeeDescription.Text;

            //}
            //else
            //{
            //    IsPost = false;
            //}
       

            if (!string.IsNullOrEmpty(ddlchartAccount.SelectedItem.Text))
            {
                activeFeePost.AccountCode = ddlchartAccount.SelectedItem.Text;
            }
            else
            {
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(txtFeeAmount.Text))
            {
                activeFeePost.Amount = Convert.ToDecimal(txtFeeAmount.Text);

            }
            else
            {
                IsPost = false;
            }

            //if (!string.IsNullOrEmpty(FeeMonthShow.Text))
            //{
            //    activeFeePost.FeeMonth = FeeMonthShow.Text;

            //} 
            //else
            //{
            //    IsPost = false;
            //}

            if (!string.IsNullOrEmpty(ddlMonth.Text))
            {
                activeFeePost.FeeMonth = ddlMonth.SelectedItem.Text;
            }
            else
            {
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(ddlFeeTypeMaster.Text))
            {
                activeFeePost.FeeType = ddlFeeTypeMaster.SelectedItem.ToString();

            }
            else
            {
                //errorProviderDis.SetError(txtCode, "Enter The Job Code ");
                IsPost = false;
            }

            if (IsPost == true)
            {
                if (buttonPost.Text == "Post")
                {
                    UnitId = activeFeePostDAL.FeePostInsert(activeFeePost);
                //    Response.Redirect("FeeMasterForm.aspx");
                //    GridViewFeeMaster.Columns.Clear();
               //     GridViewFeeMaster.DataSource = null;
                }

                else if (FeeSaveBtn.Text == "Update")
                {
                    if (activeFeePostDAL.FeePostUpdate(activeFeePost) == true)
                        IsPost = true;
                //    Response.Redirect("FeeMasterForm.aspx");
                }
            }
            return IsPost;
        }
        private void ClearFeePost()
        {
            ActiveId = 0;
           
            //VendorId = 0;
            ddlFeeTypeMaster.ClearSelection();
            txtFeeAmount.Text = string.Empty;
            ddlchartAccount.Text = string.Empty;
            //FeeMonthShow.Text = string.Empty;
            ddlMonth.SelectedItem.Text = string.Empty;
            GridViewFeeMaster.DataSource = null;
            ViewState["FeePost"] = null;
            Response.Redirect("FeeMasterForm.aspx");
            Initilaize();
            loadSession();
        }
        protected void ddlchartAccount_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}      