﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;
using System.IO;


namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfStudentMaster : System.Web.UI.Page
    {
        StudentMasterDAL activeStudentMasterDAL = new StudentMasterDAL();
        StudentMaster activeStudentMaster = new StudentMaster();
        protected void Page_Load(object sender, EventArgs e)
        {
            bindtreeview();
            loadSession();

            string[] filePaths = Directory.GetFiles(Server.MapPath("~/SchoolManagementModel/ProductIMG/"));
            List<StudentMaster> files = new List<StudentMaster>();
            StudentMaster activeStudentMaster = new StudentMaster();
            foreach (string filePath in filePaths)
            {
                string fileName = Path.GetFileName(filePath);
            //    files.Add(new StudentMaster(fileName, "~/ProductIMG/" + fileName));
            }
           // GridViewStudentMaster.DataSource = files;
           // GridViewStudentMaster.DataBind();
        }

       
        public void loadSession()
        {
            StudentMasterDAL activeSubjectMasterDAL = new StudentMasterDAL();
            List<StudentMaster> activeStudentMasterList = activeStudentMasterDAL.StudentMasterSelectNew();
            if (activeStudentMasterList != null)
            {
                GridViewStudentMaster.DataSource = ViewState["activeStudentMasterList"] as List<StudentMaster>;
                GridViewStudentMaster.DataBind();
            }
            else
            {

                GridViewStudentMaster.DataSource = null;
                GridViewStudentMaster.DataBind();
            }

        }
        
        public void bindtreeview()
        {
            DataTable dt = activeStudentMasterDAL.GetData("SELECT * From  StudentMaster where Study='True'");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["Id"].ToString()
                };
                if (parentId == 0)
                {
                    //  TreeViewFeeMaster.Nodes.Add(child);
                    dtChild = activeStudentMasterDAL.GetData("SELECT * From StudentMaster where Study='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = activeStudentMasterDAL.GetData("SELECT * From StudentMaster where Study='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }
       
        protected void GridViewStudentMaster_OnDataBound(object sender, GridViewRowEventArgs e)
        {
            //string id;
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    id = e.Row.Cells[0].Text;
            //    (e.Row.Cells[4].FindControl("imgproduct") as Image).ImageUrl = "Photos/" + id + ".jpg";
            //}
        }
        protected void GridViewStudentMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewStudentMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/StudentMasterForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                StudentMasterDAL activeStudentMasterDAL = new StudentMasterDAL();
                if (iStID > 0)
                {
                    activeStudentMasterDAL.StudentMasterDelete(iStID);
                    //BindFeesMaster();
                    // loadSession();
                    TreeViewStudentMaster.Nodes.Clear();
                    bindtreeview();
                    Response.Redirect("ListOfStudentMaster.aspx");
                }
            }
        }
        protected void GridViewStudentMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridViewStudentMaster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void TreeViewStudentMaster_SelectedNodeChanged(object sender, EventArgs e)
        {
            
        }
    }
}