﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListAcadmicSession : System.Web.UI.Page
    {
        AcadmicSessionDAL objAcadmicSessionDAL = new AcadmicSessionDAL();
        AcadmicSession objAcadmicSession = new AcadmicSession();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                loadSession();
                bindtreeview();
            }
        }

        protected void GridViewAcadmicSessionList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void loadSession()
        {
            AcadmicSessionDAL activeDAL = new AcadmicSessionDAL();
            List<AcadmicSession> activeList = activeDAL.AcadmicSessionSelect();
            if (activeList != null)
            {
                GridViewAcadmicSessionList.DataSource = ViewState ["activeList"] as List<AcadmicSession>;
                GridViewAcadmicSessionList.DataBind();
            }
            else
            {
                
                    GridViewAcadmicSessionList.DataSource = null;
                    GridViewAcadmicSessionList.DataBind();
                }
            
        }

        public void bindtreeview()
        {
            DataTable dt = objAcadmicSessionDAL.GetData("SELECT * From  AcadmicSession where Active='True' and CurrentYear='True'");
            this.loadTreeview(dt, 0, null);
        }

        protected void GridViewAcadmicSessionList_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["id"].ToString()
                };
                if (parentId == 0)
                {
                    TreeViewAcadmicSession.Nodes.Add(child);
                    dtChild = objAcadmicSessionDAL.GetData("SELECT * From  AcadmicSession where Active='True' and CurrentYear='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = objAcadmicSessionDAL.GetData("SELECT * From  AcadmicSession where Active='True'  and CurrentYear='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }

        protected void GridViewAcadmicSessionList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/AcadmicSessionForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                AcadmicSessionDAL activeDAL = new AcadmicSessionDAL();
                if (iStID > 0)
                {
                    activeDAL.AcadmicSessionDelete(iStID);
                   // loadSession();
                    TreeViewAcadmicSession.Nodes.Clear();
                    bindtreeview();
                    Response.Redirect("ListAcadmicSession.aspx");

                }
            }
        }

        protected void TreeViewAcadmicSession_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}