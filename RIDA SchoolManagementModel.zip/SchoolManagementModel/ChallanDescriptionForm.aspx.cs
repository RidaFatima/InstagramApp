﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;
using System.Web.UI;
using System.Data.SqlClient;


namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ChallanDescriptionForm : System.Web.UI.Page 
    {
        public static int rowIndex { get; set; }
        public static int ActiveId { get; set; }
        public static int ChallanId { get; set; }
        public int getid;
        public int UnitId;

        List<ChallanDescriptionTable> _lisChallanDescriptionTable = new List<ChallanDescriptionTable>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rowIndex = -1;
                BindStudentName();
                BindChartAccount();
                BindFeesMaster();
                GetAllChallanDescription();
                Initilaize();
                GetId();
                
              //  ViewState["ChallanDescriptionTable"] = new List<ChallanDescriptionTable>();
              //  Clear();
              //    txtTotal.Value = string.Empty;

                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    btnChallanSave.Text = "Update";
                    ActiveId = 1;
                    
                }
                else
                {
                    btnChallanSave.Text = "Save";
                    ActiveId = 0;
                    //Clear();
                   

                }
            }
        }

        public void BindFeesMaster()
        {
            try
            {
                FeesMasterDAL objFeesMasterDAL = new FeesMasterDAL();
                List<FeesMaster> activeFeesMasterIdList = objFeesMasterDAL.FeesMasterSelect();
                FeesMaster objFeesMaster = new FeesMaster();
                if (activeFeesMasterIdList != null)
                {
                    objFeesMaster.Id = 0;
                    objFeesMaster.Description = "None";
                    activeFeesMasterIdList.Insert(0, objFeesMaster);
                    ddlAmount.DataSource = activeFeesMasterIdList;
                    ddlAmount.DataValueField = "Id";
                    ddlAmount.DataTextField = "Description";
                    ddlAmount.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        public void BindStudentName()
        {
            try
            {
                StudentMasterDAL objStudentMasterDAL = new StudentMasterDAL();
                List<StudentMaster> activeStudentMasterIdList = objStudentMasterDAL.StudentMasterSelectNew();
                StudentMaster objStudentMaster = new StudentMaster();
                if (activeStudentMasterIdList != null)
                {
                    objStudentMaster.Id = 0;
                    objStudentMaster.StudentName = "None";
                    activeStudentMasterIdList.Insert(0, objStudentMaster);
                    ddlStudent.DataSource = activeStudentMasterIdList;
                    ddlStudent.DataValueField = "Id";
                    ddlStudent.DataTextField = "StudentName";
                    ddlStudent.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        
        public void BindChartAccount()
        {
            try
            {
                ChartofAccountDAL ActiveAccountDAL = new ChartofAccountDAL();
                List<ChartofAccount> ActiveListAccount = ActiveAccountDAL.ChartofAccountSelect();
                ChartofAccount activeChartAccount = new ChartofAccount();
                if (ActiveListAccount != null)
                {
                    activeChartAccount.Id = 0;
                    activeChartAccount.Description = "None";
                    ActiveListAccount.Insert(0, activeChartAccount);
                    ddlChartOfAccount.DataSource = ActiveListAccount;
                    ddlChartOfAccount.DataValueField = "Id";
                    ddlChartOfAccount.DataTextField = "Description";
                    ddlChartOfAccount.DataBind();
                }
            }
           
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                       UpdateData(ActiveId);
                  
                }
            }
            catch
            {
                //  MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }

        


        public void UpdateData(int Id)
        {
            try
            {
                DetailChallanDescriptionDAL objDetailChallanDescriptionDAL = new DetailChallanDescriptionDAL();
                DetailChallanDescription objDetailChallanDescription = objDetailChallanDescriptionDAL.DetailChallanDescriptionGetById(Id);
                if (objDetailChallanDescription != null)
                {

                    hfDetailChallanDescription.Value = objDetailChallanDescription.Id.ToString();
                    txtCode.Attributes.Add("value", objDetailChallanDescription.ChallanCode);
                    txtReceipt.Text = objDetailChallanDescription.ReceiptNo.ToString();
                    ddlStudent.SelectedItem.Text = objDetailChallanDescription.StudentName.ToString();
                    ddlChartOfAccount.SelectedItem.Text = objDetailChallanDescription.Account.ToString();
                    RecevDate.Text = objDetailChallanDescription.ReceivedDate.ToString();
                    txtLateFee.Text = objDetailChallanDescription.LateFee.ToString();
                    ddlAmount.SelectedItem.Text = objDetailChallanDescription.Amount.ToString();
                    objDetailChallanDescription.Total = Convert.ToDecimal(txtTotal.Value.ToString());
                }

            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
        }

            }

        private bool IPost()
        {


            bool IsPost = true;


            ChallanDescriptionTableDAL activeChallanDescriptionTblDAL = new ChallanDescriptionTableDAL();
            ChallanDescriptionTable activeChallanDescriptionTbl = new ChallanDescriptionTable();
            List<ChallanDescriptionTable> _listChallanDescriptionTable = new List<ChallanDescriptionTable>();

            if (!string.IsNullOrEmpty(hfChallanDescriptionID.Value))
            {
                activeChallanDescriptionTbl.Id = Convert.ToInt32(hfChallanDescriptionID.Value);
            }

            //if (!string.IsNullOrEmpty(txtCode.Value))
            //{
            //    activeChallanDescriptionTbl.ChallanCode = txtCode.Value;
            //}
            //else
            //{
            //    IsPost = false;
            //}  

            if (!string.IsNullOrEmpty(ddlStudent.SelectedItem.Text))
            {
                activeChallanDescriptionTbl.StudentName = ddlStudent.SelectedItem.Text.ToString();

            }
            else
            {
                IsPost = false;
            }


            if (!string.IsNullOrEmpty(ddlChartOfAccount.Text))
            {
                activeChallanDescriptionTbl.Account = ddlChartOfAccount.SelectedItem.Text.ToString();
            }
            else
            {
                IsPost = false;
            }


            if (!string.IsNullOrEmpty(txtReceipt.Text))
            {
                activeChallanDescriptionTbl.ReceiptNo = txtReceipt.Text.ToString();
            }
            else
            {
                IsPost = false;
            }


            if (!string.IsNullOrEmpty(RecevDate.Text))
            {
                activeChallanDescriptionTbl.ReceivedDate = RecevDate.Text.ToString();
            }
            else
            {
                IsPost = false;
            }



            if (!string.IsNullOrEmpty(txtLateFee.Text))
            {
                activeChallanDescriptionTbl.LateFee = txtLateFee.Text.ToString();
            }
            else
            {
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(ddlAmount.Text))
            {
                activeChallanDescriptionTbl.Amount = ddlAmount.SelectedItem.Text.ToString();
            }
            else
            {
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(txtTotal.Value))
            {
                // TotalAmount();
                txtTotal.Value = (Convert.ToInt32(txtLateFee.Text) + Convert.ToInt32(ddlAmount.SelectedItem.Text)).ToString();
                activeChallanDescriptionTbl.Total = Convert.ToDecimal(txtTotal.Value);
                //   activeChallanDescriptionTbl.Total = txtTotal.Value.ToString();
                //  activeChallanDescriptionTbl.Total = totalprice.ToString();

            }
            else
            {
                IsPost = false;
            }


            if (IsPost == true)
            {
                if (btnPost.Text == "Post")
                {
                    UnitId = activeChallanDescriptionTblDAL.ChallanDescriptionTblInsert(activeChallanDescriptionTbl);

                }


                else if (btnPost.Text == "Update")
                {
                    if (activeChallanDescriptionTblDAL.ChallanDescriptionTblUpdate(activeChallanDescriptionTbl) == true)
                        IsPost = true;
                }
            }


            return IsPost;
        }

        private bool TPost()
        {

            if (ddlStudent.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all Fields Correctly";
                return false;
            }

            _lisChallanDescriptionTable = (List<ChallanDescriptionTable>)ViewState["ChallanDescriptionTable"];
            decimal totalprice = 0.00m;
            if (!string.IsNullOrEmpty(txtLateFee.Text))
            {
                decimal latefee = Convert.ToInt32(txtLateFee.Text);
                int amount = Convert.ToInt32(ddlAmount.SelectedValue);
                decimal total = amount + latefee;
                //decimal discount = Convert.ToDecimal(txtDiscount.Text);
                //decimal dis = (total * discount) / 100;
                //decimal balance = total - dis;
                totalprice = total;
            }
            else
            {
                decimal LateFees = 0.00m;
                int Fees = 0;
                if (!string.IsNullOrEmpty(txtLateFee.Text))
                {
                    LateFees = Convert.ToDecimal(txtLateFee.Text);
                }
                if (!string.IsNullOrEmpty(ddlAmount.SelectedValue))
                {
                    Fees = Convert.ToInt32(ddlAmount.Text);
                }

                decimal total = Fees + LateFees;
                totalprice = total;
            }


            bool _post = true;
            ChallanDescriptionTableDAL activeSubjectTopicDAL = new ChallanDescriptionTableDAL();
            List<ChallanDescriptionTable> activeSubjectTopicList = new List<ChallanDescriptionTable>();
            if (ViewState["ChallanDescriptionTable"] != null)
            {
                activeSubjectTopicList = (List<ChallanDescriptionTable>)ViewState["ChallanDescriptionTable"];
            }

            //var _item = _listApproval.Find(x => x.FormID == Convert.ToInt16(ddlForms.SelectedItem.Value) && x.UserID == Convert.ToInt16(ddlUser.SelectedItem.Value));
            //if (_item != null)
            //{
            //    msgAleart.Visible = true;
            //    lblMessage.Text = "Duplicate Value not Allowed";
            //    ddlForms.ClearSelection();
            //    ddlUser.ClearSelection();
            //    txtSequence.Value = "";
            //    return false;
            //}

            ChallanDescriptionTable activeSubjectTopic = new ChallanDescriptionTable();
            if (ActiveId == 0)
            {
                activeSubjectTopic.Id = Convert.ToInt16(activeSubjectTopicDAL.MaxChallanDescriptionTableID().Tables[0].Rows[0][0]);
            }
            else
            {
                activeSubjectTopic.Id = ActiveId;
            }

            //activeSubjectSection.Id = Convert.ToInt32(TextBoxSubjectSection.Text);

            //  activeSubjectSection.Id = Convert.ToInt16(hfSubjectSection.Value);
            activeSubjectTopic.Id = Convert.ToInt16(ddlStudent.SelectedValue);
            activeSubjectTopic.StudentName = ddlStudent.SelectedItem.Text;
            activeSubjectTopic.Id = Convert.ToInt16(ddlChartOfAccount.SelectedValue);
            activeSubjectTopic.Account = ddlChartOfAccount.SelectedItem.Text;
            activeSubjectTopic.Id = Convert.ToInt16(ddlAmount.SelectedValue);
            activeSubjectTopic.Amount = ddlAmount.SelectedItem.Text;
            activeSubjectTopic.ReceiptNo = txtReceipt.Text.ToString();
            activeSubjectTopic.ReceivedDate = RecevDate.Text.ToString();
            activeSubjectTopic.LateFee = txtLateFee.Text.ToString();
            activeSubjectTopic.Total = totalprice;
            txtTotal.Value= (Convert.ToInt32(txtLateFee.Text) + Convert.ToInt32(ddlAmount.SelectedItem.Text)).ToString();
               activeSubjectTopic.Total = Convert.ToInt32(txtTotal.Value.ToString());
            //if (!string.IsNullOrEmpty(txtTotal.Value))
            //{
            //    // txtTotal.Value = Balance;
            //    txtTotal.Value = (Convert.ToInt32(txtLateFee.Text) + Convert.ToInt32(ddlAmount.SelectedItem.Text)).ToString();
            //    activeSubjectTopic.Total = Convert.ToDecimal(txtTotal.Value);
            //    //     activeSubjectTopic.Total = string.IsNullOrEmpty(txtTotal.Value) ? 0 : Convert.ToInt16(txtTotal.Value);
            //}
            //else
            //{
            //    _post = false;
            //}

            if (rowIndex >= 0)
            {
                activeSubjectTopicList.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                txtReceipt.Text = "";
                txtLateFee.Text = "";
                RecevDate.Text = "";
               // txtTotal.Value = "";
                ddlStudent.ClearSelection();
                ddlChartOfAccount.ClearSelection();
                ddlAmount.ClearSelection();               

            }

            activeSubjectTopicList.Add(activeSubjectTopic);
            GridViewChallanDescription.DataSource = activeSubjectTopicList;
            GridViewChallanDescription.DataBind();
            ViewState["ChallanDescriptionTable"] = activeSubjectTopicList;
            lblMessage.Text = "";
            txtReceipt.Text = "";
            txtLateFee.Text = "";
            RecevDate.Text = "";
            txtTotal.Value = txtTotal.Value.ToString();
            ddlStudent.ClearSelection();
            ddlChartOfAccount.ClearSelection();
            ddlAmount.ClearSelection();
            
            return _post;
        }

        private void GetAllChallanDescription()
        {
            ChallanDescriptionTableDAL objChallanDescription = new ChallanDescriptionTableDAL();
            DataSet ds = objChallanDescription.GetALlChallanDescription();
            if (ds != null)
            {
                GridViewChallanDescription.DataSource = ds;
                GridViewChallanDescription.DataBind();
            }
            else
            {
                GridViewChallanDescription.DataSource = null;
                GridViewChallanDescription.DataBind();
            }
        }

        public void ClearGrid()
        {
            List<ChallanDescriptionTable> _listChallanDescriptionTable = new List<ChallanDescriptionTable>();
            if (rowIndex >= 0)
            {
                _listChallanDescriptionTable.RemoveAt(rowIndex);
                rowIndex = -1;
                ddlChartOfAccount.ClearSelection();
                ddlStudent.ClearSelection();
                txtReceipt.Text = "";
                ddlAmount.ClearSelection();
                RecevDate.Text = "";
                txtLateFee.Text = "";
                txtTotal.Value = "";
            }
        }
        
        private bool Save()
        {


            bool IsSave = true;


            DetailChallanDescriptionDAL objDetailChallanDescriptionDAL = new DetailChallanDescriptionDAL();
            DetailChallanDescription objDetailChallanDescription = new DetailChallanDescription();

            if (!string.IsNullOrEmpty(hfDetailChallanDescription.Value))
            {
                objDetailChallanDescription.Id = Convert.ToInt32(hfDetailChallanDescription.Value);
            }

            if (!string.IsNullOrEmpty(txtCode.Value))
            {
                objDetailChallanDescription.ChallanCode = txtCode.Value;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(txtReceipt.Text))
            {
                objDetailChallanDescription.ReceiptNo = txtReceipt.Text;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlStudent.Text))
            {
                objDetailChallanDescription.StudentName = ddlStudent.SelectedItem.Text.ToString();
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(RecevDate.Text))
            {
                objDetailChallanDescription.ReceivedDate = RecevDate.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlChartOfAccount.Text))
            {
                objDetailChallanDescription.Account = ddlChartOfAccount.SelectedItem.Text.ToString();
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(txtLateFee.Text))
            {
                objDetailChallanDescription.LateFee = txtLateFee.Text.ToString();
            }
            else
            {
                
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlAmount.Text))
            {
                objDetailChallanDescription.Amount = ddlAmount.SelectedItem.Text.ToString();
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(txtTotal.Value))
            {
                txtTotal.Value = (Convert.ToInt32(txtLateFee.Text) + Convert.ToInt32(ddlAmount.SelectedItem.Text)).ToString();
                objDetailChallanDescription.Total = Convert.ToDecimal( txtTotal.Value);
            }
            else
            {
                IsSave = false;
            }


            if (IsSave == true)
            {
                if (btnChallanSave.Text == "Save")
                {
                    UnitId = objDetailChallanDescriptionDAL.DetailChallanDescriptionInsert(objDetailChallanDescription);
                    Response.Redirect("ListOfDetailChallanDescription.aspx");
                }

                else if (btnChallanSave.Text == "Update")
                {
                    if (objDetailChallanDescriptionDAL.DetailChallanDescriptionUpdate(objDetailChallanDescription) == true)

                        IsSave = true;
                    Response.Redirect("ListOfDetailChallanDescription.aspx");
                }
            }

            return IsSave;
        }
     
        public void Initilaize()
        {
            try
            {
                DetailChallanDescriptionDAL activeDetailChallanDescriptionDAL = new DetailChallanDescriptionDAL();
                DetailChallanDescription activeMemberMaxId = activeDetailChallanDescriptionDAL.DetailChallanDescriptionGetMaxId();
                string caption = "CHD-000001";
                if (activeMemberMaxId != null)
                {
                    string theString = activeMemberMaxId.ChallanCode;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtCode.Value = "CHD-00000" + code.ToString();
                }
                else
                {
                    txtCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void Clear()
        {
            ChallanId = 0;
            ActiveId = 0;
            ddlStudent.ClearSelection();
            ddlChartOfAccount.ClearSelection();
            RecevDate.Text = string.Empty;
            txtReceipt.Text = string.Empty;
            txtLateFee.Text = string.Empty;
            ddlAmount.ClearSelection();
            txtTotal.Value = string.Empty;
            GridViewChallanDescription.DataSource= string.Empty;
            ViewState["ChallanDescriptionTable"] = null;
            GridViewChallanDescription.SelectedIndex = 0;
            GridViewChallanDescription.DataBind();
            ViewState["ChallanDescriptionTable"] = (List<ChallanDescriptionTable>)null;
            ViewState["ChallanDescriptionTable"] = (ChallanDescriptionTableDAL)null;
            Initilaize();
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    ActiveId = 0;
                    Response.Redirect("~/SchoolManagementModel/ListOfDetailChallanDescription.aspx", false);
                    Context.ApplicationInstance.CompleteRequest();
                    txtTotal.Value = string.Empty;
                    _lisChallanDescriptionTable.RemoveAt(rowIndex);
                    //Clear();
                }
            }
            catch (Exception)
            {
                //     throw;
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }



        protected void ShowChallan_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListOfChallanDescription.aspx");
        }

        protected void btnPost_Click(object sender, EventArgs e)
        {
            //try
            //{
            if (TPost())
            {
                //GridViewChallanDescription.DataSource = null;
                //GridViewChallanDescription.DataBind();
            }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}

            //try
            //{
            //    if (IPost())
            //    {
            //        ActiveId = 1;
            //        GridViewChallanDescription.DataSource = null;
            //        GridViewChallanDescription.DataBind();
            //        GetAllChallanDescription();
            //        //  TPost();
            //    }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }
         

        private void UpdateChallan(int id)
        {
            if (GridViewChallanDescription.Rows.Count > 0)
            {
                List<DetailChallanDescription> activeDetailChallanDescriptionList = (List<DetailChallanDescription>)ViewState["DetailChallanDescription"];

                foreach (DetailChallanDescription item in activeDetailChallanDescriptionList)
                {
                    if (activeDetailChallanDescriptionList.IndexOf(item) == id)
                    {
                        ddlStudent.SelectedItem.Text = item.StudentName.ToString();
                        txtReceipt.Text = item.ReceiptNo.ToString();
                        RecevDate.Text = item.ReceivedDate.ToString();
                        ddlChartOfAccount.SelectedItem.Text = item.Account.ToString();
                        txtLateFee.Text = item.LateFee.ToString();
                        ddlAmount.SelectedItem.Text = item.Amount.ToString();
                        txtTotal.Value = item.Total.ToString();
                    }
                }
            }
        }
        protected void ddlStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChallanId = Convert.ToInt32(ddlStudent.SelectedValue);
        }
        protected void GridViewChallanDescription_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewChallanDescription_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        int totSubTot = 0;
        protected void GridViewChallanDescription_RowDataBound(object sender, GridViewRowEventArgs e)
        {
           
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                totSubTot += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "Total"));
            }
            txtTotal.Value = totSubTot.ToString("0.00");
  
        }        
        protected void GridViewChallanDescription_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/ChallanDescriptionForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    ChallanDescriptionTableDAL objChallanDescriptionDAL = new ChallanDescriptionTableDAL();
            //    objChallanDescriptionDAL.ChallanDescriptionTblDelete(iStID);
            //    Response.Redirect("ChallanDescriptionForm.aspx");

            //}  

            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                ChallanDescriptionTableDAL objChallanDescriptionTableDAL = new ChallanDescriptionTableDAL();
                //if (iStID > 0)
                //{
                //    objChallanDescriptionTableDAL.ChallanDescriptionTblDelete(iStID);
                    GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                    rowIndex = row.RowIndex;
                    int id = Convert.ToInt32(e.CommandArgument);
                    _lisChallanDescriptionTable = (List<ChallanDescriptionTable>)ViewState["ChallanDescriptionTable"];
                      _lisChallanDescriptionTable.RemoveAt(rowIndex);
                    GridViewChallanDescription.DataSource = _lisChallanDescriptionTable;
                    GridViewChallanDescription.DataBind();
                  //   Response.Redirect("ChallanDescriptionForm.aspx");
                    //  }
                
            }

            ////if (e.CommandName == "Edit")
            ////{
            ////    int iStID = Int32.Parse(e.CommandArgument.ToString());
            ////    if (iStID > 0)
            ////    {
            ////        Response.Redirect("~/SchoolManagementModel/ChallanDescriptionForm.aspx?Id=" + iStID);
            ////    }
            ////}
            ////else
            ////{
            ////    int iStID = Int32.Parse(e.CommandArgument.ToString());
            ////    ChallanDescriptionTableDAL objChallanDescriptionTblDAL = new ChallanDescriptionTableDAL();
            ////    if (iStID > 0)
            ////    {
            ////       
            ////        //  rowIndex = 100;
            ////        objChallanDescriptionTblDAL.ChallanDescriptionTblDelete(iStID);
            ////      GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);  
            // List<ChallanDescriptionTable> activeChallanDescriptionTblList = (List<ChallanDescriptionTable>)ViewState["ChallanDescriptionTable"];
            ////          //   activeChallanDescriptionTblList.RemoveAt(rowIndex);
            ////        GridViewChallanDescription.DataSource = activeChallanDescriptionTblList;
            ////        GridViewChallanDescription.DataBind();
            ////        //  Response.Redirect("DetailFeeForm.aspx");
            ////    }
            ////}
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }

        protected void btnReceived_Click(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}