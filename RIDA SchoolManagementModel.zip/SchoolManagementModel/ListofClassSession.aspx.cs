﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;

namespace WebDesk_ERP.SchoolManagementModel
{

   
    public partial class ListofClassSession : System.Web.UI.Page
    {
        ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
        ClassSession objClassSession = new ClassSession();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
              //  BindFeesMaster();
             //   bindtreeview();
              //  loadSession();
            }
        }

        private void BindFeesMaster()
        {
            try
            {
                ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
                ClassSession objClassSession = new ClassSession();
                List<ClassSession> activeClassSessionIdList = objClassSessionDAL.ClassSessionSelectNew();
                if (activeClassSessionIdList != null)
                {
                    GridViewListofClassSession.DataSource = ViewState["activeClassSessionIdList"] as List<ClassSession>;
                    GridViewListofClassSession.DataBind();
                }
            }
            catch (Exception)
            {
      //          throw;
            }
        }
        public void bindtreeview()
        {
            DataTable dt = objClassSessionDAL.GetData("SELECT * From  ClassSession where Running='True'");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["id"].ToString()
                };
                if (parentId == 0)
                {
                    TreeViewClassSession.Nodes.Add(child);
                    dtChild = objClassSessionDAL.GetData("SELECT * From  ClassSession where Running='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = objClassSessionDAL.GetData("SELECT * From  ClassSession where Running='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }

        public void loadSession()
        {
            ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
            List<ClassSession> activeClassSessionIdList = objClassSessionDAL.ClassSessionSelectNew();
            if (activeClassSessionIdList != null)
            {
                GridViewListofClassSession.DataSource = ViewState["activeClassSessionIdList"] as List<ClassSession>;
                GridViewListofClassSession.DataBind();
            }
        }




        protected void GridViewListofClassSession_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridViewListofClassSession_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewListofClassSession_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/ClassSessionForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
                objClassSessionDAL.ClassSessionDelete(iStID);
                //   BindFeesMaster();
                // loadSession();
                Response.Redirect("ListofClassSession.aspx");
                bindtreeview();
            }
        }

        protected void TreeViewClassSession_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}