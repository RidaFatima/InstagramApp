﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Configuration;
using System.Data.SqlClient;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ClassMasterForm : System.Web.UI.Page
    {
        public static int ActiveId { get; set; }
        public static int rowIndex { get; set; }
        public int Id { get; set; }
        List<ClassMaster> activeClassMasterIdList = new List<ClassMaster>();
        List<ClassFee> activeClassFeeList = new List<ClassFee>();
        ClassMasterDAL objClassMasterDAL = new ClassMasterDAL();
        ClassMaster objClassMaster = new ClassMaster();
        public int getid;
        public int UnitId;
        public static string Code = null;
        protected void Page_Load(object sender, EventArgs e)
        {
           
            ClassMaster objClassMaster = new ClassMaster();
           
            //BindGridView();
            //loadSession();
            
            if (!IsPostBack)
            {
                rowIndex = -1;
                BindDegreeLevel();
                BindFeeTypeMaster();
                BindAccount();
                BindChartAccount();
                Initilaize();
                GetAllFee();
                GetId();


                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    FeeSaveBtn.Text = "Update";
                    ActiveId = 1;
                    loadSession();

                    BindDegreeLevel();
                    BindFeeTypeMaster();
                    BindAccount();
                    BindChartAccount();
                    GetId();                    

                }
                else
                {
                    FeeSaveBtn.Text = "Save";
                    ActiveId = 0;
               //     Clear();
                 
                }

            }
        }

        public void UpdateData(int Id)
        {
            try
            {
                ClassMasterDAL activeClassMasterDAL = new ClassMasterDAL();
                ClassMaster objClassMaster = activeClassMasterDAL.ClassMasterGetById(Id);
                if (objClassMaster != null)
                {
                    hfClassMasterID.Value = objClassMaster.Id.ToString();
                    txtClassMasterCode.Attributes.Add("value", objClassMaster.Code);
                    txtClassMasterDescription.Text = objClassMaster.Description;
                    ddlRecieveable.SelectedItem.Text = objClassMaster.Recieveable.ToString();
                    ddlRevenue.SelectedItem.Text = objClassMaster.Revenue.ToString();
                    ddlClassMaster.SelectedItem.Text = objClassMaster.FeeType.ToString();
                    ddlLevelMaster.SelectedItem.Text = objClassMaster.Levels.ToString();
                    CheckBoxRunning.Checked = Convert.ToBoolean(objClassMaster.Running);
                  
                }

            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        private void BindGridView()
        {
            try
            {
                ClassMasterDAL objClassMasterDAL = new ClassMasterDAL();
                List<ClassMaster> activeFeeMasterIdList = objClassMasterDAL.ClassMasterSelectNew();
                if (activeClassMasterIdList != null)
                {
                    GridViewClassMaster.DataSource = ViewState["activeClassMasterIdList"] as List<ClassMaster>;
                    GridViewClassMaster.DataBind();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);
                }
            }
            catch
            {
                //  MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }

        public void BindDegreeLevel()
        {
            try
            {
                DegreeLevelDAL ActiveDegreelevelDAL = new DegreeLevelDAL();
                List<DegreeLevel> ActiveDegreeLevelList = ActiveDegreelevelDAL.DegreeLevelSelect();
                DegreeLevel activeDegreeLevel = new DegreeLevel();
                if (ActiveDegreeLevelList != null)
                {
                    activeDegreeLevel.Id = 0;
                    activeDegreeLevel.Description = "None";
                    ActiveDegreeLevelList.Insert(0, activeDegreeLevel);
                    ddlLevelMaster.DataSource = ActiveDegreeLevelList;
                    ddlLevelMaster.DataValueField = "Id";
                    ddlLevelMaster.DataTextField = "Description";
                    ddlLevelMaster.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindFeeTypeMaster()
        {
            try
            {
                FeeTypeMasterDAL objFeeTypeMasterDAL = new FeeTypeMasterDAL();
                List<FeeTypeMaster> activeFeeTypeMasterIdList = objFeeTypeMasterDAL.FeeTypeMasterSelect();
                FeeTypeMaster objFeeTypeMaster = new FeeTypeMaster();
                if (activeFeeTypeMasterIdList != null)
                {
                    objFeeTypeMaster.Id = 0;
                    objFeeTypeMaster.Description = "None";
                    activeFeeTypeMasterIdList.Insert(0, objFeeTypeMaster);
                    ddlClassMaster.DataSource = activeFeeTypeMasterIdList;
                    ddlClassMaster.DataValueField = "Id";
                    ddlClassMaster.DataTextField = "Description";
                    ddlClassMaster.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        public void BindAccount()
        {
            try
            {
                ChartofAccountDAL ActiveDAL = new ChartofAccountDAL();
                List<ChartofAccount> ActiveList = ActiveDAL.ChartofAccountSelect();
                ChartofAccount activeAccount = new ChartofAccount();
                if (ActiveList != null)
                {
                    activeAccount.Id = 0;
                    activeAccount.AccountName = "None";
                    ActiveList.Insert(0, activeAccount);
                    ddlRecieveable.DataSource = ActiveList;
                    ddlRecieveable.DataValueField = "Id";
                    ddlRecieveable.DataTextField = "AccountName";
                    ddlRecieveable.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        public void BindChartAccount()
        {
            try
            {
                ChartofAccountDAL ActiveAccountDAL = new ChartofAccountDAL();
                List<ChartofAccount> ActiveListAccount = ActiveAccountDAL.ChartofAccountSelect();
                ChartofAccount activeChartAccount = new ChartofAccount();
                if (ActiveListAccount != null)
                {
                    activeChartAccount.Id = 0;
                    activeChartAccount.Description = "None";
                    ActiveListAccount.Insert(0, activeChartAccount);
                    ddlRevenue.DataSource = ActiveListAccount;
                    ddlRevenue.DataValueField = "Id";
                    ddlRevenue.DataTextField = "Description";
                    ddlRevenue.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void loadSession()
        {
            ClassMasterDAL objClassMasterDAL = new ClassMasterDAL();
            List<ClassMaster> activeClassMasterIdList = objClassMasterDAL.ClassMasterSelectNew();
            if (activeClassMasterIdList != null)
            {
                GridViewClassMaster.DataSource = ViewState["activeClassMasterIdList"] as List<ClassMaster>;
                GridViewClassMaster.DataBind();
            }
        }

        private void UpdateClassMaster(int Id)
        {
            if (GridViewClassMaster.Rows.Count > 0)
            {
                List<ClassMaster> activeClassMasterIdList = (List<ClassMaster>)ViewState["ClassMaster"];

                foreach (ClassMaster item in activeClassMasterIdList)
                {
                    //if (activeFeeMasterIdList.IndexOf(item) == Id)
                    // {
                    //      FeeMasterId = item.Id;
                    ddlLevelMaster.SelectedItem.Text = item.Levels.ToString();
                    ddlClassMaster.SelectedItem.Text = item.FeeType.ToString();
                    //  txtAccountCode.Text = item.AccountCode.ToString();
                    ddlRecieveable.SelectedItem.Text = item.Recieveable.ToString();
                    ddlRevenue.SelectedItem.Text = item.Revenue.ToString();
                    // }
                }
            }
        }

        public void Initilaize()
        {
            try
            {
                ClassMasterDAL objClassMasterDAL = new ClassMasterDAL();
                ClassMaster objClassMaster = objClassMasterDAL.ClassMasterGetMaxId();
                string caption = "CM-00001";
                if (objClassMaster != null)
                {
                    string theString = objClassMaster.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtClassMasterCode.Value = "CM-0000" + code.ToString();
                }
                else
                {
                    txtClassMasterCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        public void AllClear()
        {
            try
            {
                ActiveId = 0;

                txtClassMasterDescription.Text = string.Empty;
                ddlRevenue.SelectedIndex = 0;
                ddlRecieveable.SelectedIndex = 0;
                ddlClassMaster.SelectedIndex = 0;
                ddlLevelMaster.SelectedIndex = 0;
                CheckBoxRunning.Checked = false;

                hfClassMasterID.Value = string.Empty;
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
        public void Clear()
        {
            GridViewClassMaster.DataSource = string.Empty;
            GridViewClassMaster.DataBind();
            ViewState["ClassFee"] = (List<ClassFee>)null;
            ActiveId = 0;
            rowIndex = -1;
            Initilaize();
            AllClear();

        }
               
        private bool Save()
        {

            bool IsSave = true;

            ClassMasterDAL objClassMasterDAL = new ClassMasterDAL();
            ClassMaster objClassMaster = new ClassMaster();

            if (!string.IsNullOrEmpty(hfClassMasterID.Value))
            {
                objClassMaster.Id = Convert.ToInt32(hfClassMasterID.Value);
            }

            if (!string.IsNullOrEmpty(txtClassMasterDescription.Text))
            {
                objClassMaster.Description = txtClassMasterDescription.Text;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(txtClassMasterCode.Value))
            {
                objClassMaster.Code = txtClassMasterCode.Value;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlLevelMaster.Text))
            {
                objClassMaster.Levels = ddlLevelMaster.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlRevenue.Text))
            {
                objClassMaster.Revenue = ddlRevenue.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlRecieveable.Text))
            {
                objClassMaster.Recieveable = ddlRecieveable.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlClassMaster.SelectedItem.Text))
            {
                objClassMaster.FeeType = ddlClassMaster.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }

            objClassMaster.Running = CheckBoxRunning.Checked;

            if (IsSave == true)
            {
                if (FeeSaveBtn.Text == "Save")
                {
                    UnitId = objClassMasterDAL.ClassMasterInsert(objClassMaster);
                    Response.Redirect("ListofClassMaster.aspx");
                }

                else if (FeeSaveBtn.Text == "Update")
                {
                    if (objClassMasterDAL.ClassMasterUpdate(objClassMaster) == true)

                        IsSave = true;
                    Response.Redirect("ListofClassMaster.aspx");
                }
            }
            return IsSave;
        }

        //private bool IPost()
        //{

        //    bool IsPost = true;

        //    ClassFeeDAL activeClassFeeDAL = new ClassFeeDAL();
        //    ClassFee activeClassFee = new ClassFee();

        //    if (!string.IsNullOrEmpty(hfClassFee.Value))
        //    {
        //        activeClassFee.Id = Convert.ToInt32(hfClassFee.Value);
        //    }

        //    if (!string.IsNullOrEmpty(ddlRecieveable.SelectedItem.Text))
        //    {
        //        activeClassFee.Recieveable = ddlRecieveable.SelectedItem.ToString();
        //    }
        //    else
        //    {
        //        IsPost = false;
        //    }

        //    if (!string.IsNullOrEmpty(ddlRevenue.Text))
        //    {
        //        activeClassFee.Revenue = ddlRevenue.SelectedItem.ToString();
        //    }
        //    else
        //    {
        //        IsPost = false;
        //    }


        //    if (!string.IsNullOrEmpty(ddlClassMaster.Text))
        //    {
        //        activeClassFee.FeeType = ddlClassMaster.SelectedItem.ToString();
        //    }
        //    else
        //    {
        //        IsPost = false;
        //    }

        //    activeClassFee.Running = CheckBoxRunning.Checked;

        //    if (IsPost == true)
        //    {
        //        if (buttonClassMasterPost.Text == "Post")
        //        {
        //            UnitId = activeClassFeeDAL.ClassFeeInsert(activeClassFee);
        //           // Response.Redirect("ClassMasterForm.aspx");
        //            //GridViewClassMaster.Columns.Clear();
        //            // GridViewFeeMaster.DataSource = null;
        //        }

        //        else if (buttonClassMasterPost.Text == "Update")
        //        {
        //            if (activeClassFeeDAL.ClassFeeUpdate(activeClassFee) == true)
        //                IsPost = true;
        //         //   Response.Redirect("ClassMasterForm.aspx");
        //        }
        //    }
        //    return IsPost;
        //}

        public bool Post()
        {
            if (ddlClassMaster.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all the Fields Correctly";
                return false;
            }
            bool _post = true;
            ClassFeeDAL _dalApproval = new ClassFeeDAL();
            List<ClassFee> _listApproval = new List<ClassFee>();
            if (ViewState["ClassFee"] != null)
            {
                _listApproval = (List<ClassFee>)ViewState["ClassFee"];
            }

            //var _item = _listApproval.Find(x => x.FormID == Convert.ToInt16(ddlForms.SelectedItem.Value) && x.UserID == Convert.ToInt16(ddlUser.SelectedItem.Value));
            //if (_item != null)
            //{
            //    msgAleart.Visible = true;
            //    lblMessage.Text = "Duplicate Value not Allowed";
            //    ddlForms.ClearSelection();
            //    ddlUser.ClearSelection();
            //    txtSequence.Value = "";
            //    return false;
            //}
            ClassFee _approval = new ClassFee();
            if (ActiveId == 0)
            {
                _approval.Id = Convert.ToInt16(_dalApproval.MaxClassFeeID().Tables[0].Rows[0][0]);
            }
            else
            {
                _approval.Id = ActiveId;
            }

            _approval.Id = Convert.ToInt16(ddlClassMaster.SelectedValue);
            _approval.FeeType = ddlClassMaster.SelectedItem.Text;
            _approval.Id = Convert.ToInt16(ddlRecieveable.SelectedValue);
            _approval.Recieveable = ddlRecieveable.SelectedItem.Text;
            _approval.Id = Convert.ToInt16(ddlRevenue.SelectedValue);
            _approval.Revenue = ddlRevenue.SelectedItem.Text;
            _approval.Id = Convert.ToInt16(CheckBoxRunning.Checked);
            _approval.Running = CheckBoxRunning.Checked;

            if (rowIndex >= 0)
            {
                _listApproval.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                ddlClassMaster.ClearSelection();
                ddlRevenue.ClearSelection();
                ddlRecieveable.ClearSelection();
                CheckBoxRunning.Checked = false;
                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";

            }

            _listApproval.Add(_approval);
            GridViewClassMaster.DataSource = _listApproval;
            GridViewClassMaster.DataBind();
            ViewState["ClassFee"] = _listApproval;
            lblMessage.Text = "";
            ddlClassMaster.ClearSelection();
            ddlRecieveable.ClearSelection();
            ddlRevenue.ClearSelection();
            CheckBoxRunning.Checked = false;
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;
        }

        private void GetAllFee()
        {
            ClassFeeDAL objFee = new ClassFeeDAL();
            DataSet ds = objFee.GetALlFee();
            if (ds != null)
            {
                GridViewClassMaster.DataSource = ds;
                GridViewClassMaster.DataBind();
            }
            else
            {
                GridViewClassMaster.DataSource = null;
                GridViewClassMaster.DataBind();
            }
        }

        private void DisplayClassMaster(int ActiveId)
        {
            try
            {
                ClassMasterDAL activeClassMasterDAL = new ClassMasterDAL();
                ClassMaster activeClassMaster = activeClassMasterDAL.ClassMasterGetById(ActiveId);
                if (activeClassMaster != null)
                {
                    //  activeFeeMaster.AccountCode = Convert.ToInt32(ddlchartAccount.Text);
                    ddlClassMaster.SelectedValue = activeClassMaster.FeeType.ToString();
                    ddlRecieveable.SelectedValue = activeClassMaster.Recieveable.ToString();
                    ddlRevenue.SelectedValue = activeClassMaster.Revenue.ToString();
                    ddlLevelMaster.SelectedValue = activeClassMaster.Levels.ToString();
                    
                }
            }
            catch (Exception ex)
            {
                //  MessageBox.Show("UpdateProduct: " + ex.Message, "ICT", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        protected void ClassMaster_Save(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    ActiveId = 0;
                    Response.Redirect("~/SchoolManagementModel/ListofClassMaster.aspx", false);
                    Context.ApplicationInstance.CompleteRequest();
                   
                }
            }
            catch (Exception)
            {
                //     throw;
            }
        }
        protected void ClassMaster_Clear(object sender, EventArgs e)
        {
            Clear();
        }
        protected void ButtonToProgram_Click(object sender, EventArgs e)
        {

        }
        protected void ButtonToAll_Click(object sender, EventArgs e)
        {

        }
        protected void buttonClassMasterPost_Click(object sender, EventArgs e)
        {
            if (Post())
            {

            }
            //try
            //{
            //    if (IPost())
            //    {
            //        ActiveId = 1;
            //        GridViewClassMaster.DataSource = null;
            //        GridViewClassMaster.DataBind();
            //        GetAllFee();
            //        ddlRevenue.SelectedIndex = 0;
            //        ddlRecieveable.SelectedIndex = 0;
            //        ddlClassMaster.SelectedIndex = 0;
            //        CheckBoxRunning.Checked = false;
            //        //ActiveId = 0;
            //        // Response.Redirect("~/SchoolManagementModel/ClassMasterForm.aspx", false);
            //        //Context.ApplicationInstance.CompleteRequest();

            //    }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }
        protected void GridViewClassMaster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewClassMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewClassMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/ClassMasterForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    ClassFeeDAL objClassFeeDAL = new ClassFeeDAL();
            //    objClassFeeDAL.ClassFeeDelete(iStID);

            //    // loadSession();
            //    Response.Redirect("ClassMasterForm.aspx");     
            //}
            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                ClassFeeDAL objClassFeePostDAL = new ClassFeeDAL();
                //if (iStID > 0)
                //{
                //    objClassFeePostDAL.ClassFeeDelete(iStID);
                    GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                    rowIndex = row.RowIndex;
                    int id = Convert.ToInt32(e.CommandArgument);
                    activeClassFeeList = (List<ClassFee>)ViewState["ClassFee"];
                    activeClassFeeList.RemoveAt(rowIndex);
                    GridViewClassMaster.DataSource = activeClassFeeList;
                    GridViewClassMaster.DataBind();
                   // Response.Redirect("ClassMasterForm.aspx");
               // }
            }
        }
        protected void GridViewClassMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ddlClassMaster_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int ClassMasterid = 0;
            //ClassMasterid = Convert.ToInt32(ddlClassMaster.SelectedValue);

            //DisplayClassMaster(ClassMasterid);
        }

        protected void ddlRecieveable_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int ClassMasterid = 0;
            //ClassMasterid = Convert.ToInt32(ddlRecieveable.SelectedValue);

            //DisplayClassMaster(ClassMasterid);
        }

        protected void ddlRevenue_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int ClassMasterid = 0;
            //ClassMasterid = Convert.ToInt32(ddlRevenue.SelectedValue);

            //DisplayClassMaster(ClassMasterid);
        }




    }
}