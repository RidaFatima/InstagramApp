﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;


namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class DetailFeeForm : System.Web.UI.Page
    {
        public static int ActiveId { get; set; }
        public static int rowIndex { get; set; }
        public int getid;
        public int UnitId;
        List<FeeDescription> activeFeeDescriptionList = new List<FeeDescription>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rowIndex = -1;
                BindAcadmicSession();
                BindDegreeLevel();
                BindFeeTypeMaster();
                BindStudentName();
                BindClassSession();
                GetAllFee();
                GetId();
                //AllClear();
                
                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    
                    DetailFeeSave.Text = "Update";
                    ActiveId = 1;
            
                }
                else
                {
                    DetailFeeSave.Text = "Save";
                    ActiveId = 0;
                    //   ViewState["FeeDescription"] = new List<FeeDescription>();
                  //  Clear();
                }
            }
        }

        public void BindAcadmicSession()
        {
            try
            {
                AcadmicSessionDAL ActiveDAL = new AcadmicSessionDAL();
                List<AcadmicSession> ActiveList = ActiveDAL.AcadmicSessionSelect();
                AcadmicSession activeSession = new AcadmicSession();
                if (ActiveList != null)
                {
                    activeSession.Id = 0;
                    activeSession.Description = "None";
                    ActiveList.Insert(0, activeSession);
                    ddlSession.DataSource = ActiveList;
                    ddlSession.DataValueField = "Id";
                    ddlSession.DataTextField = "Description";
                    ddlSession.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindClassSession()
        {
            try
            {
                ClassSectionDAL objClassSectionDAL = new ClassSectionDAL();
                List<ClassSection> activeClassSectionIdList = objClassSectionDAL.ClassSectionSelect();
                ClassSection objClassSection = new ClassSection();
                if (activeClassSectionIdList != null)
                {
                    objClassSection.Id = 0;
                    objClassSection.Description = "None";
                    activeClassSectionIdList.Insert(0, objClassSection);
                    ddlClassSection.DataSource = activeClassSectionIdList;
                    ddlClassSection.DataValueField = "Id";
                    ddlClassSection.DataTextField = "Description";
                    ddlClassSection.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        public void BindStudentName()
        {
       
            try
            {
                StudentMasterDAL objStudentMasterDAL = new StudentMasterDAL();
                List<StudentMaster> activeStudentMasterIdList = objStudentMasterDAL.StudentMasterSelectNew();
                StudentMaster objStudentMaster = new StudentMaster();
                if (activeStudentMasterIdList != null)
                {
                    objStudentMaster.Id = 0;
                    objStudentMaster.StudentName = "None";
                    activeStudentMasterIdList.Insert(0, objStudentMaster);
                    ddlStudent.DataSource = activeStudentMasterIdList;
                    ddlStudent.DataValueField = "Id";
                    ddlStudent.DataTextField = "StudentName";
                    ddlStudent.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        public void BindFeeTypeMaster()
        {
            try
            {
                FeeTypeMasterDAL objFeeTypeMasterDAL = new FeeTypeMasterDAL();
                List<FeeTypeMaster> activeFeeTypeMasterIdList = objFeeTypeMasterDAL.FeeTypeMasterSelect();
                FeeTypeMaster objFeeTypeMaster = new FeeTypeMaster();
                if (activeFeeTypeMasterIdList != null)
                {
                    objFeeTypeMaster.Id = 0;
                    objFeeTypeMaster.Description = "None";
                    activeFeeTypeMasterIdList.Insert(0, objFeeTypeMaster);
                    ddlFeesMaster.DataSource = activeFeeTypeMasterIdList;
                    ddlFeesMaster.DataValueField = "Id";
                    ddlFeesMaster.DataTextField = "Description";
                    ddlFeesMaster.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }
        public void BindDegreeLevel()
        {
            try
            {
                DegreeLevelDAL ActiveDegreeDAL = new DegreeLevelDAL();
                List<DegreeLevel> ActiveDegreeList = ActiveDegreeDAL.DegreeLevelSelect();
                DegreeLevel activeDegreeLevel = new DegreeLevel();
                if (ActiveDegreeList != null)
                {
                    activeDegreeLevel.Id = 0;
                    activeDegreeLevel.Description = "None";
                    ActiveDegreeList.Insert(0, activeDegreeLevel);
                    ddlLevel.DataSource = ActiveDegreeList;
                    ddlLevel.DataValueField = "Id";
                    ddlLevel.DataTextField = "Description";
                    ddlLevel.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);
                   
                }
            }
            catch
            {
                //  MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }
        public void UpdateData(int Id)
        {
            try
            {
                DetailFeeDescriptionDAL objDetailFeeDescriptionDAL = new DetailFeeDescriptionDAL();
                DetailFeeDescription objDetailFeeDescription = objDetailFeeDescriptionDAL.DetailFeeDescriptionGetById(Id);
                if (objDetailFeeDescription != null)
                {

                    hfDetailFeeDescription.Value = objDetailFeeDescription.Id.ToString();
                    txtDescription.Text = objDetailFeeDescription.Description;
                    ddlLevel.SelectedItem.Text = objDetailFeeDescription.Class;
                    ddltype.SelectedItem.Text = objDetailFeeDescription.Type;
                    ddlFeesMaster.SelectedItem.Text = objDetailFeeDescription.FeeSection;
                    ddlSession.SelectedItem.Text = objDetailFeeDescription.Session;
                    txtSegmentId.Text = objDetailFeeDescription.SegmentId;
                    IssueDate.Text = objDetailFeeDescription.IssueDate;
                    DueDate.Text = objDetailFeeDescription.DueDate;
                    ValidDate.Text = objDetailFeeDescription.ValidDate;
                    txtFine.Text = objDetailFeeDescription.Fine;
                    ddlStudent.SelectedItem.Text = objDetailFeeDescription.Student;
                    ddlClassSection.SelectedItem.Text = objDetailFeeDescription.StudentSection;

                }

            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }
       
        public void AllClear()
        {
            try
            {
                ActiveId = 0;

                txtDescription.Text = string.Empty;
                ddlSession.SelectedIndex = 0;
                ddlClassSection.SelectedIndex = 0;
                ddlLevel.SelectedIndex = 0;
                ddlFeesMaster.SelectedIndex = 0;
                ddltype.SelectedIndex = 0; ;
                txtFine.Text = string.Empty;
                txtSegmentId.Text = string.Empty;
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

       public void ClearFee()
        {
            try
            {
                ActiveId = 0;
                txtDescription.Text = ".";
                //ddlFeesMaster.SelectedIndex = 0;
                ddltype.SelectedIndex = 0; 
                txtFine.Text = "0.00";
                txtSegmentId.Text = "00";
                IssueDate.Text = "mm/dd/yy";
                DueDate.Text = "mm/dd/yy";
                ValidDate.Text = "mm/dd/yy";
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }
        public void Clear()
        {
            GridViewFeeDescription.DataSource = string.Empty;
            GridViewFeeDescription.SelectedIndex = 0;
            GridViewFeeDescription.DataBind();
         //   ViewState["FeeDescription"] = (FeeDescriptionDAL)null;
          //  ViewState["FeeDescription"] = (List<FeeDescription>)null;
            ActiveId = 0;
         //   rowIndex = -1;
            AllClear();
        }
        private bool Save()
        {


            bool IsSave = true;


            DetailFeeDescriptionDAL objDetailFeeDescriptionDAL = new DetailFeeDescriptionDAL();
            DetailFeeDescription objDetailFeeDescription = new DetailFeeDescription();

            if (!string.IsNullOrEmpty(hfDetailFeeDescription.Value))
            {
                objDetailFeeDescription.Id = Convert.ToInt32(hfDetailFeeDescription.Value);
            }

            if (!string.IsNullOrEmpty(txtDescription.Text))
            {
                objDetailFeeDescription.Description = txtDescription.Text;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(txtSegmentId.Text))
            {
                objDetailFeeDescription.SegmentId = txtSegmentId.Text;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlSession.Text))
            {
                objDetailFeeDescription.Session = ddlSession.SelectedItem.ToString();
            }
            else
            {               
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlClassSection.Text))
            {
                objDetailFeeDescription.StudentSection = ddlClassSection.SelectedItem.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlLevel.Text))
            {
                objDetailFeeDescription.Class = ddlLevel.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddltype.SelectedItem.Text))
            {
                objDetailFeeDescription.Type = ddltype.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlFeesMaster.SelectedItem.Text))
            {
                objDetailFeeDescription.FeeSection = ddlFeesMaster.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlStudent.Text))
            {
                objDetailFeeDescription.Student = ddlStudent.SelectedItem.ToString();
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(IssueDate.Text))
            {
                objDetailFeeDescription.IssueDate = IssueDate.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(DueDate.Text))
            {
                objDetailFeeDescription.DueDate = DueDate.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ValidDate.Text))
            {
                objDetailFeeDescription.ValidDate = ValidDate.Text;
            }
            else
            {
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(txtFine.Text))
            {
                objDetailFeeDescription.Fine = txtFine.Text;
            }
            else
            {
                IsSave = false;
            }

            if (IsSave == true)
            {
                if (DetailFeeSave.Text == "Save")
                {
                    UnitId = objDetailFeeDescriptionDAL.DetailFeeDescriptionInsert(objDetailFeeDescription);
                    Response.Redirect("ListOfDetailFeeDescription.aspx");
                }

                else if (DetailFeeSave.Text == "Update")
                {
                    if (objDetailFeeDescriptionDAL.DetailFeeDescriptionUpdate(objDetailFeeDescription) == true)

                        IsSave = true;
                    Response.Redirect("ListOfDetailFeeDescription.aspx");
                }
            }
            return IsSave;
        }
        protected void btnDetailFeeSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    ActiveId = 1;
                    Response.Redirect("~/SchoolManagementModel/ListOfDetailFeeDescription.aspx", false);
                    Context.ApplicationInstance.CompleteRequest();
                    // GridViewFee.DataSource = null;
                }
            }
            catch (Exception)
            {
                //     throw;
            }
        }

        protected void btnDetailFeeClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        protected void FeeSetUp_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void single_Month_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
      
        protected void GridViewFeeDescription_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewFeeDescription_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }

        protected void GridViewFeeDescription_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            ////if (e.CommandName == "Edit")
            ////{
            ////    int iStID = Int32.Parse(e.CommandArgument.ToString());
            ////    if (iStID > 0)
            ////    {
            ////        Response.Redirect("~/SchoolManagementModel/DetailFeeForm.aspx?Id=" + iStID);
            ////    }
            ////}
            ////else
            ////{
            ////    int iStID = Int32.Parse(e.CommandArgument.ToString());
            ////    FeeDescriptionDAL objFeeDescriptionDAL = new FeeDescriptionDAL();
            ////    if (iStID > 0)
            ////    {
            ////        GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            ////      //  rowIndex = 100;
            ////        objFeeDescriptionDAL.FeeDescriptionDelete(iStID);
            ////        List<FeeDescription> activeFeeDescriptionList = (List<FeeDescription>)ViewState["FeeDescription"];
            ////    //     activeFeeDescriptionList.RemoveAt(rowIndex);
            ////            GridViewFeeDescription.DataSource = activeFeeDescriptionList;
            ////            GridViewFeeDescription.DataBind();
            ////        //  Response.Redirect("DetailFeeForm.aspx");

            ////    }
            ////}  


            //if (e.CommandName == "Edit")
            //{
            //    GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);

            //    rowIndex = row.RowIndex;
            //    int id = Convert.ToInt32(e.CommandArgument);
            //    UpdateData(rowIndex);
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    FeeDescriptionDAL objFeeDescriptionDAL = new FeeDescriptionDAL();
            //    if (iStID > 0)
            //    {
            //        objFeeDescriptionDAL.FeeDescriptionDelete(iStID);
            //    }
            //    //  GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            //    // rowIndex = row.RowIndex;
            //    int id = Convert.ToInt32(e.CommandArgument);
            //    List<FeeDescription> activeFeeDescriptionList = (List<FeeDescription>)ViewState["FeeDescription"];
            //    // activeFeeDescriptionList.RemoveAt(rowIndex);
            //    GridViewFeeDescription.DataSource = activeFeeDescriptionList;
            //    GridViewFeeDescription.DataBind();
            //}
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/DetailFeeForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //       FeeDescriptionDAL objFeeDescriptionDAL = new FeeDescriptionDAL();
            //       if (iStID > 0)
            //   {
            //    objFeeDescriptionDAL.FeeDescriptionDelete(iStID);
            //        Response.Redirect("DetailFeeForm.aspx");
            //    }
            //}
            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                FeeDescriptionDAL objClassFeePostDAL = new FeeDescriptionDAL();
                //if (iStID > 0)
                //{
                //    objClassFeePostDAL.FeeDescriptionDelete(iStID);
                    GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                    rowIndex = row.RowIndex;
                    int id = Convert.ToInt32(e.CommandArgument);
                    activeFeeDescriptionList = (List<FeeDescription>)ViewState["FeeDescription"];
                    activeFeeDescriptionList.RemoveAt(rowIndex);
                    GridViewFeeDescription.DataSource = activeFeeDescriptionList;
                    GridViewFeeDescription.DataBind();
              //      Response.Redirect("DetailFeeForm.aspx");
                }
            }
        

        protected void GridViewFeeDescription_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void GetAllFee()
        {
            FeeDescriptionDAL objFee = new FeeDescriptionDAL();
            DataSet ds = objFee.GetALlFee();
            if (ds != null)
            {
                GridViewFeeDescription.DataSource = ds;
                GridViewFeeDescription.DataBind();
            }
            else
            {
                GridViewFeeDescription.DataSource = null;
                GridViewFeeDescription.DataBind();
            }

        }
        protected void buttonPost_Click(object sender, EventArgs e)
        {
            //try
            //{
            if (APost())
            {
                //ActiveId = 1;
                //GridViewFeeDescription.DataSource = null;
                //GridViewFeeDescription.DataBind();
            }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}

            //try
            //{
            //    if (IPost())
            //    {
            //        ActiveId = 1;
            //        GridViewFeeDescription.DataSource = null;
            //        GridViewFeeDescription.DataBind();
            //        GetAllFee();
            //        ClearFee();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    throw;
            //}
        }

        public bool APost()
        {
            if (ddltype.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all Fields Correctly";
                return false;
            }
            bool _post = true;
            FeeDescriptionDAL _dalApproval = new FeeDescriptionDAL();
            List<FeeDescription> _listApproval = new List<FeeDescription>();
            if (ViewState["FeeDescription"] != null)
            {
                _listApproval = (List<FeeDescription>)ViewState["FeeDescription"];
            }


            FeeDescription _approval = new FeeDescription();
            if (ActiveId == 0)
            {
                _approval.Id = Convert.ToInt16(_dalApproval.MaxFeeDescriptionID().Tables[0].Rows[0][0]);
            }
            else
            {
                _approval.Id = ActiveId;
            }

          //  _approval.Id = Convert.ToInt16(ddlFeesMaster.SelectedValue);
          //  _approval.FeeSection = ddlFeesMaster.SelectedItem.Text;
            _approval.Id = Convert.ToInt16(ddltype.SelectedValue);
            _approval.Type = ddltype.SelectedItem.Text;
            _approval.IssueDate = IssueDate.Text.ToString();
            _approval.ValidDate = ValidDate.Text.ToString();
            _approval.DueDate = DueDate.Text.ToString();
            _approval.segmentId = txtSegmentId.Text.ToString();
            _approval.Description = txtDescription.Text.ToString();
            _approval.Fine = txtFine.Text.ToString();
           

            //_approval.UserID = Convert.ToInt16(ddlUser.SelectedValue);
            //_approval.UserName = ddlUser.SelectedItem.Text;
            //_approval.Sequence = string.IsNullOrEmpty(txtSequence.Value) ? 0 : Convert.ToInt16(txtSequence.Value);
            if (rowIndex >= 0)
            {
                _listApproval.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
             //   ddlFeesMaster.ClearSelection();
                ddltype.ClearSelection();
                IssueDate.Text = "";
                txtFine.Text = "";
                ValidDate.Text = "";
                DueDate.Text = "";
                txtSegmentId.Text = "";
                txtDescription.Text = "";
               

                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";

            }

            _listApproval.Add(_approval);
            GridViewFeeDescription.DataSource = _listApproval;
            GridViewFeeDescription.DataBind();
            ViewState["FeeDescription"] = _listApproval;
            lblMessage.Text = "";
            //ddlFeesMaster.ClearSelection();
            ddltype.ClearSelection();
            IssueDate.Text = "";
            txtFine.Text = "";
            ValidDate.Text = "";
            DueDate.Text = "";
            txtSegmentId.Text = "";
            txtDescription.Text = "";
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;
        }

        private bool IPost()
        {

            bool IsPost = true;

            FeeDescriptionDAL activeFeeDescriptionDAL = new FeeDescriptionDAL();
            FeeDescription activeFeeDescription = new FeeDescription();

            if (!string.IsNullOrEmpty(hfFeeDescription.Value))
            {
                activeFeeDescription.Id = Convert.ToInt32(hfFeeDescription.Value);
            }

            if (!string.IsNullOrEmpty(ddlFeesMaster.SelectedItem.Text))
            {
                activeFeeDescription.FeeSection = ddlFeesMaster.SelectedItem.ToString();
            }
            else
            {
                //errorProviderDis.SetError(txtCode, "Enter The Job Code ");
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(ddltype.SelectedItem.Text))
            {
                activeFeeDescription.Type = ddltype.SelectedItem.ToString();

            }
            else
            {
                //errorProviderDis.SetError(txtCode, "Enter The Job Code ");
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(IssueDate.Text))
            {
                activeFeeDescription.IssueDate = IssueDate.Text.ToString();

            }
            else
            {
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(DueDate.Text))
            {
                activeFeeDescription.DueDate = DueDate.Text.ToString();

            }
            else
            {
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(ValidDate.Text))
            {
                activeFeeDescription.ValidDate = ValidDate.Text.ToString();
            }
            else
            {
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(txtFine.Text))
            {
                activeFeeDescription.Fine = txtFine.Text.ToString();
            }
            else
            {
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(txtSegmentId.Text))
            {
                activeFeeDescription.segmentId = txtSegmentId.Text.ToString();
            }
            else
            {
                IsPost = false;
            }

            if (!string.IsNullOrEmpty(txtDescription.Text))
            {
                activeFeeDescription.Description = txtDescription.Text.ToString();

            }
            else
            {
                IsPost = false;
            }

            if (IsPost == true)
            {
                if (buttonPost.Text == "Generate")
                {
                    UnitId = activeFeeDescriptionDAL.FeeDescriptionInsert(activeFeeDescription);
                   
                }

                else if (buttonPost.Text == "Update")
                {
                    if (activeFeeDescriptionDAL.FeeDescriptionUpdate(activeFeeDescription) == true)
                        IsPost = true;
                    //  Response.Redirect("ClassSessionForm.aspx");
                }
            }
            return IsPost;
        }
        protected void txtDescription_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ddltype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}