﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EntityLayer;
using System.Data;
using DataAccessLayer;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListDegreeForm : System.Web.UI.Page
    {
        public string IdCode { get; set; }
        public int ActiveId { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                //         BindDegreeLevel();
                loadSession();
                bindtreeview();
            }
        }
        public void BindDegreeLevel()
        {
            try
            {
                DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
                List<DegreeLevel> activeList = activeDegreeDAL.DegreeLevelSelect();
                if (activeList != null)
                {
                    GridViewDegree.AutoGenerateColumns = false;
                    GridViewDegree.DataSource = activeList;
                    GridViewDegree.DataBind();
                }
            }
            catch
            {
            }
        }
        public void Initialize()
        {
            try
            {
                DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
                DegreeLevel activeMemberMaxId = activeDegreeDAL.DegreeLevelGetMaxId();
                string caption = "AS-00001";
                if (activeMemberMaxId != null)
                {
                    string theString = activeMemberMaxId.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    IdCode = "AS-0000" + code.ToString();
                }
                else
                {
                    IdCode = caption;
                }
            }
            catch (Exception ex)
            {
            }
        }
        
        //public bool Save()
        //{
        //    bool IsSave = true;
        //    try
        //    {

        //        DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
        //        DegreeLevel activeDegree = new DegreeLevel();
        //        activeDegree.Id = Convert.ToInt32(Session["GetId"]);
                
        //        activeDegree.Description = degreeDescription.Text;
        //        ActiveYear.Checked = Convert.ToBoolean(activeDegree.Active);
        //        if (bttnSave.Text == "Save")
        //        {
        //            Initialize();
        //            activeDegree.Code = IdCode;
        //        }
        //        else if (bttnSave.Text == "Update")
        //        {
        //            // UpdateData(ActiveId);
        //            activeDegree.Code = Convert.ToString(Session["GetCode"]);
        //        }
        //        //  activeIDType.Code = IdCode;
        //        if (IsSave == true)
        //        {
        //            if (bttnSave.Text == "Save")
        //            {
        //                activeDegreeDAL.DegreeLevelInsert(activeDegree);
        //            }
        //            else if (bttnSave.Text == "Update")
        //            {

        //                if (activeDegreeDAL.DegreeLevelUpdate(activeDegree) == true)
        //                    IsSave = true;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //   MessageCtrl1.showMessageBox("Save.", MessageType.Success);
        //    }
        //    return IsSave;
        //}

        public void loadSession()
        {
            DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
            List<DegreeLevel> activeList = activeDegreeDAL.DegreeLevelSelect();
            if (activeList != null)
            {
                GridViewDegree.DataSource = ViewState ["activeList"] as List<DegreeLevel>;
                GridViewDegree.DataBind();
            }
        }

        public void bindtreeview()
        {
            DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
            DataTable dt = activeDegreeDAL.GetData("SELECT * From  DegreeLevel where Active='True'");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["id"].ToString()
                };
                if (parentId == 0)
                {
                    //TreeViewAcadmicSession.Nodes.Add(child);

                    dtChild = activeDegreeDAL.GetData("SELECT * From  DegreeLevel where Active='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = activeDegreeDAL.GetData("SELECT * From  DegreeLevel where Active='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }


        protected void GridViewDegree_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void bttnSave_Click(object sender, EventArgs e)
        {
            try
            {
               // if (Save())
                {
                    Clear();
                    Response.Redirect("ListDegreeForm.aspx");
                }
            }
            catch
            {
                //  MessageCtrl1.showMessageBox("Save.", MessageType.Success);
            }
        }
        public void Clear()
        {
            try
            {
            //    degreeDescription.Text = string.Empty;
                ActiveId = 0;
                Request.QueryString[""].ToString();
            }
            catch
            {

            }
        }
        //public void UpdateData(int Id)
        //{
        //    try
        //    {
        //        DegreeLevelDAL activeDegreeDAL = new DegreeLevelDAL();
        //        DegreeLevel activeDegree = activeDegreeDAL.DegreeLevelGetById(Id);
        //        if (activeDegree != null)
        //        {
        //            ActiveId = activeDegree.Id;
        //            Session["GetId"] = ActiveId;
        //            IdCode = activeDegree.Code;
        //            Session["GetCode"] = IdCode;
        //       //     degreeDescription.Text = activeDegree.Description;
        //      //      ActiveYear.Checked = Convert.ToBoolean(activeDegree.Active);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //   MessageCtrl1.showMessageBox("Update Data Id Type.", MessageType.Success);
        //    }
        //}


        protected void GridViewDegree_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/DegreeForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                DegreeLevelDAL activeDAL = new DegreeLevelDAL();
                if (iStID > 0)
                {
                    activeDAL.DegreeLevelDelete(iStID);
                    //loadSession();
                //    TreeViewAcadmicSession.Nodes.Clear();
                    bindtreeview();
                    Response.Redirect("ListDegreeForm.aspx");
                }
            }

        }
        protected void GridViewDegree_RowEditing(object sender, GridViewEditEventArgs e)
        {
            //try
            //{
            //    bttnSave.Text = "Update";
            //    UpdateData(ActiveId);
            //    ScriptManager.RegisterStartupScript(Page, GetType(), "disp_confirm", "<script>disp_confirm()</script>", false);
            //}
            //catch
            //{

            //}
            e.Cancel = true;
        }
        protected void GridViewDegree_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void LinkButtonEdit_Click(object sender, EventArgs e)
        {

        }
    }
}