﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfDetailFeeDescription : System.Web.UI.Page
    {
        DetailFeeDescriptionDAL objDetailFeeDescriptionDAL = new DetailFeeDescriptionDAL();
        DetailFeeDescription objDetailFeeDescription = new DetailFeeDescription();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                bindtreeview();
            }
            
        }

        public void bindtreeview()
        {
            DataTable dt = objDetailFeeDescriptionDAL.GetData("SELECT * From  DetailFeeDescription");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["id"].ToString()
                };
                if (parentId == 0)
                {
                    TreeViewDetailFeeDescription.Nodes.Add(child);
                    dtChild = objDetailFeeDescriptionDAL.GetData("SELECT * From  DetailFeeDescription");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = objDetailFeeDescriptionDAL.GetData("SELECT * From  DetailFeeDescription");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }

        protected void GridViewDetailFeeDescription_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridViewDetailFeeDescription_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewDetailFeeDescription_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewDetailFeeDescription_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/DetailFeeForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                DetailFeeDescriptionDAL objDetailFeeDescriptionDAL = new DetailFeeDescriptionDAL();
                objDetailFeeDescriptionDAL.DetailFeeDescriptionDelete(iStID);
                Response.Redirect("ListOfDetailFeeDescription.aspx");
              //  bindtreeview();
            }
        }

        protected void TreeViewDetailFeeDescription_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}