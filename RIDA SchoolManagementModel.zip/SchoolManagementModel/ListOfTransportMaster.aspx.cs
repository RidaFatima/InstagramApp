﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EntityLayer;
using System.Data;
using DataAccessLayer;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfTransportMaster : System.Web.UI.Page
    {
        public string IdCode { get; set; }
        public int ActiveId { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                loadSession();
                bindtreeview();
            }
        }
        public void loadSession()
        {
            TransportMasterDAL activeTransportMasterDAL = new TransportMasterDAL();
            List<TransportMaster> activeList = activeTransportMasterDAL.TransportMasterSelect();
            if (activeList != null)
            {
                GridViewTransportMaster.DataSource = ViewState["activeList"] as List<TransportMaster>;
                GridViewTransportMaster.DataBind();
            }
        }
        public void bindtreeview()
        {
            TransportMasterDAL activeTransportMasterDAL = new TransportMasterDAL();
            DataTable dt = activeTransportMasterDAL.GetData("SELECT * From  TransportMaster where Active='True'");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            TransportMasterDAL activeTransportMasterDAL = new TransportMasterDAL();
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["id"].ToString()
                };
                if (parentId == 0)
                {
                    //TreeViewAcadmicSession.Nodes.Add(child);

                    dtChild = activeTransportMasterDAL.GetData("SELECT * From  TransportMaster where Active='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = activeTransportMasterDAL.GetData("SELECT * From  TransportMaster where Active='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }
        protected void GridViewTransportMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/TransportMasterForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                TransportMasterDAL activeDAL = new TransportMasterDAL();
                if (iStID > 0)
                {
                    activeDAL.TransportMasterDelete(iStID);
                    //loadSession();
                    //    TreeViewAcadmicSession.Nodes.Clear();
                    bindtreeview();
                    Response.Redirect("ListOfTransportMaster.aspx");
                }
            }
        }

        protected void GridViewTransportMaster_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewTransportMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewTransportMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void TreeViewTransportMaster_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}