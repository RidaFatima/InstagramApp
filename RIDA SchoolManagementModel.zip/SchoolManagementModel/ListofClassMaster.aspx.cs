﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListofClassMaster : System.Web.UI.Page
    {
        ClassMasterDAL objClassMasterDAL = new ClassMasterDAL();
        ClassMaster objClassMaster = new ClassMaster();
        protected void Page_Load(object sender, EventArgs e)
        {
            bindtreeview();
            BindClassMaster();
            loadSession();
        }

        private void BindClassMaster()
        {
            try
            {
                ClassMasterDAL objClassMasterDAL = new ClassMasterDAL();
                ClassMaster objClassMaster = new ClassMaster();
                List<ClassMaster> activeClassMasterIdList = objClassMasterDAL.ClassMasterSelectNew();
                if (activeClassMasterIdList != null)
                {
                    GridViewListofClassMaster.DataSource = ViewState["activeClassMasterIdList"] as List<ClassMaster>;
                    GridViewListofClassMaster.DataBind();
                }
            }
            catch (Exception)
            {
                //          throw;
            }
        }

        public void loadSession()
        {
            ClassMasterDAL objClassMasterDAL = new ClassMasterDAL();
            List<ClassMaster> activeClassMasterIdList = objClassMasterDAL.ClassMasterSelectNew();
            if (activeClassMasterIdList != null)
            {
                GridViewListofClassMaster.DataSource = ViewState["activeClassSessionIdList"] as List<ClassMaster>;
                GridViewListofClassMaster.DataBind();
            }
        }

        public void bindtreeview()
        {
            DataTable dt = objClassMasterDAL.GetData("SELECT * From  ClassMaster where Running='True'");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["Id"].ToString()
                };
                if (parentId == 0)
                {
                    TreeViewClassMaster.Nodes.Add(child);
                    dtChild = objClassMasterDAL.GetData("SELECT * From  ClassMaster where Running='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = objClassMasterDAL.GetData("SELECT * From  ClassMaster where Running='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }

        protected void GridViewListofClassMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridViewListofClassMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewListofClassMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/ClassMasterForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                ClassMasterDAL objClassMasterDAL = new ClassMasterDAL();
                objClassMasterDAL.ClassMasterDelete(iStID);
                //   BindFeesMaster();
                // loadSession();
                Response.Redirect("ListofClassMaster.aspx");
                bindtreeview();
            }
        }

        protected void TreeViewClassMaster_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}