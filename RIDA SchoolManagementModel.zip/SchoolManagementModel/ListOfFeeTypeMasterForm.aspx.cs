﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;


namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfFeeTypeMasterForm : System.Web.UI.Page
    {
        FeeTypeMasterDAL activeFeeTypeMasterDAL = new FeeTypeMasterDAL();
        FeeTypeMaster activeFeeTypeMaster = new FeeTypeMaster();

        protected void Page_Load(object sender, EventArgs e)
        {
            bindtreeview();
            loadSession();
        }

        public void loadSession()
        {
            FeeTypeMasterDAL activeFeeTypeMasterDAL = new FeeTypeMasterDAL();
            List<FeeTypeMaster> activeFeeTypeMasterList = activeFeeTypeMasterDAL.FeeTypeMasterSelect();
            if (activeFeeTypeMasterList != null)
            {
                GridViewListofFeeTypeMaster.DataSource = ViewState["activeFeeTypeMasterList"] as List<FeeTypeMaster>;
                GridViewListofFeeTypeMaster.DataBind();
            }
            else
            {

                GridViewListofFeeTypeMaster.DataSource = null;
                GridViewListofFeeTypeMaster.DataBind();
            }

        }
        public void bindtreeview()
        {
            DataTable dt = activeFeeTypeMasterDAL.GetData("SELECT * From  FeeTypeMaster where Transable='True'");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["Id"].ToString()
                };
                if (parentId == 0)
                {
                  //  TreeViewFeeMaster.Nodes.Add(child);
                    dtChild = activeFeeTypeMasterDAL.GetData("SELECT * From FeeTypeMaster where Transable='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = activeFeeTypeMasterDAL.GetData("SELECT * From FeeTypeMaster where Transable='True'");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }

        protected void GridViewListofFeeTypeMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }

        protected void GridViewListofFeeTypeMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/FeeTypeMasterForm.aspx?Id=" + iStID);
                }
            }
            else
            {

                int iStID = Int32.Parse(e.CommandArgument.ToString());
                FeeTypeMasterDAL activeFeeTypeMasterDAL = new FeeTypeMasterDAL();
                if (iStID > 0)
                {
                    activeFeeTypeMasterDAL.FeeTypeMasterDelete(iStID);
                    //   BindFeesMaster();
                    // loadSession();
                   // TreeViewFeeMaster.Nodes.Clear();
                    bindtreeview();
                    Response.Redirect("ListOfFeeTypeMasterForm.aspx");
                }
                //  ClassSessionDAL objClassSessionDal = new ClassSessionDAL();
                // objClassSessionDal.ClassSessionDelete(iStID);
                // BindFeesMaster(); 
            }
        }

        protected void TreeViewFeeTypeMaster_SelectedNodeChanged(object sender, EventArgs e)
        {

        }

        protected void GridViewListofFeeTypeMaster_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}