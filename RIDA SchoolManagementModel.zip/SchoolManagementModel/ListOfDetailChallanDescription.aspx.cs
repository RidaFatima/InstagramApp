﻿using System;
using System.Web.UI.WebControls;
using EntityLayer;
using DataAccessLayer;
using System.Data;
using System.Collections.Generic;

namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ListOfDetailChallanDescription : System.Web.UI.Page
    {
        DetailChallanDescriptionDAL objDetailChallanDescriptionDAL = new DetailChallanDescriptionDAL();
        DetailChallanDescription objDetailChallanDescriptionTable = new DetailChallanDescription();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                bindtreeview();
            }
        }
        public void bindtreeview()
        {
            DataTable dt = objDetailChallanDescriptionDAL.GetData("SELECT * From  DetailChallanDescription");
            this.loadTreeview(dt, 0, null);
        }

        private void loadTreeview(DataTable dtParent, int parentId, TreeNode treeNode)
        {
            DataTable dtChild;
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["Code"].ToString(),
                    Value = row["Id"].ToString()
                };
                if (parentId == 0)
                {
                    TreeViewChallanDescriptionTable.Nodes.Add(child);
                    dtChild = objDetailChallanDescriptionDAL.GetData("SELECT * From  DetailChallanDescription");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
                else
                {
                    treeNode.ChildNodes.Add(child);

                    dtChild = objDetailChallanDescriptionDAL.GetData("SELECT * From  DetailChallanDescription");
                    loadTreeview(dtChild, int.Parse(child.Value), child);
                }
            }
        }

        protected void GridViewChallanDescriptionTable_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridViewChallanDescriptionTable_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewChallanDescriptionTable_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewChallanDescriptionTable_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                if (iStID > 0)
                {
                    Response.Redirect("~/SchoolManagementModel/ChallanDescriptionForm.aspx?Id=" + iStID);
                }
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                DetailChallanDescriptionDAL objDetailChallanDescriptionDAL = new DetailChallanDescriptionDAL();
                objDetailChallanDescriptionDAL.DetailChallanDescriptionDelete(iStID);
                //   BindFeesMaster();
                // loadSession();
                Response.Redirect("ListOfDetailChallanDescription.aspx");
                bindtreeview();
            }
        }

        protected void TreeViewChallanDescriptionTable_SelectedNodeChanged(object sender, EventArgs e)
        {

        }
    }
}