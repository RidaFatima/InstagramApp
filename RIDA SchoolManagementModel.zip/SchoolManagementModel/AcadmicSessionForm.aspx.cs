﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI;
using System.Configuration;
using EntityLayer;
using System.Data;
using DataAccessLayer;
using System.Data.SqlClient;


namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class AcadmicSessionForm : System.Web.UI.Page
    {
        public int ActiveId;
        public int getid;
        public int UnitId;
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (!IsPostBack)
            {
               
                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    ButnSave.Text = "Update";
                    ActiveId = 1;
                  //  UpdateData(getid);
                    Initilaize();
                    GetId();

                    
                }
                else
                {
                    ButnSave.Text = "Save";
                    ActiveId = 0;
                    Clear();
                }
            }
        }

             public void UpdateData(int Id)
        {
            try
            {
                AcadmicSessionDAL activeAcadmicSessionDAL = new AcadmicSessionDAL();
                AcadmicSession activeAcadmicSession = activeAcadmicSessionDAL.AcadmicSessionGetById(Id);
                if (activeAcadmicSession != null)
                {

                    hfAcadmicSessionID.Value = activeAcadmicSession.Id.ToString();
                    txtAcdmicCode.Attributes.Add("value", activeAcadmicSession.Code);
                    txtDescription.Text = activeAcadmicSession.Description;

                    TextBox1.Text = activeAcadmicSession.EndDate.ToString("yyyy-MM-dd");
                    single_calStartDate.Text = activeAcadmicSession.StartDate.ToString("yyyy-MM-dd");

                    Activechk.Checked = Convert.ToBoolean(activeAcadmicSession.Active);
                   
                    CurrentYearchk.Checked = Convert.ToBoolean(activeAcadmicSession.CurrentYear);
                }

            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);

                }
            }
            catch
            {
             //   MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }

        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            {
                try
                {

                    if (Save())
                    {
                        Clear();
                        //BindUnit();
                        Response.Redirect("ListAcadmicSession.aspx");
                    }
                }
                catch (Exception ex)
                {
                    Messages.ErrorMessage(ex.ToString());

                }
            }
        }

    protected void ValidateDuration(object sender, ServerValidateEventArgs e)
        {
            DateTime start = DateTime.Parse(single_calStartDate.Text);
            DateTime end = DateTime.Parse(TextBox1.Text);

            int months = (end.Month - start.Month) + 12 * (end.Year - start.Year);

            e.IsValid = months < 12.0;
        }

        public bool Save()
        {

            bool IsSave = true;

            
            AcadmicSessionDAL activeAcadmicSessionDAL = new AcadmicSessionDAL();
            AcadmicSession activeAcadmicSession = new AcadmicSession();

            if (!string.IsNullOrEmpty(hfAcadmicSessionID.Value))
            {
                activeAcadmicSession.Id = Convert.ToInt32(hfAcadmicSessionID.Value);
            }
            


            if (!string.IsNullOrEmpty(txtDescription.Text))
            {
                activeAcadmicSession.Description = txtDescription.Text;
            }
            else
            {
                IsSave = false;
            }


            if (!string.IsNullOrEmpty(txtAcdmicCode.Value))
            {
                activeAcadmicSession.Code = txtAcdmicCode.Value;
            }
            else
            {
                IsSave = false;
            }



            if (!string.IsNullOrEmpty(TextBox1.Text))
            {
                activeAcadmicSession.EndDate = Convert.ToDateTime(TextBox1.Text);
            }
            if (!string.IsNullOrEmpty(single_calStartDate.Text))
            {
                activeAcadmicSession.StartDate = Convert.ToDateTime(single_calStartDate.Text);
            }

            DateTime start = DateTime.Parse(single_calStartDate.Text);
            DateTime end = DateTime.Parse(TextBox1.Text);

            int months = (end.Month - start.Month) + 12 * (end.Year - start.Year);

            // ErrorMessage1.IsValid months = 12.0;

            if (months == 11)
            {
                IsSave = true;

            }
            else
            {
                IsSave = false;
                MessageCtrl2.showMessageBox("Unable to Save .", MessageType.Information);
            }

            // activeAcadmicSession.Active = Activechk.Checked;
            //   activeAcadmicSession.Active = true;
            // activeAcadmicSession.CurrentYear = true;


            //if (Activechk !=null && Activechk.Checked)
            //{
            //    activeAcadmicSession.Active = Activechk.Checked;

            //}
            //else
            //{

            //    //  activeAcadmicSession.Active = Activechk.Checked;
            //    Activechk.Checked = false;
            //  //  IsSave = false;
            //}

            //if (CurrentYearchk != null && CurrentYearchk.Checked)
            //{
            //    activeAcadmicSession.CurrentYear = CurrentYearchk.Checked;

            //}
            //else
            //{

            //    //  activeAcadmicSession.Active = Activechk.Checked;
            //    CurrentYearchk.Checked = false;
            //  //  IsSave = false;
            //}

            activeAcadmicSession.Active = Activechk.Checked;
            activeAcadmicSession.CurrentYear = CurrentYearchk.Checked;




            if (IsSave == true)
            {
                if (ButnSave.Text == "Save")
                {
                    UnitId = activeAcadmicSessionDAL.AcadmicSessionInsert(activeAcadmicSession);
                    Response.Redirect("ListAcadmicSession.aspx");
                }

                else if (ButnSave.Text == "Update")
                {
                    if (activeAcadmicSessionDAL.AcadmicSessionUpdate(activeAcadmicSession) == true)

                        IsSave = true;
                    Response.Redirect("ListAcadmicSession.aspx");
                }
            }

            return IsSave;
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        public void Clear()
        {
            try
            {
                ActiveId = 0;

                txtDescription.Text = string.Empty;

                TextBox1.Text = string.Empty;
                single_calStartDate.Text = string.Empty;

                Activechk.Checked = false;
               
                CurrentYearchk.Checked = false;
                hfAcadmicSessionID.Value = string.Empty;
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());

            }
        }

        public void Initilaize()
        {
            try
            {
                AcadmicSessionDAL activeAcadmicSessionDAL = new AcadmicSessionDAL();
                AcadmicSession activeAcadmicSession = activeAcadmicSessionDAL.AcadmicSessionGetMaxId();
                string caption = "AS-00001";
                if (activeAcadmicSession != null) 
                {
                    string theString = activeAcadmicSession.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    txtAcdmicCode.Value = "AS-0000" + code.ToString();
                }
                else
                {
                    txtAcdmicCode.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }

        protected void StartDate_TextChanged(object sender, EventArgs e)
        {

        }

        protected void EndDate_TextChanged(object sender, EventArgs e)
        {

        }

        protected void single_calStartDate_TextChanged(object sender, EventArgs e)
        {

        }
    }

}

    

   
       

      
      