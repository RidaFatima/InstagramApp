﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI;
using System.Configuration;
using EntityLayer;
using System.Data;
using DataAccessLayer;
using System.Data.SqlClient;


namespace WebDesk_ERP.SchoolManagementModel
{
    public partial class ClassSessionForm : System.Web.UI.Page
    {
        
        public static int FeeId { get; set; }
        public static string Fee { get; set; }
        public static int ActiveId { get; set; }
        public int Id { get; set; }
        public static int rowIndex { get; set; }
        public static int PIActiveId { get; set; }
        public static int AcadmicSessionId { get; set; }
        public static bool Running { get; set; }
        public static int ClassSessionId { get; set; }
      
        public static string Code = null;

        public int getid;
        public int UnitId;

      //  List<ClassSession> activeFeeList = new List<ClassSession>();
        List<ClassSession> activeClassSessionIdList = new List<ClassSession>();
        List<ClassFeePost> activeClassFeePostList = new List<ClassFeePost>();
      //  List<FeesMaster> activeFeeMasterIdList = new List<FeesMaster>(); 
        ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
        protected void Page_Load(object sender, EventArgs e)
        {
        
            if (!IsPostBack)
            {
                rowIndex = -1;
                ClassSession objClassSession = new ClassSession();
                ViewState["ClassFeePost"] = new List<ClassFeePost>();
                //   ViewState["ClassSession"] = new List<ClassSession>();
                //BindFeesMaster();
                //BindClassSession();
                //  BindGridView();
                // GridViewFee.DataSource = string.Empty;
                ViewState["ClassFeePost"] = null;
                GridViewFee.DataBind();
                BindDegreeLevel();
                BindFeeTypeMaster();
                BindAcadmicSession();
                BindClassMaster();
                Initilaize();
                GetId();
                GetAllFee();
                ViewState["ClassFeePost"] = null;
                GridViewFee.DataBind();

                //ClassClear_Click(ClassClear, new EventArgs());
                //  Clear();

                if (!string.IsNullOrWhiteSpace(Request.QueryString["Id"]))
                {
                    getid = Convert.ToInt32(Request.QueryString["Id"].ToString());
                    /* load form for Edit */
                    ClassSave.Text = "Update";
                    ActiveId = 1;
                    //  UpdateData(getid);

                    // BindFeesMaster();
                    //   loadSession();                    
                }
                else
                {
                  //  ViewState["ClassFeePost"] = null;
                  //  GridViewFee.DataBind();
                    ViewState["ClassFeePost"] = (List<ClassFeePost>)null;
                    ClassSave.Text = "Save";
                    ActiveId = 0;
                    Clear();
                    //GridViewFee.DataSource=null;
                    GridViewFee.DataBind();
                //    Response.Redirect("ClassSessionForm.aspx");
                }
            }
        }

        public void GetId()
        {
            try
            {
                if (Request.QueryString["Id"] != null)
                {
                    ActiveId = Convert.ToInt32(Request.QueryString["Id"]);
                    UpdateData(ActiveId);                    
                }
            }
            catch
            {
                //  MessageCtrl1.showMessageBox("Get By Id.", MessageType.Success);
            }
        }


        //public void UpdateData(int Id)
        //{
        //    try
        //    {
        //        ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
        //        ClassSession objClassSession = objClassSessionDAL.ClassSessionGetById(Id);
        //        if (objClassSession != null)
        //        {

        //            hfClassSession.Value = objClassSession.Id.ToString();
        //            TextBox1.Attributes.Add("value", objClassSession.Code);
        //            TextBox2.Text = objClassSession.Description;
        //           // ddlSession.Text = objClassSession.Session;
        //            TextBox4.Text = objClassSession.Class;
        //            objClassSession.Levels = ddlLevel.SelectedItem.Text;
        //            //TextBox5.Text = objClassSession.Levels.ToString();
        //            objClassSession.FeeType = ddlFeesMaster.SelectedItem.Text;
        //            objClassSession.Session = ddlSession.SelectedItem.Text;
        //            CheckBoxClassSession.Checked = Convert.ToBoolean(objClassSession.Running);
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        Messages.ErrorMessage(ex.ToString());

        //    }
        //}

        public void UpdateData(int Id)
        {
            try
            {
                ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
                ClassSession objClassSession = objClassSessionDAL.ClassSessionGetById(Id);
                 if (objClassSession != null)
                {

                    hfClassSession.Value = objClassSession.Id.ToString();
                    TextBox1.Attributes.Add("value", objClassSession.Code);
                    TextBox2.Text = objClassSession.Description;
                    ddlClassMaster.SelectedItem.Text = objClassSession.Class;
                    ddlLevel.SelectedItem.Text = objClassSession.Levels;
                    //objClassSession.Levels = ddlLevel.SelectedItem.Text;
                    ddlFeesMaster.SelectedItem.Text = objClassSession.FeeType;
                    //objClassSession.FeeType = ddlFeesMaster.SelectedItem.Text;
                    ddlSession.SelectedItem.Text = objClassSession.Session;
                    //objClassSession.Session = ddlSession.SelectedItem.Text;
                    CheckBoxClassSession.Checked = Convert.ToBoolean(objClassSession.Running);
                }

            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
   
        public void BindAcadmicSession()
        {
            try
            {
                AcadmicSessionDAL ActiveDAL = new AcadmicSessionDAL();
                List<AcadmicSession> ActiveList = ActiveDAL.AcadmicSessionSelect();
                AcadmicSession activeSession = new AcadmicSession();
                if (ActiveList != null)
                {
                    activeSession.Id = 0;
                    activeSession.Description = "None";
                    ActiveList.Insert(0, activeSession);
                    ddlSession.DataSource = ActiveList;
                    ddlSession.DataValueField = "Id";
                    ddlSession.DataTextField = "Description";
                    ddlSession.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }        
        public void BindClassMaster()
        {
            try
            {
                ClassMasterDAL ActiveClassMasterDAL = new ClassMasterDAL();
                List<ClassMaster> ActiveClassMasterList = ActiveClassMasterDAL.ClassMasterSelectNew();
                ClassMaster activeClassMaster = new ClassMaster();
                if (ActiveClassMasterList != null)
                {
                    activeClassMaster.Id = 0;
                    activeClassMaster.Description = "None";
                    ActiveClassMasterList.Insert(0, activeClassMaster);
                    ddlClassMaster.DataSource = ActiveClassMasterList;
                    ddlClassMaster.DataValueField = "Id";
                    ddlClassMaster.DataTextField = "Description";
                    ddlClassMaster.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindDegreeLevel()
        {
            try
            {
                DegreeLevelDAL ActiveDegreeDAL = new DegreeLevelDAL();
                List<DegreeLevel> ActiveDegreeList = ActiveDegreeDAL.DegreeLevelSelect();
                DegreeLevel activeDegreeLevel = new DegreeLevel();
                if (ActiveDegreeList != null)
                {
                    activeDegreeLevel.Id = 0;
                    activeDegreeLevel.Description = "None";
                    ActiveDegreeList.Insert(0, activeDegreeLevel);
                    ddlLevel.DataSource = ActiveDegreeList;
                    ddlLevel.DataValueField = "Id";
                    ddlLevel.DataTextField = "Description";
                    ddlLevel.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindFeeTypeMaster()
        {
            try
            {
                FeeTypeMasterDAL objFeeTypeMasterDAL = new FeeTypeMasterDAL();
                List<FeeTypeMaster> activeFeeTypeMasterIdList = objFeeTypeMasterDAL.FeeTypeMasterSelect();
                FeeTypeMaster objFeeTypeMaster = new FeeTypeMaster();
                if (activeFeeTypeMasterIdList != null)
                {
                    objFeeTypeMaster.Id = 0;
                    objFeeTypeMaster.Description = "None";
                    activeFeeTypeMasterIdList.Insert(0, objFeeTypeMaster);
                    ddlFeesMaster.DataSource = activeFeeTypeMasterIdList;
                    ddlFeesMaster.DataValueField = "Id";
                    ddlFeesMaster.DataTextField = "Description";
                    ddlFeesMaster.DataBind();
                }
            }
            catch (Exception ex)
            {
                Messages.ExceptionMessage(ex.Message);
            }
        }

        public void BindClassSession()
        {
            // try
            // {
            ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
            List<ClassSession> activeClassSessionIdList = objClassSessionDAL.ClassSessionSelectNew();
            ClassSession objClassSession = new ClassSession();
            objClassSession.Id = 0;
            objClassSession.Description = "None";
            activeClassSessionIdList.Insert(0, objClassSession);
        }

        //public void loadSession()
        //{ 
        //    ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
        //    List<ClassSession> activeClassSessionIdList = objClassSessionDAL.ClassSessionSelectNew();
        //    if (activeClassSessionIdList != null)
        //    {
        //        GridViewFee.DataSource = ViewState["activeClassSessionIdList"] as List<ClassSession>;
        //        GridViewFee.DataBind();
        //    }
        //}

        //public void BindFeesMaster()
        //{
        //    FeesMasterDAL objFeeMasterDAL = new FeesMasterDAL();
        //    List<FeesMaster> activeFeeMasterIdList = objFeeMasterDAL.FeeMasterSelectNew();
        //    FeesMaster activeFeeMaster = new FeesMaster();
        //    activeFeeMaster.Id = 0;
        //    activeFeeMaster.FeeType = "None";
        //    activeFeeMasterIdList.Insert(0, activeFeeMaster);
        //    ddlFeesMaster.DataSource = activeFeeMasterIdList;
        //    ddlFeesMaster.DataValueField = "Id";
        //    ddlFeesMaster.DataTextField = "FeeType";
        //    ddlFeesMaster.DataBind();
        //    if (activeFeeMasterIdList != null)
        //    {
        //        ddlFeesMaster.DataTextField = "FeeType";

        //        ddlFeesMaster.DataValueField = "Id";
        //        ddlFeesMaster.DataSource = activeFeeMasterIdList;
        //        ddlFeesMaster.DataBind();
        //    }


        //private void BindGridView()
        //{
        //    try
        //    {
        //        ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
        //        ClassSession objClassSession = new ClassSession();
        //        List<ClassSession> activeClassSessionIdList = objClassSessionDAL.ClassSessionSelectNew();
        //        if (activeClassSessionIdList != null)
        //        {
        //            GridViewFee.DataSource = ViewState["activeClassSessionIdList"] as List<ClassSession>;
        //            GridViewFee.DataBind();
        //        }
        //    }
        //    catch (Exception)
        //    {

        //        //      throw;
        //    }
        //}
       
        protected void ButtonClassSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    ActiveId = 0;
                    Response.Redirect("~/SchoolManagementModel/ListofClassSession.aspx", false);
                    Context.ApplicationInstance.CompleteRequest();
                   // GridViewFee.DataSource = null;
                }
            }
            catch (Exception)
            {
           //     throw;
            }
        }
  
        private bool Save()
        {
          
            bool IsSave = true;


            ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
            ClassSession objClassSession = new ClassSession();

            if (!string.IsNullOrEmpty(hfClassSession.Value))
            {
                objClassSession.Id = Convert.ToInt32(hfClassSession.Value);
            }

            if (!string.IsNullOrEmpty(TextBox2.Text))
            {
                objClassSession.Description = TextBox2.Text;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(TextBox1.Value))
            {
                objClassSession.Code = TextBox1.Value;
            }
            else
            {
                IsSave = false;
            }

            if (!string.IsNullOrEmpty(ddlSession.Text))
            {
                objClassSession.Session = ddlSession.SelectedItem.ToString();
            }
            else
            {          
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlClassMaster.Text))
            {
                objClassSession.Class = ddlClassMaster.SelectedItem.Text;
            }
            else
            {               
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlLevel.Text))
            {
                objClassSession.Levels = ddlLevel.SelectedItem.ToString();
            }
            else
            {               
                IsSave = false;
            }
            if (!string.IsNullOrEmpty(ddlFeesMaster.SelectedItem.Text))
            {
                objClassSession.FeeType = ddlFeesMaster.SelectedItem.ToString();
            }
            else
            {              
                IsSave = false;
            }

            objClassSession.Running = CheckBoxClassSession.Checked;
          

            if (IsSave == true)
            {
                if (ClassSave.Text == "Save")
                {
                    UnitId = objClassSessionDAL.ClassSessionInsert(objClassSession);
                    Response.Redirect("ListofClassSession.aspx");
                }

                else if (ClassSave.Text == "Update")
                {
                    if (objClassSessionDAL.ClassSessionUpdate(objClassSession) == true)

                        IsSave = true;
                    Response.Redirect("ListofClassSession.aspx");
                }
            }

            return IsSave;
        }
     
        public void AllClear()
        { 
            try
            {
                ActiveId = 0;

                TextBox2.Text = string.Empty;
                ddlSession.SelectedIndex = 0;
                ddlClassMaster.SelectedIndex = 0;
                ddlLevel.SelectedIndex = 0;
                ddlFeesMaster.SelectedIndex = 0;

                CheckBoxClassSession.Checked = false;      
                Initilaize();
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
        public void Clear()
        {
            ClassFeePostDAL objFee = new ClassFeePostDAL();
            DataSet ds = objFee.GetALlFee();
            //if (ds != null)
            //{
            //    GridViewFee.DataSource = ds;
            //    GridViewFee.DataBind();
            //}
            //else
            //{
            //    GridViewFee.DataSource = null;
            //    GridViewFee.DataBind();
            //}

            ViewState["ClassFeePost"] = null;
            ds.Clear();
            GridViewFee.DataBind();

            //    GridViewFee.DataSource = ds;
            ////  GridViewFee.DataBind(); 
            //  ds.Clear();
            // Response.Redirect("ClassSessionForm.aspx");
            //  ViewState["ClassFeePost"] = (List<ClassFeePost>)null;
            // rowIndex = -1;
            ActiveId = 0;
            Initilaize();
            AllClear();
        }
        public void Initilaize()
        {
            try
            {
                ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
                ClassSession objClassSession = new ClassSession();
                ClassSession activeMemberMaxId = objClassSessionDAL.ClassSessionGetMaxId();
                string caption = "CS-00001";
                if (activeMemberMaxId != null)
                {
                    string theString = activeMemberMaxId.Code;
                    var subString = theString.Substring(theString.LastIndexOf('-') + 1);
                    int add = Convert.ToInt32(subString);
                    int code = add + 1;

                    TextBox1.Value = "CS-0000" + code.ToString();
                }
                else
                {
                    TextBox1.Value = caption;
                }
            }
            catch (Exception ex)
            {
                Messages.ErrorMessage(ex.ToString());
            }
        }
        protected void ClassClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        protected void buttonFeePost_Click(object sender, EventArgs e)
        {
            if (Post())
            {

            }
            //try
            //{
            //    if (IPost())
            //    {
            //        ActiveId = 1;
            //        GridViewFee.DataSource = null;
            //        GridViewFee.DataBind();
            //        ddlFeesMaster.SelectedIndex = 0;
            //        GetAllFee();
            //        Context.ApplicationInstance.CompleteRequest();
            //    }          
            //}
            //catch (Exception ex)
            //{
            //    throw;
            //}
        }

        private void GetAllFee()
        {
            ClassFeePostDAL objFee = new ClassFeePostDAL();
            DataSet ds = objFee.GetALlFee();
            if (ds != null)
            {
                GridViewFee.DataSource = ds;
                GridViewFee.DataBind();
            }
            else
            {
                GridViewFee.DataSource = null;
                GridViewFee.DataBind();
            }
        }

        protected void GridViewFee_RowEditing(object sender, GridViewEditEventArgs e)
        {
            e.Cancel = true;
        }
        protected void GridViewFee_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true;           
        }
        protected void GridViewFee_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                rowIndex = row.RowIndex;
                int id = Convert.ToInt32(e.CommandArgument);
                UpdateData(rowIndex);
            }
            else
            {
                int iStID = Int32.Parse(e.CommandArgument.ToString());
                 ClassFeePostDAL objClassFeePostDAL = new ClassFeePostDAL();
                //if (iStID > 0)
                //{
                //    objClassFeePostDAL.ClassFeePostDelete(iStID);
                    GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                    rowIndex = row.RowIndex;
                    int id = Convert.ToInt32(e.CommandArgument);
                    activeClassFeePostList = (List<ClassFeePost>)ViewState["ClassFeePost"];
                       activeClassFeePostList.RemoveAt(rowIndex);
                    GridViewFee.DataSource = activeClassFeePostList;
                    GridViewFee.DataBind();
                    //   Response.Redirect("ClassSessionForm.aspx");
               // }
            }

            ////////////////////////////////////////////////////////////////////////////////////////////

            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/ClassSessionForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    ClassFeePostDAL objClassFeePostDAL = new ClassFeePostDAL();
            //    if (iStID > 0)
            //    {
            //        objClassFeePostDAL.ClassFeePostDelete(iStID);

            //        Response.Redirect("ClassSessionForm.aspx");
            //    }
            //}

            ////////////////////////////////////////////////////////////////////////////////////////////

            //if (e.CommandName == "Edit")
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    if (iStID > 0)
            //    {
            //        Response.Redirect("~/SchoolManagementModel/ClassSessionForm.aspx?Id=" + iStID);
            //    }
            //}
            //else
            //{
            //    int iStID = Int32.Parse(e.CommandArgument.ToString());
            //    ClassFeePostDAL objClassFeePostDAL = new ClassFeePostDAL();
            //    if (iStID > 0)
            //    {
            //        GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            //        rowIndex = 0;
            //         objClassFeePostDAL.ClassFeePostDelete(iStID);
            //          activeClassFeePostList = (List<ClassFeePost>)ViewState["ClassFeePost"];
            //       // activeClassFeePostList.RemoveAt(rowIndex);

            //      //  GridViewFee.DataSource = activeClassFeePostList;
            //        GridViewFee.DataBind();
            //        Response.Redirect("ClassSessionForm.aspx");
            //    }
            //}
        }
  
        private void UpdateClassSession(int Id)
        {
            if (GridViewFee.Rows.Count > 0)
            {
                List<ClassSession> activeClassSessionIdList = (List<ClassSession>)ViewState["ClassSession"];

                foreach (ClassSession item in activeClassSessionIdList)
                {
                    if (activeClassSessionIdList.IndexOf(item) == Id)
                    {
                        //  ClassSessionId =item.Id;
                        //    TextBox1.Value =item.Code;
                        TextBox2.Text = item.Description.ToString();
                        ddlSession.Text = item.Session.ToString();
                        ddlClassMaster.SelectedItem.Text = item.Class;
                        ddlLevel.Text = item.Levels.ToString();
                        CheckBoxClassSession.Checked = item.Running;
                        ddlFeesMaster.SelectedItem.Text = item.FeeType.ToString();
                    }
                }
            }
        }
         protected void GridViewFee_SelectedIndexChanged(object sender, EventArgs e) 
        {

        }
       
        protected void ddlFeetype_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ClassSessionid = 0;
            ClassSessionid = Convert.ToInt32(ddlFeesMaster.SelectedValue);

            DisplayClassSession(ClassSessionid);
        }

        private void DisplayClassSession(int ActiveId)
        {
            try
            {
                ClassSessionDAL objClassSessionDAL = new ClassSessionDAL();
                ClassSession activeClassSession = objClassSessionDAL.ClassSessionGetById(ActiveId);
                if (activeClassSession != null)
                {
                    activeClassSession.Description = TextBox2.Text;
                    ddlFeesMaster.SelectedValue = activeClassSession.FeeType.ToString();
                    ddlSession.Text = activeClassSession.Session;
                    ddlClassMaster.SelectedItem.Text = activeClassSession.Class;
                    ddlLevel.Text = activeClassSession.Levels;
                }
            }
            catch (Exception ex)
            {
                //  MessageBox.Show("UpdateProduct: " + ex.Message, "ICT", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private bool IPost()
        {

            bool IsPost = true;


            ClassFeePostDAL activeClassFeePostDAL = new ClassFeePostDAL();
            ClassFeePost activeClassFeePost = new ClassFeePost();

            //     ClassFeePost activeClassFeePost = activeClassFeePostDAL.ClassFeePostGetById(Convert.ToInt32(ddlFeesMaster.SelectedValue));
            List<ClassFeePost> activeClassFeePostList = (List<ClassFeePost>)ViewState["ClassFeePost"];
            if (GridViewFee.Rows.Count > 0)
            {
                if (ActiveId <= 0)
                {
                    if (ViewState["ClassFeePost"] != null)
                    {
                        activeClassFeePostList = (List<ClassFeePost>)ViewState["ClassFeePost"];
                    }
                    GridViewFee.DataSource = null;
                }
            }

                int index = rowIndex;

                if (!string.IsNullOrEmpty(HiddenFieldClassPost.Value))
                {
                    activeClassFeePost.Id = Convert.ToInt32(HiddenFieldClassPost.Value);
                }

                if (!string.IsNullOrEmpty(ddlFeesMaster.SelectedItem.Text))
                {
                    activeClassFeePost.FeeType = ddlFeesMaster.SelectedItem.ToString();
                }
                else
                {
                    IsPost = false;
                }
            
                if (IsPost == true)
                {
                    if (buttonFeePost.Text == "Post")
                    {
                        UnitId = activeClassFeePostDAL.ClassFeePostInsert(activeClassFeePost);
                        //  Response.Redirect("ClassSessionForm.aspx");
                        // GridViewFee.Columns.Clear();
                        //     GridViewFeeMaster.DataSource = null;
                    }

                    else if (ClassSave.Text == "Update")
                    {
                        if (activeClassFeePostDAL.ClassFeePostUpdate(activeClassFeePost) == true)
                            IsPost = true;
                        //  Response.Redirect("ClassSessionForm.aspx");
                    }
                    
                }
              //  activeClassFeePostList.RemoveAt(index);
              //  activeClassFeePostList.Insert(index, activeClassFeePost);
            
            return IsPost;
        }


        ////private void ClearClassFeePost()
        ////{
        ////    ActiveId = 0;

        ////    //VendorId = 0;
        ////    ddlFeesMaster.ClearSelection();

        ////    GridViewFee.DataSource = null;
        ////    ViewState["FeePost"] = null;
        ////    Response.Redirect("ClassSessionForm.aspx");
        ////    Initilaize();
        ////    loadSession();

        //}

        //private bool Post()
        //{
        //    bool isSave = true;
        //    try
        //    {
        //        activeClassFeePostList = (List<ClassFeePost>)ViewState["ClassFeePost"];

        //        if (isSave)
        //        {
        //                if (ActiveId <= 0 && PIActiveId <= 0)
        //                {
        //                    // GridViewPurchaseReq.DataSource = null;
        //                }
        //                if (GridViewFee.Rows.Count > 0)
        //                {
        //                    if (PIActiveId > 0)
        //                    {
        //                        if (ViewState["ClassFeePost"] != null)
        //                        {
        //                            activeClassFeePostList = (List<ClassFeePost>)ViewState["ClassFeePost"];
        //                        }
        //                        int index = rowIndex;
        //                        ClassFeePost activeClassFeePost = new ClassFeePost();
        //                        activeClassFeePost.Id = 1;
        //                        //  activeClassFeePost.productid = Convert.ToInt32(ddlProduct.SelectedValue);
        //                        activeClassFeePost.FeeType = ddlFeesMaster.SelectedItem.Text;

        //                        activeClassFeePostList.RemoveAt(index);
        //                        activeClassFeePostList.Insert(index, activeClassFeePost);
        //                    }
        //                    else
        //                    {
        //                        if (ActiveId <= 0)
        //                        {
        //                            if (ViewState["ClassFeePost"] != null)
        //                            {
        //                                activeClassFeePostList = (List<ClassFeePost>)ViewState["ClassFeePost"];
        //                            }
        //                            GridViewFee.DataSource = null;
        //                        }

        //                        if (ViewState["ClassFeePost"] != null)
        //                        {
        //                            activeClassFeePostList = (List<ClassFeePost>)ViewState["ClassFeePost"];
        //                        }

        //                        ClassFeePost activeClassFeePost = new ClassFeePost();
        //                        activeClassFeePost.Id = 1;
        //                       // activeClassFeePost.productid = Convert.ToInt32(ddlProduct.SelectedValue);
        //                        activeClassFeePost.FeeType = ddlFeesMaster.SelectedItem.Text;

        //                        activeClassFeePostList.Add(activeClassFeePost);
        //                    }
        //                }
        //                else
        //                {
        //                    ClassFeePost activeClassFeePost = new ClassFeePost();
        //                    activeClassFeePost.Id = 1;
        //                //    activePurchase.productid = Convert.ToInt32(ddlProduct.SelectedValue);
        //                    activeClassFeePost.FeeType = ddlFeesMaster.SelectedItem.Text;



        //                    activeClassFeePostList.Add(activeClassFeePost);
        //                }
        //                GridViewFee.DataSource = activeClassFeePostList;
        //                GridViewFee.DataBind();
        //                ViewState["ClassFeePost"] = activeClassFeePostList;

        //            }
        //            else
        //            {
        //                divInfor.Visible = true;
        //            }
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    return isSave;
        //}  

        public bool Post()
        {
            if (ddlFeesMaster.Text == "")
            {
                msgAleart.Visible = true;
                lblMessage.Text = "Please Fill all Fields Correctly";
                return false;
            }
            bool _post = true;
            ClassFeePostDAL _dalApproval = new ClassFeePostDAL();
            List<ClassFeePost> _listApproval = new List<ClassFeePost>();
            if (ViewState["ClassFeePost"] != null)
            {
                _listApproval = (List<ClassFeePost>)ViewState["ClassFeePost"];
            }

            //var _item = _listApproval.Find(x => x.FormID == Convert.ToInt16(ddlForms.SelectedItem.Value) && x.UserID == Convert.ToInt16(ddlUser.SelectedItem.Value));
            //if (_item != null)
            //{
            //    msgAleart.Visible = true;
            //    lblMessage.Text = "Duplicate Value not Allowed";
            //    ddlForms.ClearSelection();
            //    ddlUser.ClearSelection();
            //    txtSequence.Value = "";
            //    return false;
            //} 
            ClassFeePost _approval = new ClassFeePost();
            if (ActiveId == 0)
            {
                _approval.Id = Convert.ToInt16(_dalApproval.MaxClassFeePostID().Tables[0].Rows[0][0]);
            }
            else
            {
                _approval.Id = ActiveId;
            }

            _approval.Id = Convert.ToInt16(ddlFeesMaster.SelectedValue);
            _approval.FeeType = ddlFeesMaster.SelectedItem.Text;
            //_approval.UserID = Convert.ToInt16(ddlUser.SelectedValue);
            //_approval.UserName = ddlUser.SelectedItem.Text;
            //_approval.Sequence = string.IsNullOrEmpty(txtSequence.Value) ? 0 : Convert.ToInt16(txtSequence.Value);
            if (rowIndex >= 0)
            {
                _listApproval.RemoveAt(rowIndex);
                rowIndex = -1;
                lblMessage.Text = "";
                ddlFeesMaster.ClearSelection();
                //  ddlUser.ClearSelection();
                // txtSequence.Value = "";

            }

            _listApproval.Add(_approval);
            GridViewFee.DataSource = _listApproval;
            GridViewFee.DataBind();
            ViewState["ClassFeePost"] = _listApproval;
            lblMessage.Text = "";
            ddlFeesMaster.ClearSelection();
            //   ddlUser.ClearSelection();
            // txtSequence.Value = "";
            return _post;
        }

    }  
}
 